// src/popup/welcome.ts
var $ = (id) => document.getElementById(id);
var send = (msg) => chrome.runtime.sendMessage(msg);
var STATUS_TEXT = { unpaired: "Not connected", connecting: "Connecting", connected: "Connected", disconnected: "Offline", revoked: "Removed" };
var toastTimer;
function toast(msg) {
  const t = $("toast");
  t.textContent = msg;
  t.classList.add("on");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove("on"), 1800);
}
var formatCode = (v) => {
  const raw = v.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 10);
  return raw.length > 5 ? `${raw.slice(0, 5)}-${raw.slice(5)}` : raw;
};
async function render() {
  const s = await send({ type: "acm:status" }).catch(() => null);
  if (!s) return;
  const paired = s.status !== "unpaired" && s.status !== "revoked";
  const st = $("status");
  st.className = `status ${s.status}`;
  $("statusText").textContent = STATUS_TEXT[s.status] ?? s.status;
  $("setup").hidden = paired;
  $("done").hidden = !paired;
  const server = s.server || "https://agent-chrome-mcp.circo.workers.dev";
  $("docs").href = server;
  const sv = $("server");
  if (!sv.value) sv.value = "http://127.0.0.1:47823";
  $("waiting").hidden = !s.connectPending;
  if (paired) $("doneName").textContent = s.name || "This profile";
  const code2 = $("code");
  $("s2").classList.add("active");
}
var code = $("code");
code.addEventListener("input", () => {
  code.value = formatCode(code.value);
  code.classList.toggle("complete", code.value.length === 11);
  $("pairError").hidden = true;
  render();
});
$("pairForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const err = $("pairError");
  const btn = $("pair");
  const c = formatCode(code.value);
  if (c.length !== 11) {
    err.hidden = false;
    err.textContent = "Pairing codes have 10 characters, like ABCDE-FGHJK.";
    return;
  }
  err.hidden = true;
  btn.disabled = true;
  btn.classList.add("loading");
  btn.textContent = "Connecting";
  try {
    await chrome.permissions.request({ permissions: ["identity", "identity.email"] }).catch(() => false);
    const r = await send({
      type: "acm:pair",
      server: $("server").value.trim(),
      code: c,
      name: $("pname").value.trim() || "Chrome"
    });
    if (r?.error) throw new Error(r.error);
  } catch (x) {
    err.hidden = false;
    err.textContent = String(x.message ?? x).replace(/^Error: /, "");
  } finally {
    btn.disabled = false;
    btn.classList.remove("loading");
    btn.textContent = "Connect";
    render();
  }
});
var copy = async (text, label) => {
  await navigator.clipboard.writeText(text);
  toast("Copied to clipboard");
  if (label) {
    label.textContent = "Copied";
    setTimeout(() => label.textContent = "Copy", 1500);
  }
};
$("signin").onclick = async () => {
  $("pairError").hidden = true;
  const r = await send({ type: "acm:connect-start", server: "https://agent-chrome-mcp.circo.workers.dev", name: $("pname").value.trim() || "Chrome" });
  if (r?.error) {
    $("pairError").hidden = false;
    $("pairError").textContent = r.error;
  }
  render();
};
$("copyPrompt").onclick = (e) => copy("Use agent-chrome to open news.ycombinator.com and take a screenshot", e.currentTarget.querySelector(".copy"));
chrome.runtime.onMessage.addListener((m) => m?.type === "acm:status-changed" && render());
render();
setInterval(render, 2e3);
$("pname").focus();
