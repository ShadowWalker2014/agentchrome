"use strict";
(() => {
  // ../protocol/src/tools.ts
  var browser = {
    type: "string",
    description: "Which connected Chrome profile to use (id or name from list_browsers). Optional: defaults to the browser selected with select_browser, else the most recently active one."
  };
  var tabId = {
    type: "number",
    description: "Tab ID from tabs_context. Optional: defaults to this session's current tab (created inside the session tab group if none exists)."
  };
  var coord = {
    type: "array",
    items: { type: "number" },
    minItems: 2,
    maxItems: 2,
    description: "[x, y] in screenshot pixels (same space as the last screenshot of this tab)."
  };
  var obj = (properties, required = []) => ({
    type: "object",
    properties: { ...properties, browser },
    required,
    additionalProperties: false
  });
  var TOOLS = [
    {
      name: "list_browsers",
      title: "List connected browsers",
      server: true,
      description: "List the Chrome profiles paired with this account, with online status. Each Chrome profile that installs the extension and pairs shows up as its own browser.",
      inputSchema: { type: "object", properties: {}, additionalProperties: false },
      annotations: { readOnlyHint: true }
    },
    {
      name: "select_browser",
      title: "Select browser",
      server: true,
      description: "Choose which paired Chrome profile this session controls by default. Pass the id or name from list_browsers.",
      inputSchema: {
        type: "object",
        properties: { browser: { type: "string", description: "Browser id or name." } },
        required: ["browser"],
        additionalProperties: false
      }
    },
    {
      name: "pairing_code",
      title: "Get a pairing code",
      server: true,
      description: "Get a one-time code to connect a Chrome profile to this account. Give the user the code with these steps: install the Agent Chrome extension (download link in the result), click its toolbar icon, paste the code and press Connect. Use this when list_browsers shows no browser, or the user wants to add another Chrome profile.",
      inputSchema: { type: "object", properties: {}, additionalProperties: false }
    },
    {
      name: "tabs_context",
      title: "Get session tabs",
      description: "Get the tabs in this session's Chrome tab group (id, url, title, active). Call this first to get a valid tabId. Each agent session gets its own tab group so its work stays separate from the user's tabs. Set createIfEmpty to open a blank tab in a new group when there is none. Set all=true to list every open tab in the browser.",
      inputSchema: obj({
        createIfEmpty: { type: "boolean", description: "Create the group with a new tab if the session has none. Default true." },
        all: { type: "boolean", description: "List every tab in the browser, not only this session's group." }
      }),
      annotations: { readOnlyHint: true }
    },
    {
      name: "tabs_create",
      title: "Open tab",
      description: "Open a new tab inside this session's tab group and make it the session's current tab. Optionally load a URL.",
      inputSchema: obj({
        url: { type: "string", description: "URL to open. Default about:blank." },
        active: { type: "boolean", description: "Focus the tab in its window. Default false (work happens in the background)." }
      })
    },
    {
      name: "tabs_close",
      title: "Close tab",
      description: "Close a tab. Only tabs in this session's group can be closed unless force is true.",
      inputSchema: obj({ tabId: { ...tabId, description: "Tab to close." }, force: { type: "boolean" } }, ["tabId"]),
      annotations: { destructiveHint: true }
    },
    {
      name: "tabs_select",
      title: "Switch tab",
      description: "Make a tab this session's current tab. Pass adopt=true to move a user's tab into the session group. Pass focus=true to also bring it to the front.",
      inputSchema: obj({ tabId: { ...tabId, description: "Tab to switch to." }, adopt: { type: "boolean" }, focus: { type: "boolean" } }, ["tabId"])
    },
    {
      name: "tab_groups",
      title: "Manage tab groups",
      description: "List, create, rename, recolor, collapse or ungroup Chrome tab groups. action=list returns every group. action=update changes title/color/collapsed of a group (defaults to this session's group). action=create groups the given tabIds (or the current tab) into a new group. action=ungroup removes tabs from their group. action=move moves tabIds into a group.",
      inputSchema: obj(
        {
          action: { type: "string", enum: ["list", "create", "update", "ungroup", "move"] },
          groupId: { type: "number", description: "Target group. Default: this session's group." },
          tabIds: { type: "array", items: { type: "number" } },
          title: { type: "string", description: "New group name." },
          color: { type: "string", enum: ["grey", "blue", "red", "yellow", "green", "pink", "purple", "cyan", "orange"] },
          collapsed: { type: "boolean" },
          makeSessionGroup: { type: "boolean", description: "With create/move: make this the session's group from now on." }
        },
        ["action"]
      )
    },
    {
      name: "navigate",
      title: "Navigate",
      description: "Load a URL in a tab and wait for it to finish loading. Use 'back' or 'forward' for history navigation, 'reload' to reload.",
      inputSchema: obj({ url: { type: "string" }, tabId, timeoutMs: { type: "number", description: "Max wait for load. Default 30000." } }, ["url"]),
      timeoutMs: 6e4
    },
    {
      name: "computer",
      title: "Mouse, keyboard and screenshots",
      description: [
        "Use a mouse and keyboard to interact with the page, and take screenshots.",
        "Coordinates are in the pixel space of the latest screenshot of that tab. Take a screenshot first.",
        "Prefer clicking with ref (from read_page or find) over coordinates when you have one.",
        "Actions: screenshot, left_click, right_click, middle_click, double_click, triple_click, hover or mouse_move (moves the pointer without clicking), left_click_drag (start_coordinate or start_ref -> coordinate or ref; native HTML5 drag and drop works), type (text), key (text like 'Enter', 'cmd+a', 'ctrl+shift+t'; space-separated for sequences), scroll (scroll_direction, scroll_amount), scroll_to (ref), wait (duration seconds), zoom (region screenshot at full resolution)."
      ].join(" "),
      inputSchema: obj(
        {
          action: {
            type: "string",
            enum: [
              "screenshot",
              "left_click",
              "right_click",
              "middle_click",
              "double_click",
              "triple_click",
              "hover",
              "mouse_move",
              "left_click_drag",
              "type",
              "key",
              "scroll",
              "scroll_to",
              "wait",
              "zoom"
            ]
          },
          coordinate: coord,
          start_coordinate: { ...coord, description: "[x, y] drag start for left_click_drag." },
          start_ref: { type: "string", description: "Element ref to start a drag from (alternative to start_coordinate)." },
          ref: { type: "string", description: "Element ref from read_page/find, e.g. 'ref_12'. Alternative to coordinate." },
          text: { type: "string", description: "Text to type (type) or keys to press (key)." },
          modifiers: { type: "string", description: "Modifier keys held during a click: ctrl, shift, alt, cmd; combine with '+'." },
          scroll_direction: { type: "string", enum: ["up", "down", "left", "right"] },
          scroll_amount: { type: "number", minimum: 1, maximum: 20, description: "Scroll ticks. Default 3." },
          duration: { type: "number", minimum: 0, maximum: 30, description: "Seconds to wait." },
          repeat: { type: "number", minimum: 1, maximum: 100, description: "Repeat count for key." },
          region: { type: "array", items: { type: "number" }, minItems: 4, maxItems: 4, description: "[x0, y0, x1, y1] for zoom." },
          tabId
        },
        ["action"]
      ),
      timeoutMs: 6e4
    },
    {
      name: "screenshot",
      title: "Screenshot",
      description: "Capture a screenshot of a tab. fullPage captures the whole scrollable page. Set save=true to also store it and get a download URL.",
      inputSchema: obj({
        tabId,
        fullPage: { type: "boolean" },
        format: { type: "string", enum: ["jpeg", "png"], description: "Default jpeg." },
        save: { type: "boolean", description: "Upload and return a download URL (cloud) or a file path (local)." }
      }),
      annotations: { readOnlyHint: true }
    },
    {
      name: "read_page",
      title: "Read accessibility tree",
      description: "Get an accessibility-tree view of the page: each element's role, name and a ref like 'ref_12' usable in computer, form_input, file_upload and scroll_to. filter='interactive' returns only buttons, links and inputs. Output is limited to max_chars (default 50000).",
      inputSchema: obj({
        tabId,
        filter: { type: "string", enum: ["interactive", "all"], description: "Default all." },
        depth: { type: "number", description: "Max tree depth. Default 25." },
        ref_id: { type: "string", description: "Scope to the subtree under this ref." },
        max_chars: { type: "number" },
        viewportOnly: { type: "boolean", description: "Only elements visible in the viewport." }
      }),
      annotations: { readOnlyHint: true }
    },
    {
      name: "find",
      title: "Find elements",
      description: "Find elements matching a description, e.g. 'search box', 'Sign in button', 'price of the first result'. Returns up to 20 matches with refs and screenshot coordinates.",
      inputSchema: obj({ query: { type: "string" }, tabId, limit: { type: "number" } }, ["query"]),
      annotations: { readOnlyHint: true }
    },
    {
      name: "form_input",
      title: "Set form value",
      description: "Set the value of a form control by ref: text inputs and textareas (string), checkboxes and radios (boolean), selects (option value or visible text), contenteditable (string). Fires input and change events like a user would.",
      inputSchema: obj(
        { ref: { type: "string" }, value: { type: ["string", "number", "boolean"] }, tabId },
        ["ref", "value"]
      )
    },
    {
      name: "get_page_text",
      title: "Get page text",
      description: "Get the readable text of the page (article or main content when present), plus title and URL.",
      inputSchema: obj({ tabId, max_chars: { type: "number", description: "Default 50000." } }),
      annotations: { readOnlyHint: true }
    },
    {
      name: "javascript_tool",
      title: "Run JavaScript",
      description: "Run JavaScript in the page's main world and return the value of the last expression (await is allowed). Runs even on pages with a strict CSP. Do not return huge objects.",
      inputSchema: obj(
        {
          text: { type: "string", description: "JavaScript code." },
          action: { type: "string", enum: ["javascript_exec"], description: "Optional, for Claude in Chrome compatibility." },
          tabId
        },
        ["text"]
      ),
      timeoutMs: 6e4
    },
    {
      name: "read_console_messages",
      title: "Read console",
      description: "Read console messages and uncaught errors from a tab, captured since the agent first touched it. Filter with a regex pattern.",
      inputSchema: obj({
        tabId,
        pattern: { type: "string" },
        onlyErrors: { type: "boolean" },
        clear: { type: "boolean" },
        limit: { type: "number", description: "Default 100." }
      }),
      annotations: { readOnlyHint: true }
    },
    {
      name: "read_network_requests",
      title: "Read network requests",
      description: "Read HTTP requests made by a tab (url, method, status, type, timing), captured since the agent first touched it. Filter by urlPattern (substring or regex).",
      inputSchema: obj({
        tabId,
        urlPattern: { type: "string" },
        clear: { type: "boolean" },
        limit: { type: "number", description: "Default 100." },
        includeBodies: { type: "boolean", description: "Include response bodies of up to 10 KB for XHR/fetch requests." }
      }),
      annotations: { readOnlyHint: true }
    },
    {
      name: "resize_window",
      title: "Resize window",
      description: "Resize the browser window that holds the tab.",
      inputSchema: obj({ width: { type: "number" }, height: { type: "number" }, tabId }, ["width", "height"])
    },
    {
      name: "file_upload",
      title: "Upload files",
      description: "Put files into a file input or a drop zone without the native file picker. Give ref (the file input, its upload button or a drop zone from read_page), or leave ref out to fill a file picker the page just tried to open (click results tell you when). Pass paths (absolute paths on the computer running Chrome; the page gets real files) or files (each with base64, url or a screenshot imageId).",
      inputSchema: obj({
        ref: { type: "string", description: "File input, upload button or drop zone. Omit to fill a file picker that a click opened." },
        paths: { type: "array", items: { type: "string" }, description: "Absolute file paths on the computer running Chrome." },
        files: {
          type: "array",
          items: {
            type: "object",
            properties: {
              name: { type: "string" },
              mimeType: { type: "string" },
              base64: { type: "string" },
              url: { type: "string" },
              imageId: { type: "string", description: "id returned by a screenshot." }
            },
            required: ["name"]
          }
        },
        tabId
      }),
      timeoutMs: 6e4
    },
    {
      name: "upload_image",
      title: "Upload screenshot",
      description: "Upload a captured screenshot (imageId) into a file input (ref) or drop it on a target (coordinate).",
      inputSchema: obj(
        { imageId: { type: "string" }, ref: { type: "string" }, coordinate: coord, filename: { type: "string" }, tabId },
        ["imageId"]
      )
    },
    {
      name: "record",
      title: "Record video",
      description: "Record a video clip of a tab. action=start begins, action=stop finishes and returns a download URL (cloud) or file path (local) for an MP4 or WebM file, action=status reports progress. The clip looks like a person using the page: the blue border, status pill and the cursor's name tag are left out, and the cursor is a normal arrow that turns into a hand over links and an I-beam over text (cursor=natural, the default). Use cursor=agent to show the agent cursor and indicators, or cursor=hidden for no cursor. The toolbar icon shows REC meanwhile. Max length 10 minutes.",
      inputSchema: obj(
        {
          action: { type: "string", enum: ["start", "stop", "status"] },
          tabId,
          fps: { type: "number", description: "Frames per second, default 15." },
          format: { type: "string", enum: ["mp4", "webm"], description: "Default mp4 when Chrome supports it." },
          filename: { type: "string" },
          download: { type: "boolean", description: "Also save into the browser's Downloads folder." },
          cursor: { type: "string", enum: ["natural", "agent", "hidden"], description: "How the cursor looks in the clip. Default natural." },
          showClicks: { type: "boolean", description: "Draw a soft ripple where clicks land. Default false." }
        },
        ["action"]
      ),
      timeoutMs: 12e4
    },
    {
      name: "gif_creator",
      title: "Record GIF",
      description: "Record browser actions and export an animated GIF. action=start_recording, stop_recording, export (returns the GIF), clear.",
      inputSchema: obj(
        {
          action: { type: "string", enum: ["start_recording", "stop_recording", "export", "clear"] },
          cursor: { type: "string", enum: ["natural", "agent", "hidden"], description: "How the cursor looks in the GIF. Default natural." },
          showClicks: { type: "boolean", description: "Draw click ripples. Default false." },
          tabId,
          filename: { type: "string" },
          download: { type: "boolean" }
        },
        ["action"]
      ),
      timeoutMs: 12e4
    },
    {
      name: "wait_for",
      title: "Wait for page condition",
      description: "Wait until text appears, a CSS selector matches, text disappears, or the URL matches. Returns as soon as the condition holds or fails after timeoutMs.",
      inputSchema: obj({
        tabId,
        text: { type: "string" },
        textGone: { type: "string" },
        selector: { type: "string" },
        urlIncludes: { type: "string" },
        timeoutMs: { type: "number", description: "Default 10000, max 60000." }
      }),
      timeoutMs: 7e4,
      annotations: { readOnlyHint: true }
    },
    {
      name: "handle_dialog",
      title: "Handle dialog",
      description: "Accept or dismiss a JavaScript alert/confirm/prompt/beforeunload dialog on a tab. Dialogs block the page until handled; tool results mention an open dialog.",
      inputSchema: obj({ accept: { type: "boolean" }, promptText: { type: "string" }, tabId }, ["accept"])
    },
    {
      name: "history_search",
      title: "Search browsing history",
      description: "Search this Chrome profile's browsing history. Works only when the user turned on history access in the extension popup.",
      inputSchema: obj({ query: { type: "string" }, maxResults: { type: "number" }, daysBack: { type: "number" } }, ["query"]),
      annotations: { readOnlyHint: true }
    }
  ];
  var READ_ONLY = /* @__PURE__ */ new Set(["list_browsers", "tabs_context", "screenshot", "read_page", "find", "get_page_text", "read_console_messages", "read_network_requests", "wait_for", "history_search"]);
  for (const t of TOOLS) {
    t.annotations = {
      title: t.title,
      readOnlyHint: READ_ONLY.has(t.name),
      destructiveHint: t.name === "tabs_close",
      idempotentHint: READ_ONLY.has(t.name),
      openWorldHint: !t.server
    };
  }
  var TOOL_BY_NAME = new Map(TOOLS.map((t) => [t.name, t]));

  // ../protocol/src/mcp.ts
  var SUPPORTED_PROTOCOL_VERSIONS = ["2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05"];
  var LATEST_PROTOCOL_VERSION = SUPPORTED_PROTOCOL_VERSIONS[0];
  var enc = new TextEncoder();

  // ../protocol/src/agent-icons.ts
  var AGENT_ICONS = {
    "claude": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="100%" height="100%"><path d="M4.709 15.955l4.72-2.647.08-.23-.08-.128H9.2l-.79-.048-2.698-.073-2.339-.097-2.266-.122-.571-.121L0 11.784l.055-.352.48-.321.686.06 1.52.103 2.278.158 1.652.097 2.449.255h.389l.055-.157-.134-.098-.103-.097-2.358-1.596-2.552-1.688-1.336-.972-.724-.491-.364-.462-.158-1.008.656-.722.881.06.225.061.893.686 1.908 1.476 2.491 1.833.365.304.145-.103.019-.073-.164-.274-1.355-2.446-1.446-2.49-.644-1.032-.17-.619a2.97 2.97 0 01-.104-.729L6.283.134 6.696 0l.996.134.42.364.62 1.414 1.002 2.229 1.555 3.03.456.898.243.832.091.255h.158V9.01l.128-1.706.237-2.095.23-2.695.08-.76.376-.91.747-.492.584.28.48.685-.067.444-.286 1.851-.559 2.903-.364 1.942h.212l.243-.242.985-1.306 1.652-2.064.73-.82.85-.904.547-.431h1.033l.76 1.129-.34 1.166-1.064 1.347-.881 1.142-1.264 1.7-.79 1.36.073.11.188-.02 2.856-.606 1.543-.28 1.841-.315.833.388.091.395-.328.807-1.969.486-2.309.462-3.439.813-.042.03.049.061 1.549.146.662.036h1.622l3.02.225.79.522.474.638-.079.485-1.215.62-1.64-.389-3.829-.91-1.312-.329h-.182v.11l1.093 1.068 2.006 1.81 2.509 2.33.127.578-.322.455-.34-.049-2.205-1.657-.851-.747-1.926-1.62h-.128v.17l.444.649 2.345 3.521.122 1.08-.17.353-.608.213-.668-.122-1.374-1.925-1.415-2.167-1.143-1.943-.14.08-.674 7.254-.316.37-.729.28-.607-.461-.322-.747.322-1.476.389-1.924.315-1.53.286-1.9.17-.632-.012-.042-.14.018-1.434 1.967-2.18 2.945-1.726 1.845-.414.164-.717-.37.067-.662.401-.589 2.388-3.036 1.44-1.882.93-1.086-.006-.158h-.055L4.132 18.56l-1.13.146-.487-.456.061-.746.231-.243 1.908-1.312-.006.006z" fill="#D97757" fill-rule="nonzero"></path></svg>',
    "codex": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="100%" height="100%"><path d="M19.503 0H4.496A4.496 4.496 0 000 4.496v15.007A4.496 4.496 0 004.496 24h15.007A4.496 4.496 0 0024 19.503V4.496A4.496 4.496 0 0019.503 0z" fill="#fff"></path><path d="M9.064 3.344a4.578 4.578 0 012.285-.312c1 .115 1.891.54 2.673 1.275.01.01.024.017.037.021a.09.09 0 00.043 0 4.55 4.55 0 013.046.275l.047.022.116.057a4.581 4.581 0 012.188 2.399c.209.51.313 1.041.315 1.595a4.24 4.24 0 01-.134 1.223.123.123 0 00.03.115c.594.607.988 1.33 1.183 2.17.289 1.425-.007 2.71-.887 3.854l-.136.166a4.548 4.548 0 01-2.201 1.388.123.123 0 00-.081.076c-.191.551-.383 1.023-.74 1.494-.9 1.187-2.222 1.846-3.711 1.838-1.187-.006-2.239-.44-3.157-1.302a.107.107 0 00-.105-.024c-.388.125-.78.143-1.204.138a4.441 4.441 0 01-1.945-.466 4.544 4.544 0 01-1.61-1.335c-.152-.202-.303-.392-.414-.617a5.81 5.81 0 01-.37-.961 4.582 4.582 0 01-.014-2.298.124.124 0 00.006-.056.085.085 0 00-.027-.048 4.467 4.467 0 01-1.034-1.651 3.896 3.896 0 01-.251-1.192 5.189 5.189 0 01.141-1.6c.337-1.112.982-1.985 1.933-2.618.212-.141.413-.251.601-.33.215-.089.43-.164.646-.227a.098.098 0 00.065-.066 4.51 4.51 0 01.829-1.615 4.535 4.535 0 011.837-1.388zm3.482 10.565a.637.637 0 000 1.272h3.636a.637.637 0 100-1.272h-3.636zM8.462 9.23a.637.637 0 00-1.106.631l1.272 2.224-1.266 2.136a.636.636 0 101.095.649l1.454-2.455a.636.636 0 00.005-.64L8.462 9.23z" fill="url(#acm-codex-lobe-icons-codex-_R_0_)"></path><defs><linearGradient gradientUnits="userSpaceOnUse" id="acm-codex-lobe-icons-codex-_R_0_" x1="12" x2="12" y1="3" y2="21"><stop stop-color="#B1A7FF"></stop><stop offset=".5" stop-color="#7A9DFF"></stop><stop offset="1" stop-color="#3941FF"></stop></linearGradient></defs></svg>',
    "gemini": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="100%" height="100%"><path d="M20.616 10.835a14.147 14.147 0 01-4.45-3.001 14.111 14.111 0 01-3.678-6.452.503.503 0 00-.975 0 14.134 14.134 0 01-3.679 6.452 14.155 14.155 0 01-4.45 3.001c-.65.28-1.318.505-2.002.678a.502.502 0 000 .975c.684.172 1.35.397 2.002.677a14.147 14.147 0 014.45 3.001 14.112 14.112 0 013.679 6.453.502.502 0 00.975 0c.172-.685.397-1.351.677-2.003a14.145 14.145 0 013.001-4.45 14.113 14.113 0 016.453-3.678.503.503 0 000-.975 13.245 13.245 0 01-2.003-.678z" fill="#3186FF"></path><path d="M20.616 10.835a14.147 14.147 0 01-4.45-3.001 14.111 14.111 0 01-3.678-6.452.503.503 0 00-.975 0 14.134 14.134 0 01-3.679 6.452 14.155 14.155 0 01-4.45 3.001c-.65.28-1.318.505-2.002.678a.502.502 0 000 .975c.684.172 1.35.397 2.002.677a14.147 14.147 0 014.45 3.001 14.112 14.112 0 013.679 6.453.502.502 0 00.975 0c.172-.685.397-1.351.677-2.003a14.145 14.145 0 013.001-4.45 14.113 14.113 0 016.453-3.678.503.503 0 000-.975 13.245 13.245 0 01-2.003-.678z" fill="url(#acm-gemini-lobe-icons-gemini-0-_R_0_)"></path><path d="M20.616 10.835a14.147 14.147 0 01-4.45-3.001 14.111 14.111 0 01-3.678-6.452.503.503 0 00-.975 0 14.134 14.134 0 01-3.679 6.452 14.155 14.155 0 01-4.45 3.001c-.65.28-1.318.505-2.002.678a.502.502 0 000 .975c.684.172 1.35.397 2.002.677a14.147 14.147 0 014.45 3.001 14.112 14.112 0 013.679 6.453.502.502 0 00.975 0c.172-.685.397-1.351.677-2.003a14.145 14.145 0 013.001-4.45 14.113 14.113 0 016.453-3.678.503.503 0 000-.975 13.245 13.245 0 01-2.003-.678z" fill="url(#acm-gemini-lobe-icons-gemini-1-_R_0_)"></path><path d="M20.616 10.835a14.147 14.147 0 01-4.45-3.001 14.111 14.111 0 01-3.678-6.452.503.503 0 00-.975 0 14.134 14.134 0 01-3.679 6.452 14.155 14.155 0 01-4.45 3.001c-.65.28-1.318.505-2.002.678a.502.502 0 000 .975c.684.172 1.35.397 2.002.677a14.147 14.147 0 014.45 3.001 14.112 14.112 0 013.679 6.453.502.502 0 00.975 0c.172-.685.397-1.351.677-2.003a14.145 14.145 0 013.001-4.45 14.113 14.113 0 016.453-3.678.503.503 0 000-.975 13.245 13.245 0 01-2.003-.678z" fill="url(#acm-gemini-lobe-icons-gemini-2-_R_0_)"></path><defs><linearGradient gradientUnits="userSpaceOnUse" id="acm-gemini-lobe-icons-gemini-0-_R_0_" x1="7" x2="11" y1="15.5" y2="12"><stop stop-color="#08B962"></stop><stop offset="1" stop-color="#08B962" stop-opacity="0"></stop></linearGradient><linearGradient gradientUnits="userSpaceOnUse" id="acm-gemini-lobe-icons-gemini-1-_R_0_" x1="8" x2="11.5" y1="5.5" y2="11"><stop stop-color="#F94543"></stop><stop offset="1" stop-color="#F94543" stop-opacity="0"></stop></linearGradient><linearGradient gradientUnits="userSpaceOnUse" id="acm-gemini-lobe-icons-gemini-2-_R_0_" x1="3.5" x2="17.5" y1="13.5" y2="12"><stop stop-color="#FABC12"></stop><stop offset=".46" stop-color="#FABC12" stop-opacity="0"></stop></linearGradient></defs></svg>',
    "antigravity": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="100%" height="100%"><mask height="23" id="acm-antigravity-lobe-icons-antigravity-0-_R_0_" maskUnits="userSpaceOnUse" width="24" x="0" y="1"><path d="M21.751 22.607c1.34 1.005 3.35.335 1.508-1.508C17.73 15.74 18.904 1 12.037 1 5.17 1 6.342 15.74.815 21.1c-2.01 2.009.167 2.511 1.507 1.506 5.192-3.517 4.857-9.714 9.715-9.714 4.857 0 4.522 6.197 9.714 9.715z" fill="#fff"></path></mask><g mask="url(#acm-antigravity-lobe-icons-antigravity-0-_R_0_)"><g filter="url(#acm-antigravity-lobe-icons-antigravity-1-_R_0_)"><path d="M-1.018-3.992c-.408 3.591 2.686 6.89 6.91 7.37 4.225.48 7.98-2.043 8.387-5.633.408-3.59-2.686-6.89-6.91-7.37-4.225-.479-7.98 2.043-8.387 5.633z" fill="#FFE432"></path></g><g filter="url(#acm-antigravity-lobe-icons-antigravity-2-_R_0_)"><path d="M15.269 7.747c1.058 4.557 5.691 7.374 10.348 6.293 4.657-1.082 7.575-5.653 6.516-10.21-1.058-4.556-5.691-7.374-10.348-6.292-4.657 1.082-7.575 5.653-6.516 10.21z" fill="#FC413D"></path></g><g filter="url(#acm-antigravity-lobe-icons-antigravity-3-_R_0_)"><path d="M-12.443 10.804c1.338 4.703 7.36 7.11 13.453 5.378 6.092-1.733 9.947-6.95 8.61-11.652C8.282-.173 2.26-2.58-3.833-.848-9.925.884-13.78 6.1-12.443 10.804z" fill="#00B95C"></path></g><g filter="url(#acm-antigravity-lobe-icons-antigravity-4-_R_0_)"><path d="M-12.443 10.804c1.338 4.703 7.36 7.11 13.453 5.378 6.092-1.733 9.947-6.95 8.61-11.652C8.282-.173 2.26-2.58-3.833-.848-9.925.884-13.78 6.1-12.443 10.804z" fill="#00B95C"></path></g><g filter="url(#acm-antigravity-lobe-icons-antigravity-5-_R_0_)"><path d="M-7.608 14.703c3.352 3.424 9.126 3.208 12.896-.483 3.77-3.69 4.108-9.459.756-12.883C2.69-2.087-3.083-1.871-6.853 1.82c-3.77 3.69-4.108 9.458-.755 12.883z" fill="#00B95C"></path></g><g filter="url(#acm-antigravity-lobe-icons-antigravity-6-_R_0_)"><path d="M9.932 27.617c1.04 4.482 5.384 7.303 9.7 6.3 4.316-1.002 6.971-5.448 5.93-9.93-1.04-4.483-5.384-7.304-9.7-6.301-4.316 1.002-6.971 5.448-5.93 9.93z" fill="#3186FF"></path></g><g filter="url(#acm-antigravity-lobe-icons-antigravity-7-_R_0_)"><path d="M2.572-8.185C.392-3.329 2.778 2.472 7.9 4.771c5.122 2.3 11.042.227 13.222-4.63 2.18-4.855-.205-10.656-5.327-12.955-5.122-2.3-11.042-.227-13.222 4.63z" fill="#FBBC04"></path></g><g filter="url(#acm-antigravity-lobe-icons-antigravity-8-_R_0_)"><path d="M-3.267 38.686c-5.277-2.072 3.742-19.117 5.984-24.83 2.243-5.712 8.34-8.664 13.616-6.592 5.278 2.071 11.533 13.482 9.29 19.195-2.242 5.713-23.613 14.298-28.89 12.227z" fill="#3186FF"></path></g><g filter="url(#acm-antigravity-lobe-icons-antigravity-9-_R_0_)"><path d="M28.71 17.471c-1.413 1.649-5.1.808-8.236-1.878-3.135-2.687-4.531-6.201-3.118-7.85 1.412-1.649 5.1-.808 8.235 1.878s4.532 6.2 3.119 7.85z" fill="#749BFF"></path></g><g filter="url(#acm-antigravity-lobe-icons-antigravity-10-_R_0_)"><path d="M18.163 9.077c5.81 3.93 12.502 4.19 14.946.577 2.443-3.612-.287-9.727-6.098-13.658-5.81-3.931-12.502-4.19-14.946-.577-2.443 3.612.287 9.727 6.098 13.658z" fill="#FC413D"></path></g><g filter="url(#acm-antigravity-lobe-icons-antigravity-11-_R_0_)"><path d="M-.915 2.684c-1.44 3.473-.97 6.967 1.05 7.804 2.02.837 4.824-1.3 6.264-4.772 1.44-3.473.97-6.967-1.05-7.804-2.02-.837-4.824 1.3-6.264 4.772z" fill="#FFEE48"></path></g></g><defs><filter color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse" height="17.587" id="acm-antigravity-lobe-icons-antigravity-1-_R_0_" width="19.838" x="-3.288" y="-11.917"><feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend><feGaussianBlur result="effect1_foregroundBlur_977_115" stdDeviation="1.117"></feGaussianBlur></filter><filter color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse" height="38.565" id="acm-antigravity-lobe-icons-antigravity-2-_R_0_" width="38.9" x="4.251" y="-13.493"><feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend><feGaussianBlur result="effect1_foregroundBlur_977_115" stdDeviation="5.4"></feGaussianBlur></filter><filter color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse" height="36.517" id="acm-antigravity-lobe-icons-antigravity-3-_R_0_" width="40.955" x="-21.889" y="-10.592"><feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend><feGaussianBlur result="effect1_foregroundBlur_977_115" stdDeviation="4.591"></feGaussianBlur></filter><filter color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse" height="36.517" id="acm-antigravity-lobe-icons-antigravity-4-_R_0_" width="40.955" x="-21.889" y="-10.592"><feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend><feGaussianBlur result="effect1_foregroundBlur_977_115" stdDeviation="4.591"></feGaussianBlur></filter><filter color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse" height="36.595" id="acm-antigravity-lobe-icons-antigravity-5-_R_0_" width="36.632" x="-19.099" y="-10.278"><feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend><feGaussianBlur result="effect1_foregroundBlur_977_115" stdDeviation="4.591"></feGaussianBlur></filter><filter color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse" height="34.087" id="acm-antigravity-lobe-icons-antigravity-6-_R_0_" width="33.533" x=".981" y="8.758"><feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend><feGaussianBlur result="effect1_foregroundBlur_977_115" stdDeviation="4.363"></feGaussianBlur></filter><filter color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse" height="35.276" id="acm-antigravity-lobe-icons-antigravity-7-_R_0_" width="35.978" x="-6.143" y="-21.659"><feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend><feGaussianBlur result="effect1_foregroundBlur_977_115" stdDeviation="3.954"></feGaussianBlur></filter><filter color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse" height="46.523" id="acm-antigravity-lobe-icons-antigravity-8-_R_0_" width="45.114" x="-11.96" y="-.46"><feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend><feGaussianBlur result="effect1_foregroundBlur_977_115" stdDeviation="3.531"></feGaussianBlur></filter><filter color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse" height="24.054" id="acm-antigravity-lobe-icons-antigravity-9-_R_0_" width="25.094" x="10.485" y=".58"><feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend><feGaussianBlur result="effect1_foregroundBlur_977_115" stdDeviation="3.159"></feGaussianBlur></filter><filter color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse" height="30.007" id="acm-antigravity-lobe-icons-antigravity-10-_R_0_" width="33.508" x="5.833" y="-12.467"><feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend><feGaussianBlur result="effect1_foregroundBlur_977_115" stdDeviation="2.669"></feGaussianBlur></filter><filter color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse" height="26.151" id="acm-antigravity-lobe-icons-antigravity-11-_R_0_" width="22.194" x="-8.355" y="-8.876"><feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood><feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape"></feBlend><feGaussianBlur result="effect1_foregroundBlur_977_115" stdDeviation="3.303"></feGaussianBlur></filter></defs></svg>',
    "grok": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="100%" height="100%"><path d="M9.27 15.29l7.978-5.897c.391-.29.95-.177 1.137.272.98 2.369.542 5.215-1.41 7.169-1.951 1.954-4.667 2.382-7.149 1.406l-2.711 1.257c3.889 2.661 8.611 2.003 11.562-.953 2.341-2.344 3.066-5.539 2.388-8.42l.006.007c-.983-4.232.242-5.924 2.75-9.383.06-.082.12-.164.179-.248l-3.301 3.305v-.01L9.267 15.292M7.623 16.723c-2.792-2.67-2.31-6.801.071-9.184 1.761-1.763 4.647-2.483 7.166-1.425l2.705-1.25a7.808 7.808 0 00-1.829-1A8.975 8.975 0 005.984 5.83c-2.533 2.536-3.33 6.436-1.962 9.764 1.022 2.487-.653 4.246-2.34 6.022-.599.63-1.199 1.259-1.682 1.925l7.62-6.815"></path></svg>',
    "muse": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="100%" height="100%"><path d="M5.91 3.869C6.777 3.869 7.396 4.546 7.396 5.607 7.396 6.669 7.225 7.626 6.941 9.659 6.738 11.084 6.389 13.258 6.243 14.162 6.523 13.628 7.178 12.378 7.294 12.144 8.666 9.375 10.096 6.901 10.508 6.246 11.054 5.372 11.535 5.021 12.278 5.021 12.664 5.022 13.124 5.217 13.352 5.477 13.66 5.829 13.725 6.398 13.714 7.019 13.698 7.97 13.574 9.486 13.405 11.177 13.33 11.929 13.185 13.466 13.087 14.496 13.965 12.925 15.591 10.035 16.246 9.025 16.817 8.146 17.392 7.579 18.164 7.579 18.83 7.579 19.651 8.05 19.603 9.302 19.531 11.149 19.264 15.174 19.143 16.979 19.96 15.79 21.033 14.029 21.436 13.367 21.842 12.698 22.26 12.157 22.894 12.139 23.544 12.12 23.979 12.562 23.999 13.244 24.019 13.927 23.612 14.694 23.072 15.565 22.486 16.511 21.831 17.523 21.033 18.468 20.236 19.413 19.502 20.131 18.384 20.131 17.382 20.131 16.677 19.465 16.628 18.246 16.602 17.607 16.723 16.234 16.814 15.16 16.92 13.917 17.048 12.717 17.137 11.923 16.256 13.535 14.402 16.912 13.568 18.23 12.752 19.52 12.355 19.974 11.493 19.975 10.631 19.975 10.253 19.354 10.241 18.42 10.227 17.407 10.988 11.324 11.246 9.297 10.828 10.191 9.801 12.385 9.157 13.69 8.534 14.953 7.489 17.135 6.73 18.393 6.184 19.298 5.57 19.975 4.66 19.975 3.75 19.975 3.236 19.363 3.236 18.379 3.236 17.395 3.521 15.756 3.827 13.723 3.98 12.739 4.155 11.667 4.352 10.53 4.496 9.708 4.746 8.26 4.9 7.371 4.2 8.461 2.941 10.423 2.558 11.014 2.131 11.671 1.749 12.15 1.115 12.15 0.416 12.15 0 11.605 0 10.971 0 10.337 0.322 9.848 0.846 8.988 1.518 7.883 2.726 6.377 3.388 5.586 4.168 4.654 4.947 3.869 5.91 3.869Z" fill="url(#acm-muse-lobe-icons-muse-_R_0_)"></path><defs><linearGradient gradientUnits="userSpaceOnUse" id="acm-muse-lobe-icons-muse-_R_0_" x1="31.979" x2="5.981" y1="26.171" y2="-3.014"><stop offset=".255" stop-color="#0082FB"></stop><stop offset=".697" stop-color="#0064E0"></stop><stop offset="1" stop-color="#0040DC"></stop></linearGradient></defs></svg>',
    "cursor": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="100%" height="100%"><path d="M22.106 5.68L12.5.135a.998.998 0 00-.998 0L1.893 5.68a.84.84 0 00-.419.726v11.186c0 .3.16.577.42.727l9.607 5.547a.999.999 0 00.998 0l9.608-5.547a.84.84 0 00.42-.727V6.407a.84.84 0 00-.42-.726zm-.603 1.176L12.228 22.92c-.063.108-.228.064-.228-.061V12.34a.59.59 0 00-.295-.51l-9.11-5.26c-.107-.062-.063-.228.062-.228h18.55c.264 0 .428.286.296.514z"></path></svg>',
    "opencode": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="100%" height="100%"><path d="M16 6H8v12h8V6zm4 16H4V2h16v20z"></path></svg>',
    "windsurf": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="100%" height="100%"><path clip-rule="evenodd" d="M23.78 5.004h-.228a2.187 2.187 0 00-2.18 2.196v4.912c0 .98-.804 1.775-1.76 1.775a1.818 1.818 0 01-1.472-.773L13.168 5.95a2.197 2.197 0 00-1.81-.95c-1.134 0-2.154.972-2.154 2.173v4.94c0 .98-.797 1.775-1.76 1.775-.57 0-1.136-.289-1.472-.773L.408 5.098C.282 4.918 0 5.007 0 5.228v4.284c0 .216.066.426.188.604l5.475 7.889c.324.466.8.812 1.351.938 1.377.316 2.645-.754 2.645-2.117V11.89c0-.98.787-1.775 1.76-1.775h.002c.586 0 1.135.288 1.472.773l4.972 7.163a2.15 2.15 0 001.81.95c1.158 0 2.151-.973 2.151-2.173v-4.939c0-.98.787-1.775 1.76-1.775h.194c.122 0 .22-.1.22-.222V5.225a.221.221 0 00-.22-.222z"></path></svg>',
    "copilot": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="100%" height="100%"><path d="M19.245 5.364c1.322 1.36 1.877 3.216 2.11 5.817.622 0 1.2.135 1.592.654l.73.964c.21.278.323.61.323.955v2.62c0 .339-.173.669-.453.868C20.239 19.602 16.157 21.5 12 21.5c-4.6 0-9.205-2.583-11.547-4.258-.28-.2-.452-.53-.453-.868v-2.62c0-.345.113-.679.321-.956l.73-.963c.392-.517.974-.654 1.593-.654l.029-.297c.25-2.446.81-4.213 2.082-5.52 2.461-2.54 5.71-2.851 7.146-2.864h.198c1.436.013 4.685.323 7.146 2.864zm-7.244 4.328c-.284 0-.613.016-.962.05-.123.447-.305.85-.57 1.108-1.05 1.023-2.316 1.18-2.994 1.18-.638 0-1.306-.13-1.851-.464-.516.165-1.012.403-1.044.996a65.882 65.882 0 00-.063 2.884l-.002.48c-.002.563-.005 1.126-.013 1.69.002.326.204.63.51.765 2.482 1.102 4.83 1.657 6.99 1.657 2.156 0 4.504-.555 6.985-1.657a.854.854 0 00.51-.766c.03-1.682.006-3.372-.076-5.053-.031-.596-.528-.83-1.046-.996-.546.333-1.212.464-1.85.464-.677 0-1.942-.157-2.993-1.18-.266-.258-.447-.661-.57-1.108-.32-.032-.64-.049-.96-.05zm-2.525 4.013c.539 0 .976.426.976.95v1.753c0 .525-.437.95-.976.95a.964.964 0 01-.976-.95v-1.752c0-.525.437-.951.976-.951zm5 0c.539 0 .976.426.976.95v1.753c0 .525-.437.95-.976.95a.964.964 0 01-.976-.95v-1.752c0-.525.437-.951.976-.951zM7.635 5.087c-1.05.102-1.935.438-2.385.906-.975 1.037-.765 3.668-.21 4.224.405.394 1.17.657 1.995.657h.09c.649-.013 1.785-.176 2.73-1.11.435-.41.705-1.433.675-2.47-.03-.834-.27-1.52-.63-1.813-.39-.336-1.275-.482-2.265-.394zm6.465.394c-.36.292-.6.98-.63 1.813-.03 1.037.24 2.06.675 2.47.968.957 2.136 1.104 2.776 1.11h.044c.825 0 1.59-.263 1.995-.657.555-.556.765-3.187-.21-4.224-.45-.468-1.335-.804-2.385-.906-.99-.088-1.875.058-2.265.394zM12 7.615c-.24 0-.525.015-.84.044.03.16.045.336.06.526l-.001.159a2.94 2.94 0 01-.014.25c.225-.022.425-.027.612-.028h.366c.187 0 .387.006.612.028-.015-.146-.015-.277-.015-.409.015-.19.03-.365.06-.526a9.29 9.29 0 00-.84-.044z"></path></svg>',
    "kiro": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="100%" height="100%"><path d="M18.8 0H5.2A5.2 5.2 0 000 5.2v13.6A5.2 5.2 0 005.2 24h13.6a5.2 5.2 0 005.2-5.2V5.2A5.2 5.2 0 0018.8 0z" fill="#9046FF"></path><path d="M7.97 16.376c-1.644 3.642 1.86 4.556 4.443 2.424.76 2.39 3.608.607 4.631-1.247 2.251-4.084 1.342-8.249 1.108-9.108-1.6-5.859-9.6-5.869-10.976.03-.323 1.033-.328 2.206-.507 3.423-.09.617-.16 1.009-.393 1.655-.139.373-.323.7-.62 1.257-.458.865-.264 2.53 2.101 1.665l.224-.1h-.01l-.001.001z" fill="#fff"></path><path d="M12.722 10.985c-.656 0-.755-.785-.755-1.252 0-.423.074-.756.218-.97a.61.61 0 01.537-.283c.229 0 .428.095.567.289.159.218.243.55.243.964 0 .785-.303 1.252-.805 1.252h-.005zm2.703 0c-.656 0-.755-.785-.755-1.252 0-.423.074-.756.219-.97a.61.61 0 01.536-.283c.229 0 .428.095.567.289.159.218.243.55.243.964 0 .785-.303 1.252-.805 1.252h-.005z" fill="#000"></path></svg>',
    "cline": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="100%" height="100%"><path d="M17.035 3.991c2.75 0 4.98 2.24 4.98 5.003v1.667l1.45 2.896a1.01 1.01 0 01-.002.909l-1.448 2.864v1.668c0 2.762-2.23 5.002-4.98 5.002H7.074c-2.751 0-4.98-2.24-4.98-5.002V17.33l-1.48-2.855a1.01 1.01 0 01-.003-.927l1.482-2.887V8.994c0-2.763 2.23-5.003 4.98-5.003h9.962zM8.265 9.6a2.274 2.274 0 00-2.274 2.274v4.042a2.274 2.274 0 004.547 0v-4.042A2.274 2.274 0 008.265 9.6zm7.326 0a2.274 2.274 0 00-2.274 2.274v4.042a2.274 2.274 0 104.548 0v-4.042A2.274 2.274 0 0015.59 9.6z"></path><path d="M12.054 5.558a2.779 2.779 0 100-5.558 2.779 2.779 0 000 5.558z"></path></svg>',
    "qwen": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="100%" height="100%"><path d="M19.713 2.825h-5.907c0-.251-.066-.503-.196-.728L12.819.728A1.46 1.46 0 0 0 11.559 0h-1.58c-.52 0-1 .275-1.26.728l-2.42 4.19a1.45 1.45 0 0 0 0 1.453l.791 1.37c.26.448.74.727 1.26.727h11.36c.52 0 1-.275 1.26-.728l.79-1.37a1.45 1.45 0 0 0 0-1.451l-.79-1.37a1.46 1.46 0 0 0-1.26-.728zM.195 9.905l2.951 5.115a1.46 1.46 0 0 0-.531.531l-.791 1.37a1.45 1.45 0 0 0 0 1.452l.79 1.37c.26.448.74.727 1.26.727h4.84c.52 0 1-.275 1.26-.728l.79-1.37a1.45 1.45 0 0 0 0-1.451L5.086 7.083a1.46 1.46 0 0 0-1.26-.728h-1.58c-.52 0-1 .276-1.26.728l-.79 1.37a1.45 1.45 0 0 0 0 1.452m15.888 13.367 2.951-5.115c.217.125.469.196.728.196h1.582c.52 0 1-.275 1.26-.728l.79-1.37a1.45 1.45 0 0 0 0-1.451l-2.42-4.191a1.46 1.46 0 0 0-1.259-.728h-1.582c-.52 0-1 .276-1.259.728l-5.678 9.838a1.45 1.45 0 0 0 0 1.452l.79 1.37c.26.448.74.727 1.26.727h1.582c.52 0 1-.275 1.26-.728z" fill="#082dff"></path></svg>'
  };

  // src/content/agent.ts
  (() => {
    if (window.__acm) return;
    let nextRef = 1;
    const refToEl = /* @__PURE__ */ new Map();
    const elToRef = /* @__PURE__ */ new WeakMap();
    const refOf = (el) => {
      let r = elToRef.get(el);
      if (!r) {
        r = `ref_${nextRef++}`;
        elToRef.set(el, r);
        refToEl.set(r, new WeakRef(el));
      }
      return r;
    };
    const elOf = (ref) => {
      const el = refToEl.get(ref)?.deref();
      if (!el || !el.isConnected) throw new Error(`Element ${ref} is gone (the page changed). Call read_page or find again.`);
      return el;
    };
    const INPUT_ROLES = {
      button: "button",
      submit: "button",
      reset: "button",
      image: "button",
      checkbox: "checkbox",
      radio: "radio",
      range: "slider",
      number: "spinbutton",
      search: "searchbox",
      email: "textbox",
      tel: "textbox",
      text: "textbox",
      url: "textbox",
      password: "textbox",
      date: "textbox",
      "datetime-local": "textbox",
      month: "textbox",
      time: "textbox",
      week: "textbox",
      color: "button",
      file: "button"
    };
    const TAG_ROLES = {
      button: "button",
      select: "combobox",
      textarea: "textbox",
      img: "img",
      svg: "img",
      h1: "heading",
      h2: "heading",
      h3: "heading",
      h4: "heading",
      h5: "heading",
      h6: "heading",
      nav: "navigation",
      main: "main",
      header: "banner",
      footer: "contentinfo",
      aside: "complementary",
      form: "form",
      table: "table",
      tr: "row",
      td: "cell",
      th: "columnheader",
      ul: "list",
      ol: "list",
      li: "listitem",
      dialog: "dialog",
      summary: "button",
      details: "group",
      option: "option",
      iframe: "iframe",
      label: "label",
      fieldset: "group",
      legend: "legend",
      article: "article",
      section: "region",
      p: "paragraph",
      video: "video",
      audio: "audio",
      canvas: "canvas",
      hr: "separator",
      progress: "progressbar",
      meter: "meter",
      menu: "list",
      dl: "list",
      dt: "term",
      dd: "definition",
      code: "code",
      pre: "code",
      blockquote: "blockquote"
    };
    const INTERACTIVE = /* @__PURE__ */ new Set([
      "button",
      "link",
      "textbox",
      "searchbox",
      "checkbox",
      "radio",
      "combobox",
      "listbox",
      "slider",
      "spinbutton",
      "switch",
      "tab",
      "menuitem",
      "menuitemcheckbox",
      "menuitemradio",
      "option",
      "treeitem"
    ]);
    function roleOf(el) {
      const explicit = el.getAttribute("role");
      if (explicit) return explicit.split(" ")[0];
      const tag = el.tagName.toLowerCase();
      if (tag === "a") return el.hasAttribute("href") ? "link" : "generic";
      if (tag === "input") return INPUT_ROLES[el.type] ?? "textbox";
      if (tag === "section" && !(el.getAttribute("aria-label") || el.getAttribute("aria-labelledby"))) return "generic";
      if (el.isContentEditable && el.getAttribute("contenteditable") !== null) return "textbox";
      return TAG_ROLES[tag] ?? "generic";
    }
    const clean = (s, max = 100) => {
      const t = (s ?? "").replace(/\s+/g, " ").trim();
      return t.length > max ? `${t.slice(0, max - 1)}\u2026` : t;
    };
    function nameOf(el, role) {
      const aria = el.getAttribute("aria-label");
      if (aria) return clean(aria);
      const by = el.getAttribute("aria-labelledby");
      if (by) {
        const t = by.split(/\s+/).map((id) => el.ownerDocument.getElementById(id)?.textContent ?? "").join(" ");
        if (t.trim()) return clean(t);
      }
      const tag = el.tagName.toLowerCase();
      if (tag === "input" || tag === "textarea" || tag === "select") {
        const id = el.id;
        if (id) {
          const lab = el.ownerDocument.querySelector(`label[for="${CSS.escape(id)}"]`);
          if (lab?.textContent?.trim()) return clean(lab.textContent);
        }
        const wrap = el.closest("label");
        if (wrap?.textContent?.trim()) return clean(wrap.textContent);
        const inp = el;
        if (["button", "submit", "reset"].includes(inp.type) && inp.value) return clean(inp.value);
        return clean(el.getAttribute("placeholder") || el.getAttribute("title") || el.getAttribute("name") || "");
      }
      if (tag === "img") return clean(el.getAttribute("alt") || el.getAttribute("title") || "");
      if (tag === "svg") return clean(el.querySelector("title")?.textContent || "");
      if (tag === "iframe") return clean(el.getAttribute("title") || el.getAttribute("src") || "");
      if (["button", "link", "heading", "tab", "menuitem", "option", "listitem", "cell", "columnheader", "label", "legend", "paragraph", "term", "definition", "code", "blockquote", "checkbox", "radio", "switch", "treeitem"].includes(role)) {
        return clean(el.innerText ?? el.textContent, role === "paragraph" ? 300 : 100) || clean(el.getAttribute("title"));
      }
      return clean(el.getAttribute("title") || "");
    }
    function isHidden(el) {
      if (el.getAttribute("aria-hidden") === "true") return true;
      const he = el;
      if (he.hidden) return true;
      const cs = getComputedStyle(el);
      if (cs.display === "none" || cs.visibility === "hidden" || cs.visibility === "collapse") return true;
      if (cs.opacity === "0" && !INTERACTIVE.has(roleOf(el))) return true;
      return false;
    }
    function rectOf(el) {
      const r = el.getBoundingClientRect();
      let x = r.left;
      let y = r.top;
      let w = el.ownerDocument.defaultView;
      while (w && w !== window && w.frameElement) {
        const fr = w.frameElement.getBoundingClientRect();
        x += fr.left;
        y += fr.top;
        w = w.parent;
      }
      return { x, y, width: r.width, height: r.height };
    }
    const inViewport = (r) => r.width > 0 && r.height > 0 && r.x + r.width > 0 && r.y + r.height > 0 && r.x < innerWidth && r.y < innerHeight;
    function describe(el, role, name) {
      const bits = [role];
      if (name) bits.push(JSON.stringify(name));
      bits.push(`[${refOf(el)}]`);
      const tag = el.tagName.toLowerCase();
      if (role === "heading") bits.push(`level=${tag.match(/h(\d)/)?.[1] ?? el.getAttribute("aria-level") ?? ""}`);
      if (tag === "a" && el.href) {
        const href = el.getAttribute("href");
        bits.push(`href=${JSON.stringify(href.length > 120 ? `${href.slice(0, 119)}\u2026` : href)}`);
      }
      if (tag === "input" || tag === "textarea") {
        const inp = el;
        if (inp.type === "checkbox" || inp.type === "radio") bits.push(inp.checked ? "checked" : "unchecked");
        else if (inp.type === "password") bits.push(inp.value ? 'value="\u2022\u2022\u2022\u2022"' : "empty");
        else if (inp.type !== "button" && inp.type !== "submit") bits.push(`value=${JSON.stringify(clean(inp.value, 200))}`);
        if (inp.placeholder && !name.includes(inp.placeholder)) bits.push(`placeholder=${JSON.stringify(clean(inp.placeholder))}`);
        if (inp.type && !["text", "textarea"].includes(inp.type)) bits.push(`type=${inp.type}`);
      }
      if (tag === "select") {
        const sel = el;
        bits.push(`value=${JSON.stringify(clean(sel.selectedOptions[0]?.text ?? ""))}`);
        bits.push(`options=${JSON.stringify([...sel.options].slice(0, 25).map((o) => clean(o.text, 40)))}`);
      }
      const ariaChecked = el.getAttribute("aria-checked");
      if (ariaChecked) bits.push(`checked=${ariaChecked}`);
      const expanded = el.getAttribute("aria-expanded");
      if (expanded) bits.push(`expanded=${expanded}`);
      const selected = el.getAttribute("aria-selected");
      if (selected === "true") bits.push("selected");
      if (el.disabled || el.getAttribute("aria-disabled") === "true") bits.push("disabled");
      if (el === el.ownerDocument.activeElement) bits.push("focused");
      return bits.join(" ");
    }
    function* childrenOf(el) {
      const host2 = el;
      if (host2.shadowRoot) yield* Array.from(host2.shadowRoot.children);
      if (host2.tagName === "IFRAME") {
        try {
          const doc = host2.contentDocument;
          if (doc?.body) yield doc.body;
        } catch {
        }
      }
      if (host2.tagName === "SLOT") {
        yield* host2.assignedElements();
        return;
      }
      yield* Array.from(el.children);
    }
    function readPage(args) {
      const interactiveOnly = args.filter === "interactive";
      const maxDepth = args.depth ?? 25;
      const maxChars = args.max_chars ?? 5e4;
      const root = args.ref_id ? elOf(args.ref_id) : document.body;
      const lines = [];
      let chars = 0;
      let truncated = false;
      const walk = (el, depth) => {
        if (truncated) return;
        if (["SCRIPT", "STYLE", "NOSCRIPT", "TEMPLATE", "HEAD", "META", "LINK"].includes(el.tagName)) return;
        if (el.id === "__acm_overlay_host") return;
        if (isHidden(el)) return;
        const role = roleOf(el);
        let shown = false;
        if (role !== "generic") {
          const name = nameOf(el, role);
          const interesting = interactiveOnly ? INTERACTIVE.has(role) || el.onclick !== null || el.getAttribute("tabindex") === "0" : !(role === "listitem" && !name) && !(["paragraph", "label", "img"].includes(role) && !name);
          if (interesting) {
            const r = rectOf(el);
            if (!args.viewportOnly || inViewport(r)) {
              const line = `${"  ".repeat(Math.min(depth, maxDepth))}- ${describe(el, role, name)}`;
              if (chars + line.length > maxChars) {
                truncated = true;
                return;
              }
              lines.push(line);
              chars += line.length + 1;
              shown = true;
            }
          }
          if (["button", "link", "heading", "option", "paragraph", "label", "code", "checkbox", "radio"].includes(role) && shown) return;
        } else if (!interactiveOnly && el.children.length === 0) {
          const t = clean(el.innerText ?? el.textContent, 200);
          if (t && (!args.viewportOnly || inViewport(rectOf(el)))) {
            const line = `${"  ".repeat(Math.min(depth, maxDepth))}- text ${JSON.stringify(t)}`;
            if (chars + line.length > maxChars) {
              truncated = true;
              return;
            }
            lines.push(line);
            chars += line.length + 1;
          }
          return;
        } else if (!interactiveOnly && el.children.length > 0) {
          for (const n of Array.from(el.childNodes)) {
            if (n.nodeType === 3) {
              const t = clean(n.textContent, 200);
              if (t) {
                lines.push(`${"  ".repeat(Math.min(depth, maxDepth))}- text ${JSON.stringify(t)}`);
                chars += t.length + 12;
              }
            }
          }
        }
        if (depth >= maxDepth) return;
        for (const c of childrenOf(el)) walk(c, shown ? depth + 1 : depth);
      };
      walk(root, 0);
      const header = `Page: ${document.title}
URL: ${location.href}
Viewport: ${innerWidth}x${innerHeight}, scrolled to (${Math.round(scrollX)}, ${Math.round(scrollY)}) of ${document.documentElement.scrollWidth}x${document.documentElement.scrollHeight}
`;
      return header + lines.join("\n") + (truncated ? `
\u2026 output truncated at ${maxChars} chars. Use ref_id to read a subtree, filter="interactive", or viewportOnly.` : "");
    }
    const ROLE_WORDS = {
      button: ["button", "btn"],
      link: ["link", "anchor"],
      textbox: ["input", "field", "textbox", "box", "text", "textarea"],
      searchbox: ["search", "input", "field", "box"],
      checkbox: ["checkbox", "check", "toggle"],
      radio: ["radio", "option"],
      combobox: ["select", "dropdown", "combobox", "menu"],
      heading: ["heading", "title", "header"],
      img: ["image", "img", "picture", "logo", "icon"],
      tab: ["tab"],
      menuitem: ["menu", "item"],
      switch: ["switch", "toggle"]
    };
    function find(args) {
      const q = args.query.toLowerCase();
      const tokens = q.split(/[^a-z0-9@._-]+/).filter((t) => t.length > 1 && !["the", "a", "an", "of", "on", "in", "to", "for", "and", "with", "that", "this"].includes(t));
      const results = [];
      const visit = (el) => {
        if (["SCRIPT", "STYLE", "NOSCRIPT", "TEMPLATE"].includes(el.tagName) || el.id === "__acm_overlay_host") return;
        if (isHidden(el)) return;
        const role = roleOf(el);
        if (role !== "generic" || el.children.length === 0 && (el.textContent ?? "").trim()) {
          const name = nameOf(el, role) || clean(el.innerText, 100);
          const hay = [
            name,
            el.getAttribute("placeholder"),
            el.getAttribute("aria-label"),
            el.getAttribute("title"),
            el.getAttribute("name"),
            el.id,
            el.getAttribute("type"),
            el.getAttribute("alt"),
            typeof el.className === "string" ? el.className : "",
            el.getAttribute("data-testid")
          ].filter(Boolean).join(" ").toLowerCase();
          let score = 0;
          if (name && name.toLowerCase() === q) score += 12;
          if (name && q.includes(name.toLowerCase()) && name.length > 2) score += 4;
          for (const t of tokens) {
            if (hay.includes(t)) score += name.toLowerCase().includes(t) ? 3 : 1.5;
            if ((ROLE_WORDS[role] ?? []).includes(t)) score += 2.5;
          }
          if (INTERACTIVE.has(role)) score += 0.5;
          if (score > 0) results.push({ el, score, role, name });
        }
        for (const c of childrenOf(el)) visit(c);
      };
      visit(document.body);
      results.sort((a, b) => b.score - a.score);
      const picked = [];
      for (const r of results) {
        if (picked.length >= (args.limit ?? 20)) break;
        if (picked.some((p) => p.el.contains(r.el) && p.score >= r.score && p.role === "generic")) continue;
        picked.push(r);
      }
      return picked.map((r) => ({ ref: refOf(r.el), role: r.role, name: r.name, rect: rectOf(r.el), score: Math.round(r.score * 10) / 10 }));
    }
    function scrollIntoViewIfNeeded(el) {
      const r = rectOf(el);
      if (!inViewport(r) || r.y < 0 || r.y + r.height > innerHeight) el.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    }
    function refRect(args) {
      const el = elOf(args.ref);
      if (args.scroll !== false) scrollIntoViewIfNeeded(el);
      const r = rectOf(el);
      return { ...r, cx: r.x + r.width / 2, cy: r.y + r.height / 2, tag: el.tagName.toLowerCase() };
    }
    const setNative = (el, value) => {
      const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, "value").set.call(el, value);
    };
    function formInput(args) {
      const el = elOf(args.ref);
      scrollIntoViewIfNeeded(el);
      el.focus?.();
      const fire = (type) => el.dispatchEvent(new Event(type, { bubbles: true }));
      if (el instanceof HTMLSelectElement) {
        const v = String(args.value);
        const opt = [...el.options].find((o) => o.value === v) ?? [...el.options].find((o) => o.text.trim().toLowerCase() === v.toLowerCase()) ?? [...el.options].find((o) => o.text.toLowerCase().includes(v.toLowerCase()));
        if (!opt) throw new Error(`No option matching "${v}". Options: ${[...el.options].map((o) => o.text.trim()).join(", ")}`);
        el.value = opt.value;
        fire("input");
        fire("change");
        return `Selected "${opt.text.trim()}"`;
      }
      if (el instanceof HTMLInputElement && (el.type === "checkbox" || el.type === "radio")) {
        const want = typeof args.value === "boolean" ? args.value : !["false", "0", "off", "no", ""].includes(String(args.value).toLowerCase());
        if (el.checked !== want) el.click();
        return `${el.type} is now ${el.checked ? "checked" : "unchecked"}`;
      }
      if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
        setNative(el, String(args.value));
        el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: String(args.value) }));
        fire("change");
        return `Set value to ${JSON.stringify(String(args.value))}`;
      }
      if (el.isContentEditable) {
        el.textContent = String(args.value);
        el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: String(args.value) }));
        return "Set text content";
      }
      const role = el.getAttribute("role");
      if (role === "checkbox" || role === "switch") {
        const want = Boolean(args.value) && String(args.value) !== "false";
        if (el.getAttribute("aria-checked") === "true" !== want) el.click();
        return `${role} toggled`;
      }
      throw new Error(`${el.tagName.toLowerCase()} is not a form control. Use computer type instead.`);
    }
    function pageText(args) {
      const max = args.max_chars ?? 5e4;
      const candidates = ["article", "main", "[role=main]", "#content", ".content", "body"];
      let best = document.body;
      for (const sel of candidates) {
        const el = document.querySelector(sel);
        if (el && (el.innerText?.length ?? 0) > 200) {
          best = el;
          break;
        }
      }
      let text = (best.innerText ?? "").replace(/\n{3,}/g, "\n\n").trim();
      const truncated = text.length > max;
      if (truncated) text = text.slice(0, max);
      return `Title: ${document.title}
URL: ${location.href}

${text}${truncated ? `
\u2026 truncated at ${max} chars` : ""}`;
    }
    async function waitFor(args) {
      const deadline = Date.now() + Math.min(args.timeoutMs ?? 1e4, 6e4);
      const check = () => {
        const body = document.body?.innerText ?? "";
        if (args.text && !body.includes(args.text)) return false;
        if (args.textGone && body.includes(args.textGone)) return false;
        if (args.selector && !document.querySelector(args.selector)) return false;
        return true;
      };
      while (Date.now() < deadline) {
        if (check()) return { ok: true };
        await new Promise((r) => setTimeout(r, 150));
      }
      return { ok: check() };
    }
    const b64ToFile = (f) => {
      const bin = atob(f.base64);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return new File([bytes], f.name, { type: f.mimeType || "application/octet-stream" });
    };
    function setFiles(args) {
      const dt = new DataTransfer();
      for (const f of args.files) dt.items.add(b64ToFile(f));
      if (args.ref) {
        const el = elOf(args.ref);
        if (el instanceof HTMLInputElement && el.type === "file") {
          el.files = dt.files;
          el.dispatchEvent(new Event("input", { bubbles: true }));
          el.dispatchEvent(new Event("change", { bubbles: true }));
          return `Attached ${args.files.length} file(s) to the file input`;
        }
        const inner = el.querySelector('input[type="file"]');
        if (inner) {
          inner.files = dt.files;
          inner.dispatchEvent(new Event("change", { bubbles: true }));
          return `Attached ${args.files.length} file(s) to the file input inside ${args.ref}`;
        }
        return dropOn(el, dt, rectOf(el).x + 5, rectOf(el).y + 5);
      }
      const target = document.elementFromPoint(args.x ?? 0, args.y ?? 0);
      if (!target) throw new Error("Nothing at that coordinate to drop on");
      return dropOn(target, dt, args.x ?? 0, args.y ?? 0);
    }
    function dropOn(el, dt, x, y) {
      for (const type of ["dragenter", "dragover", "drop"]) {
        el.dispatchEvent(new DragEvent(type, { bubbles: true, cancelable: true, dataTransfer: dt, clientX: x, clientY: y }));
      }
      return `Dropped ${dt.files.length} file(s) on ${el.tagName.toLowerCase()}`;
    }
    let host = null;
    let shadow = null;
    let hideTimer;
    let recTimer;
    function ensureOverlay() {
      if (host?.isConnected) return shadow;
      host = document.createElement("div");
      host.id = "__acm_overlay_host";
      host.style.cssText = "all:initial;position:fixed;inset:0;pointer-events:none;z-index:2147483647;";
      if (/Mac/i.test(navigator.platform) && Math.abs(window.outerHeight - screen.height) > 2) host.style.setProperty("--acm-r", "0 0 18px 18px");
      shadow = host.attachShadow({ mode: "closed" });
      shadow.innerHTML = `<style>
      :host{all:initial}
      .frame{position:fixed;inset:0;pointer-events:none;opacity:0;transition:opacity .4s cubic-bezier(.2,.8,.2,1)}
      .frame.on{opacity:1}
      .frame::before{content:"";position:absolute;inset:0;border:5px solid #2F6BFF;border-radius:var(--acm-r,0)}
      .frame::after{content:"";position:absolute;inset:0;border-radius:var(--acm-r,0);box-shadow:inset 0 0 0 5px rgba(47,107,255,.35),inset 0 0 28px 8px rgba(47,107,255,.55),inset 0 0 110px 16px rgba(47,107,255,.2);animation:breathe 2.2s ease-in-out infinite}
      @keyframes breathe{0%,100%{opacity:.45}50%{opacity:1}}
      .pill{position:fixed;left:50%;bottom:20px;transform:translate(-50%,10px) scale(.98);display:flex;align-items:center;gap:10px;height:36px;padding:0 5px 0 14px;border-radius:999px;
        background:rgba(14,14,16,.88);color:#FAFAFA;font:500 13px/1 "Inter","SF Pro Text",ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;letter-spacing:-.01em;
        box-shadow:0 0 0 1px rgba(255,255,255,.09),0 1px 0 0 rgba(255,255,255,.06) inset,0 12px 32px -8px rgba(0,0,0,.55);
        backdrop-filter:blur(16px) saturate(160%);-webkit-backdrop-filter:blur(16px) saturate(160%);
        pointer-events:auto;opacity:0;transition:opacity .3s cubic-bezier(.2,.8,.2,1),transform .3s cubic-bezier(.2,.8,.2,1)}
      .pill.on{opacity:1;transform:translate(-50%,0) scale(1)}
      .dot{position:relative;width:7px;height:7px;border-radius:50%;background:#2F6BFF}
      .dot::after{content:"";position:absolute;inset:-4px;border-radius:50%;background:rgba(47,107,255,.35);animation:halo 1.6s ease-out infinite}
      .rec .dot{background:#FF453A}.rec .dot::after{background:rgba(255,69,58,.35)}
      .paused .dot{background:#A1A1AA}.paused .dot::after{animation:none;opacity:0}
      @keyframes halo{0%{transform:scale(.6);opacity:1}100%{transform:scale(1.8);opacity:0}}
      .ag{display:none;position:relative;box-sizing:border-box;width:24px;height:24px;margin-left:-8px;border-radius:7px;background:#fff;color:#0A0A0B;flex:none;place-items:center;box-shadow:0 0 0 1px rgba(255,255,255,.12)}
      .ag.on{display:grid}
      .ag svg{display:block;width:15px;height:15px}
      .ag.on~.label{margin-left:-1px}
      .pill.has-ag .dot{position:absolute;left:25px;top:25px;width:8px;height:8px;box-shadow:0 0 0 2px rgba(14,14,16,1);z-index:1}
      .pill.has-ag .dot::after{inset:-3px}
      .rec-time{font-variant-numeric:tabular-nums;color:#A1A1AA;font-size:12px}
      .rec-time:empty{display:none}
      button{all:unset;cursor:pointer;height:26px;padding:0 11px;border-radius:999px;background:rgba(255,255,255,.08);color:#FAFAFA;font-weight:500;font-size:12px;display:inline-flex;align-items:center;
        box-shadow:0 0 0 1px rgba(255,255,255,.08) inset;transition:background .15s}
      button:hover{background:rgba(255,255,255,.16)}
      :host([data-pass]) *{pointer-events:none!important}
      :host([data-clean]) .frame,:host([data-clean]) .pill,:host([data-clean]) .ripple{display:none!important}
      .ripple{position:fixed;width:26px;height:26px;margin:-13px 0 0 -13px;border-radius:50%;border:2px solid #2F6BFF;background:rgba(47,107,255,.18);pointer-events:none;animation:rip .55s cubic-bezier(.2,.8,.2,1) forwards}
      @keyframes rip{from{transform:scale(.4);opacity:1}to{transform:scale(1.7);opacity:0}}
    </style><div class="frame"></div><div class="pill"><span class="dot"></span><span class="ag"></span><span class="label"></span><span class="rec-time"></span><button class="stop">Stop</button></div>`;
      shadow.querySelector(".stop").addEventListener("click", (e) => {
        e.stopPropagation();
        const paused = shadow.querySelector(".pill").classList.contains("paused");
        chrome.runtime.sendMessage({ type: paused ? "acm:resume" : "acm:stop" });
      });
      (document.documentElement ?? document.body).appendChild(host);
      return shadow;
    }
    function setClean(on) {
      if (!host) return;
      if (on) host.setAttribute("data-clean", "");
      else host.removeAttribute("data-clean");
    }
    function overlay(args) {
      const sh = ensureOverlay();
      setClean(Boolean(args.clean));
      const frame = sh.querySelector(".frame");
      const pill = sh.querySelector(".pill");
      const label = sh.querySelector(".label");
      const btn = sh.querySelector(".stop");
      const recTime = sh.querySelector(".rec-time");
      clearTimeout(hideTimer);
      if (recTimer) clearInterval(recTimer);
      recTime.textContent = "";
      pill.classList.toggle("rec", Boolean(args.rec));
      pill.classList.toggle("paused", args.state === "paused");
      if (args.rec) {
        const since = args.rec.since;
        const tick = () => {
          const s = Math.floor((Date.now() - since) / 1e3);
          recTime.textContent = `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
        };
        tick();
        recTimer = setInterval(tick, 1e3);
      }
      if (args.state === "hidden") {
        frame.classList.remove("on");
        pill.classList.remove("on");
        return true;
      }
      label.textContent = args.label ?? "Agent is working";
      const ag = sh.querySelector(".ag");
      const icon = args.agent ? AGENT_ICONS[args.agent] : void 0;
      ag.classList.toggle("on", Boolean(icon));
      pill.classList.toggle("has-ag", Boolean(icon));
      if (icon && ag.dataset.k !== args.agent) {
        ag.innerHTML = icon;
        ag.dataset.k = args.agent;
      }
      btn.textContent = args.state === "paused" ? "Resume" : "Stop";
      if (args.state === "working" || args.state === "paused") {
        frame.classList.toggle("on", args.state === "working");
        pill.classList.add("on");
      } else {
        hideTimer = setTimeout(() => {
          frame.classList.remove("on");
          if (!args.rec) pill.classList.remove("on");
        }, args.linger ?? 1500);
      }
      return true;
    }
    function passThrough(args) {
      ensureOverlay();
      if (args.on) host.setAttribute("data-pass", "");
      else host.removeAttribute("data-pass");
      return true;
    }
    function setOverlayVisible(args) {
      if (host) host.style.visibility = args.visible ? "visible" : "hidden";
      return true;
    }
    function ripple(args) {
      const sh = ensureOverlay();
      if (host?.hasAttribute("data-clean")) return true;
      const r = document.createElement("div");
      r.className = "ripple";
      r.style.left = `${args.x}px`;
      r.style.top = `${args.y}px`;
      sh.appendChild(r);
      setTimeout(() => r.remove(), 700);
      return true;
    }
    const ARROW = '<svg viewBox="0 0 24 24" width="24" height="24"><path d="M5.5 3.2v15.6c0 .7.8 1 1.3.5l3.6-3.5 2.7 6c.2.4.7.6 1.1.4l2-.9c.4-.2.6-.7.4-1.1l-2.7-5.9h5.2c.7 0 1-.8.5-1.3L6.8 2.7c-.5-.5-1.3-.2-1.3.5z" fill="#2F6BFF" stroke="#fff" stroke-width="1.6" stroke-linejoin="round"/></svg>';
    const HAND = '<svg viewBox="0 0 24 24" width="24" height="24"><path d="M9 11.5V4.8a1.6 1.6 0 0 1 3.2 0v5.4l.2-.9a1.5 1.5 0 0 1 3 .3v.9a1.5 1.5 0 0 1 3 .2v.8a1.5 1.5 0 0 1 3 .3v4.4c0 3.3-2.4 6.3-6 6.3h-1.6c-2 0-3.4-.8-4.6-2.3l-3.4-4.3a1.6 1.6 0 0 1 2.4-2.1z" fill="#2F6BFF" stroke="#fff" stroke-width="1.5" stroke-linejoin="round"/></svg>';
    const BEAM = '<svg viewBox="0 0 24 24" width="24" height="24"><path d="M9 3.5h2c.6 0 1 .4 1 1 0-.6.4-1 1-1h2M12 4.5v15M9 20.5h2c.6 0 1-.4 1-1 0 .6.4 1 1 1h2" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round"/><path d="M9 3.5h2c.6 0 1 .4 1 1 0-.6.4-1 1-1h2M12 4.5v15M9 20.5h2c.6 0 1-.4 1-1 0 .6.4 1 1 1h2" fill="none" stroke="#2F6BFF" stroke-width="1.8" stroke-linecap="round"/></svg>';
    const N_ARROW = '<svg viewBox="0 0 24 24" width="24" height="24"><path d="M5.5 3.2v15.6c0 .7.8 1 1.3.5l3.6-3.5 2.7 6c.2.4.7.6 1.1.4l2-.9c.4-.2.6-.7.4-1.1l-2.7-5.9h5.2c.7 0 1-.8.5-1.3L6.8 2.7c-.5-.5-1.3-.2-1.3.5z" fill="#000" stroke="#fff" stroke-width="1.5" stroke-linejoin="round"/></svg>';
    const N_HAND = '<svg viewBox="0 0 24 24" width="24" height="24"><path d="M9 11.5V4.8a1.6 1.6 0 0 1 3.2 0v5.4l.2-.9a1.5 1.5 0 0 1 3 .3v.9a1.5 1.5 0 0 1 3 .2v.8a1.5 1.5 0 0 1 3 .3v4.4c0 3.3-2.4 6.3-6 6.3h-1.6c-2 0-3.4-.8-4.6-2.3l-3.4-4.3a1.6 1.6 0 0 1 2.4-2.1z" fill="#fff" stroke="#000" stroke-width="1.3" stroke-linejoin="round"/><path d="M12.2 10.5v4M15.4 11v3.5M18.4 11.5v3" stroke="#000" stroke-width="1.1" stroke-linecap="round"/></svg>';
    const N_BEAM = '<svg viewBox="0 0 24 24" width="24" height="24"><path d="M9 3.5h2c.6 0 1 .4 1 1 0-.6.4-1 1-1h2M12 4.5v15M9 20.5h2c.6 0 1-.4 1-1 0 .6.4 1 1 1h2" fill="none" stroke="#fff" stroke-width="3.6" stroke-linecap="round"/><path d="M9 3.5h2c.6 0 1 .4 1 1 0-.6.4-1 1-1h2M12 4.5v15M9 20.5h2c.6 0 1-.4 1-1 0 .6.4 1 1 1h2" fill="none" stroke="#000" stroke-width="1.5" stroke-linecap="round"/></svg>';
    let skin = "agent";
    let cur = null;
    let curIdle;
    function ensureCursor(label, agent) {
      const sh = ensureOverlay();
      if (!cur || !cur.el.isConnected) {
        const style = document.createElement("style");
        style.textContent = `
        .acur{position:fixed;left:0;top:0;width:24px;height:24px;pointer-events:none;opacity:0;will-change:transform;transition:opacity .25s ease;filter:drop-shadow(0 2px 6px rgba(47,107,255,.45)) drop-shadow(0 1px 1px rgba(0,0,0,.25))}
        .acur.on{opacity:1}
        .acur .ic{position:absolute;inset:0;transform-origin:5px 3px;transition:transform .12s cubic-bezier(.2,.8,.2,1)}
        .acur .ic.hand{transform-origin:10px 4px}.acur .ic.text{transform-origin:12px 12px}
        .acur.down .ic{transform:scale(.82)}
        .acur .tg{position:absolute;left:20px;top:20px;display:flex;align-items:center;gap:6px;box-sizing:border-box;height:23px;padding:0 9px;border-radius:7px 999px 999px 999px;background:#2F6BFF;color:#fff;white-space:nowrap;
          font:600 11.5px/1.25 "Inter","SF Pro Text",ui-sans-serif,system-ui,-apple-system,sans-serif;letter-spacing:-.01em;box-shadow:0 0 0 1.5px #fff,0 4px 12px -2px rgba(47,107,255,.5)}
        .acur .tg i{display:grid;place-items:center;box-sizing:border-box;width:17px;height:17px;margin:-1px 0 -1px -5px;border-radius:5px;background:#fff;color:#0A0A0B;flex:none}
        .acur .tg i svg{display:block;width:12px;height:12px}
        .acur.grab .ic{transform:scale(.92)}
        .acur.natural{filter:drop-shadow(0 1px 1.5px rgba(0,0,0,.35))}
        .acur.natural .tg{display:none}
        .acur.hidden-skin{display:none}`;
        sh.appendChild(style);
        const el = document.createElement("div");
        el.className = "acur";
        el.setAttribute("aria-hidden", "true");
        const icon2 = document.createElement("div");
        icon2.className = "ic";
        const tag = document.createElement("div");
        tag.className = "tg";
        el.append(icon2, tag);
        sh.appendChild(el);
        cur = { el, icon: icon2, tag, x: innerWidth * 0.62, y: innerHeight * 0.55, kind: "" };
        el.style.transform = `translate(${cur.x - 5}px, ${cur.y - 3}px)`;
      }
      const icon = agent ? AGENT_ICONS[agent] : void 0;
      const key = `${agent ?? ""}|${label}`;
      if (cur.tag.dataset.k !== key) {
        cur.tag.dataset.k = key;
        cur.tag.innerHTML = icon ? `<i>${icon}</i>` : "";
        cur.tag.append(document.createTextNode(label));
      }
      return cur;
    }
    function cursorKind(x, y) {
      const el = document.elementFromPoint(x, y);
      if (!el) return "arrow";
      const c = getComputedStyle(el).cursor;
      if (c === "pointer") return "hand";
      if (c === "text" || c === "vertical-text") return "text";
      if (c === "auto" || c === "default") {
        if (el.closest("a[href],button,summary,label,select,[role=button],[role=link],[role=tab],[role=menuitem],[role=option],[role=checkbox],[role=switch]")) return "hand";
        if (el.closest('input:not([type=checkbox]):not([type=radio]):not([type=button]):not([type=submit]):not([type=range]):not([type=file]),textarea,[contenteditable=""],[contenteditable=true]')) return "text";
      }
      return "arrow";
    }
    function setKind(c, kind) {
      if (c.kind === `${skin}:${kind}`) return;
      c.kind = `${skin}:${kind}`;
      c.icon.className = `ic ${kind}`;
      const nat = skin === "natural";
      c.icon.innerHTML = kind === "hand" ? nat ? N_HAND : HAND : kind === "text" ? nat ? N_BEAM : BEAM : nat ? N_ARROW : ARROW;
      c.el.dataset.hx = kind === "hand" ? "10" : kind === "text" ? "12" : "5";
      c.el.dataset.hy = kind === "hand" ? "4" : kind === "text" ? "12" : "3";
    }
    const place = (c, x, y, rot = 0, sx = 1) => {
      c.el.style.transform = `translate(${x - Number(c.el.dataset.hx ?? 5)}px, ${y - Number(c.el.dataset.hy ?? 3)}px) rotate(${rot}deg) scale(${sx})`;
    };
    async function cursorTo(args) {
      skin = args.skin ?? "agent";
      const c = ensureCursor(args.label ?? "Agent", args.agent);
      c.el.classList.toggle("natural", skin === "natural");
      c.el.classList.toggle("hidden-skin", skin === "hidden");
      setClean(skin !== "agent");
      clearTimeout(curIdle);
      curIdle = setTimeout(() => c.el.classList.remove("on"), 15e3);
      const wasOn = c.el.classList.contains("on");
      c.el.classList.toggle("grab", Boolean(args.grab));
      if (args.grab) setKind(c, "hand");
      c.el.classList.add("on");
      const fromX = c.x;
      const fromY = c.y;
      const dx = args.x - fromX;
      const dy = args.y - fromY;
      const dist = Math.hypot(dx, dy);
      const visible = document.visibilityState === "visible";
      if (!visible || dist < 2 || !wasOn) {
        if (!args.grab) setKind(c, cursorKind(args.x, args.y));
        if (!wasOn && visible && dist >= 2) {
          place(c, args.x - Math.sign(dx || 1) * 40, args.y - Math.sign(dy || 1) * 30);
          await new Promise((r) => requestAnimationFrame(r));
          c.x = args.x - Math.sign(dx || 1) * 40;
          c.y = args.y - Math.sign(dy || 1) * 30;
          return cursorTo(args);
        }
        c.x = args.x;
        c.y = args.y;
        place(c, c.x, c.y);
      } else {
        const dur = args.durationMs ?? Math.min(420, Math.max(160, 140 + dist * 0.38));
        const bend = Math.min(60, dist * 0.18) * (dx >= 0 ? -1 : 1);
        const cx = fromX + dx / 2 - dy / (dist || 1) * bend;
        const cy = fromY + dy / 2 + dx / (dist || 1) * bend;
        const tilt = Math.max(-12, Math.min(12, dx / 25));
        const start = performance.now();
        await new Promise((resolve) => {
          const step = (now) => {
            const t = Math.min(1, (now - start) / dur);
            const e = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
            const u = 1 - e;
            const x = u * u * fromX + 2 * u * e * cx + e * e * args.x;
            const y = u * u * fromY + 2 * u * e * cy + e * e * args.y;
            const s = Math.sin(Math.PI * t);
            if (t > 0.6 && !args.grab) setKind(c, cursorKind(args.x, args.y));
            place(c, x, y, tilt * s, 1 - 0.06 * s);
            c.x = x;
            c.y = y;
            if (t < 1) requestAnimationFrame(step);
            else resolve();
          };
          requestAnimationFrame(step);
        });
        c.x = args.x;
        c.y = args.y;
        if (!args.grab) setKind(c, cursorKind(args.x, args.y));
        place(c, c.x, c.y);
      }
      if (args.press) {
        c.el.classList.add("down");
        setTimeout(() => c.el.classList.remove("down"), 140);
      }
      return true;
    }
    function cursorHide() {
      if (cur) cur.el.classList.remove("on");
      return true;
    }
    function viewport() {
      return { width: innerWidth, height: innerHeight, dpr: devicePixelRatio, scrollX, scrollY, url: location.href, title: document.title };
    }
    function elementAt(args) {
      const el = document.elementFromPoint(args.x, args.y);
      if (!el) return null;
      const role = roleOf(el);
      return { ref: refOf(el), tag: el.tagName.toLowerCase(), role, name: nameOf(el, role) || clean(el.innerText, 60) };
    }
    function markUpload(args) {
      const el = elOf(args.ref);
      const isFile = (x) => x instanceof HTMLInputElement && x.type === "file";
      const label = el instanceof HTMLLabelElement ? el : el.closest("label");
      const target = isFile(el) && el || label && isFile(label.control) && label.control || el.querySelector('input[type="file"]') || // Styled upload buttons usually sit next to a hidden input.
      el.parentElement?.querySelector('input[type="file"]') || el;
      const token = Math.random().toString(36).slice(2);
      target.setAttribute("data-acm-up", token);
      setTimeout(() => target.removeAttribute("data-acm-up"), 1e4);
      const isInput = target instanceof HTMLInputElement && target.type === "file";
      return { token, isInput, multiple: isInput && target.multiple, accept: isInput ? target.accept : "" };
    }
    const fns = {
      readPage,
      find,
      refRect,
      formInput,
      pageText,
      waitFor,
      setFiles,
      overlay,
      setOverlayVisible,
      ripple,
      viewport,
      elementAt,
      cursorTo,
      cursorHide,
      markUpload,
      passThrough,
      ping: () => true
    };
    window.__acm = {
      run(name, args) {
        const f = fns[name];
        if (!f) throw new Error(`unknown content function ${name}`);
        return f(args ?? {});
      }
    };
  })();
})();
