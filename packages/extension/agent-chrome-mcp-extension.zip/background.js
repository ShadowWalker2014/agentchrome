// ../protocol/src/tools.ts
var browser = {
  type: "string",
  description: "Which connected Chrome profile to use (id or name from list_browsers). Optional: defaults to the browser selected with select_browser, else the most recently active one."
};
var tabId = {
  type: "number",
  description: "Tab ID from tabs_context. Optional: defaults to this session's current tab (created inside the session tab group if none exists)."
};
var coord = {
  type: "array",
  items: { type: "number" },
  minItems: 2,
  maxItems: 2,
  description: "[x, y] in screenshot pixels (same space as the last screenshot of this tab)."
};
var obj = (properties, required = []) => ({
  type: "object",
  properties: { ...properties, browser },
  required,
  additionalProperties: false
});
var TOOLS = [
  {
    name: "list_browsers",
    title: "List connected browsers",
    server: true,
    description: "List the Chrome profiles paired with this account, with online status. Each Chrome profile that installs the extension and pairs shows up as its own browser.",
    inputSchema: { type: "object", properties: {}, additionalProperties: false },
    annotations: { readOnlyHint: true }
  },
  {
    name: "select_browser",
    title: "Select browser",
    server: true,
    description: "Choose which paired Chrome profile this session controls by default. Pass the id or name from list_browsers.",
    inputSchema: {
      type: "object",
      properties: { browser: { type: "string", description: "Browser id or name." } },
      required: ["browser"],
      additionalProperties: false
    }
  },
  {
    name: "pairing_code",
    title: "Get a pairing code",
    server: true,
    description: "Get a one-time code to connect a Chrome profile to this account. Give the user the code with these steps: install the Agent Chrome extension (download link in the result), click its toolbar icon, paste the code and press Connect. Use this when list_browsers shows no browser, or the user wants to add another Chrome profile.",
    inputSchema: { type: "object", properties: {}, additionalProperties: false }
  },
  {
    name: "tabs_context",
    title: "Get session tabs",
    description: "Get the tabs in this session's Chrome tab group (id, url, title, active). Call this first to get a valid tabId. Each agent session gets its own tab group so its work stays separate from the user's tabs. Set createIfEmpty to open a blank tab in a new group when there is none. Set all=true to list every open tab in the browser.",
    inputSchema: obj({
      createIfEmpty: { type: "boolean", description: "Create the group with a new tab if the session has none. Default true." },
      all: { type: "boolean", description: "List every tab in the browser, not only this session's group." }
    }),
    annotations: { readOnlyHint: true }
  },
  {
    name: "tabs_create",
    title: "Open tab",
    description: "Open a new tab inside this session's tab group and make it the session's current tab. Optionally load a URL.",
    inputSchema: obj({
      url: { type: "string", description: "URL to open. Default about:blank." },
      active: { type: "boolean", description: "Focus the tab in its window. Default false (work happens in the background)." }
    })
  },
  {
    name: "tabs_close",
    title: "Close tab",
    description: "Close a tab. Only tabs in this session's group can be closed unless force is true.",
    inputSchema: obj({ tabId: { ...tabId, description: "Tab to close." }, force: { type: "boolean" } }, ["tabId"]),
    annotations: { destructiveHint: true }
  },
  {
    name: "tabs_select",
    title: "Switch tab",
    description: "Make a tab this session's current tab. Pass adopt=true to move a user's tab into the session group. Pass focus=true to also bring it to the front.",
    inputSchema: obj({ tabId: { ...tabId, description: "Tab to switch to." }, adopt: { type: "boolean" }, focus: { type: "boolean" } }, ["tabId"])
  },
  {
    name: "tab_groups",
    title: "Manage tab groups",
    description: "List, create, rename, recolor, collapse or ungroup Chrome tab groups. action=list returns every group. action=update changes title/color/collapsed of a group (defaults to this session's group). action=create groups the given tabIds (or the current tab) into a new group. action=ungroup removes tabs from their group. action=move moves tabIds into a group.",
    inputSchema: obj(
      {
        action: { type: "string", enum: ["list", "create", "update", "ungroup", "move"] },
        groupId: { type: "number", description: "Target group. Default: this session's group." },
        tabIds: { type: "array", items: { type: "number" } },
        title: { type: "string", description: "New group name." },
        color: { type: "string", enum: ["grey", "blue", "red", "yellow", "green", "pink", "purple", "cyan", "orange"] },
        collapsed: { type: "boolean" },
        makeSessionGroup: { type: "boolean", description: "With create/move: make this the session's group from now on." }
      },
      ["action"]
    )
  },
  {
    name: "navigate",
    title: "Navigate",
    description: "Load a URL in a tab and wait for it to finish loading. Use 'back' or 'forward' for history navigation, 'reload' to reload.",
    inputSchema: obj({ url: { type: "string" }, tabId, timeoutMs: { type: "number", description: "Max wait for load. Default 30000." } }, ["url"]),
    timeoutMs: 6e4
  },
  {
    name: "computer",
    title: "Mouse, keyboard and screenshots",
    description: [
      "Use a mouse and keyboard to interact with the page, and take screenshots.",
      "Coordinates are in the pixel space of the latest screenshot of that tab. Take a screenshot first.",
      "Prefer clicking with ref (from read_page or find) over coordinates when you have one.",
      "Actions: screenshot, left_click, right_click, middle_click, double_click, triple_click, hover or mouse_move (moves the pointer without clicking), left_click_drag (start_coordinate or start_ref -> coordinate or ref; native HTML5 drag and drop works), type (text), key (text like 'Enter', 'cmd+a', 'ctrl+shift+t'; space-separated for sequences), scroll (scroll_direction, scroll_amount), scroll_to (ref), wait (duration seconds), zoom (region screenshot at full resolution)."
    ].join(" "),
    inputSchema: obj(
      {
        action: {
          type: "string",
          enum: [
            "screenshot",
            "left_click",
            "right_click",
            "middle_click",
            "double_click",
            "triple_click",
            "hover",
            "mouse_move",
            "left_click_drag",
            "type",
            "key",
            "scroll",
            "scroll_to",
            "wait",
            "zoom"
          ]
        },
        coordinate: coord,
        start_coordinate: { ...coord, description: "[x, y] drag start for left_click_drag." },
        start_ref: { type: "string", description: "Element ref to start a drag from (alternative to start_coordinate)." },
        ref: { type: "string", description: "Element ref from read_page/find, e.g. 'ref_12'. Alternative to coordinate." },
        text: { type: "string", description: "Text to type (type) or keys to press (key)." },
        modifiers: { type: "string", description: "Modifier keys held during a click: ctrl, shift, alt, cmd; combine with '+'." },
        scroll_direction: { type: "string", enum: ["up", "down", "left", "right"] },
        scroll_amount: { type: "number", minimum: 1, maximum: 20, description: "Scroll ticks. Default 3." },
        duration: { type: "number", minimum: 0, maximum: 30, description: "Seconds to wait." },
        repeat: { type: "number", minimum: 1, maximum: 100, description: "Repeat count for key." },
        region: { type: "array", items: { type: "number" }, minItems: 4, maxItems: 4, description: "[x0, y0, x1, y1] for zoom." },
        tabId
      },
      ["action"]
    ),
    timeoutMs: 6e4
  },
  {
    name: "screenshot",
    title: "Screenshot",
    description: "Capture a screenshot of a tab. fullPage captures the whole scrollable page. Set save=true to also store it and get a download URL.",
    inputSchema: obj({
      tabId,
      fullPage: { type: "boolean" },
      format: { type: "string", enum: ["jpeg", "png"], description: "Default jpeg." },
      save: { type: "boolean", description: "Upload and return a download URL (cloud) or a file path (local)." }
    }),
    annotations: { readOnlyHint: true }
  },
  {
    name: "read_page",
    title: "Read accessibility tree",
    description: "Get an accessibility-tree view of the page: each element's role, name and a ref like 'ref_12' usable in computer, form_input, file_upload and scroll_to. filter='interactive' returns only buttons, links and inputs. Output is limited to max_chars (default 50000).",
    inputSchema: obj({
      tabId,
      filter: { type: "string", enum: ["interactive", "all"], description: "Default all." },
      depth: { type: "number", description: "Max tree depth. Default 25." },
      ref_id: { type: "string", description: "Scope to the subtree under this ref." },
      max_chars: { type: "number" },
      viewportOnly: { type: "boolean", description: "Only elements visible in the viewport." }
    }),
    annotations: { readOnlyHint: true }
  },
  {
    name: "find",
    title: "Find elements",
    description: "Find elements matching a description, e.g. 'search box', 'Sign in button', 'price of the first result'. Returns up to 20 matches with refs and screenshot coordinates.",
    inputSchema: obj({ query: { type: "string" }, tabId, limit: { type: "number" } }, ["query"]),
    annotations: { readOnlyHint: true }
  },
  {
    name: "form_input",
    title: "Set form value",
    description: "Set the value of a form control by ref: text inputs and textareas (string), checkboxes and radios (boolean), selects (option value or visible text), contenteditable (string). Fires input and change events like a user would.",
    inputSchema: obj(
      { ref: { type: "string" }, value: { type: ["string", "number", "boolean"] }, tabId },
      ["ref", "value"]
    )
  },
  {
    name: "get_page_text",
    title: "Get page text",
    description: "Get the readable text of the page (article or main content when present), plus title and URL.",
    inputSchema: obj({ tabId, max_chars: { type: "number", description: "Default 50000." } }),
    annotations: { readOnlyHint: true }
  },
  {
    name: "javascript_tool",
    title: "Run JavaScript",
    description: "Run JavaScript in the page's main world and return the value of the last expression (await is allowed). Runs even on pages with a strict CSP. Do not return huge objects.",
    inputSchema: obj(
      {
        text: { type: "string", description: "JavaScript code." },
        action: { type: "string", enum: ["javascript_exec"], description: "Optional, for Claude in Chrome compatibility." },
        tabId
      },
      ["text"]
    ),
    timeoutMs: 6e4
  },
  {
    name: "read_console_messages",
    title: "Read console",
    description: "Read console messages and uncaught errors from a tab, captured since the agent first touched it. Filter with a regex pattern.",
    inputSchema: obj({
      tabId,
      pattern: { type: "string" },
      onlyErrors: { type: "boolean" },
      clear: { type: "boolean" },
      limit: { type: "number", description: "Default 100." }
    }),
    annotations: { readOnlyHint: true }
  },
  {
    name: "read_network_requests",
    title: "Read network requests",
    description: "Read HTTP requests made by a tab (url, method, status, type, timing), captured since the agent first touched it. Filter by urlPattern (substring or regex).",
    inputSchema: obj({
      tabId,
      urlPattern: { type: "string" },
      clear: { type: "boolean" },
      limit: { type: "number", description: "Default 100." },
      includeBodies: { type: "boolean", description: "Include response bodies of up to 10 KB for XHR/fetch requests." }
    }),
    annotations: { readOnlyHint: true }
  },
  {
    name: "resize_window",
    title: "Resize window",
    description: "Resize the browser window that holds the tab.",
    inputSchema: obj({ width: { type: "number" }, height: { type: "number" }, tabId }, ["width", "height"])
  },
  {
    name: "file_upload",
    title: "Upload files",
    description: "Put files into a file input or a drop zone without the native file picker. Give ref (the file input, its upload button or a drop zone from read_page), or leave ref out to fill a file picker the page just tried to open (click results tell you when). Pass paths (absolute paths on the computer running Chrome; the page gets real files) or files (each with base64, url or a screenshot imageId).",
    inputSchema: obj({
      ref: { type: "string", description: "File input, upload button or drop zone. Omit to fill a file picker that a click opened." },
      paths: { type: "array", items: { type: "string" }, description: "Absolute file paths on the computer running Chrome." },
      files: {
        type: "array",
        items: {
          type: "object",
          properties: {
            name: { type: "string" },
            mimeType: { type: "string" },
            base64: { type: "string" },
            url: { type: "string" },
            imageId: { type: "string", description: "id returned by a screenshot." }
          },
          required: ["name"]
        }
      },
      tabId
    }),
    timeoutMs: 6e4
  },
  {
    name: "upload_image",
    title: "Upload screenshot",
    description: "Upload a captured screenshot (imageId) into a file input (ref) or drop it on a target (coordinate).",
    inputSchema: obj(
      { imageId: { type: "string" }, ref: { type: "string" }, coordinate: coord, filename: { type: "string" }, tabId },
      ["imageId"]
    )
  },
  {
    name: "record",
    title: "Record video",
    description: "Record a video clip of a tab. action=start begins, action=stop finishes and returns a download URL (cloud) or file path (local) for an MP4 or WebM file, action=status reports progress. The clip looks like a person using the page: the blue border, status pill and the cursor's name tag are left out, and the cursor is a normal arrow that turns into a hand over links and an I-beam over text (cursor=natural, the default). Use cursor=agent to show the agent cursor and indicators, or cursor=hidden for no cursor. The toolbar icon shows REC meanwhile. Max length 10 minutes.",
    inputSchema: obj(
      {
        action: { type: "string", enum: ["start", "stop", "status"] },
        tabId,
        fps: { type: "number", description: "Frames per second, default 15." },
        format: { type: "string", enum: ["mp4", "webm"], description: "Default mp4 when Chrome supports it." },
        filename: { type: "string" },
        download: { type: "boolean", description: "Also save into the browser's Downloads folder." },
        cursor: { type: "string", enum: ["natural", "agent", "hidden"], description: "How the cursor looks in the clip. Default natural." },
        showClicks: { type: "boolean", description: "Draw a soft ripple where clicks land. Default false." }
      },
      ["action"]
    ),
    timeoutMs: 12e4
  },
  {
    name: "gif_creator",
    title: "Record GIF",
    description: "Record browser actions and export an animated GIF. action=start_recording, stop_recording, export (returns the GIF), clear.",
    inputSchema: obj(
      {
        action: { type: "string", enum: ["start_recording", "stop_recording", "export", "clear"] },
        cursor: { type: "string", enum: ["natural", "agent", "hidden"], description: "How the cursor looks in the GIF. Default natural." },
        showClicks: { type: "boolean", description: "Draw click ripples. Default false." },
        tabId,
        filename: { type: "string" },
        download: { type: "boolean" }
      },
      ["action"]
    ),
    timeoutMs: 12e4
  },
  {
    name: "wait_for",
    title: "Wait for page condition",
    description: "Wait until text appears, a CSS selector matches, text disappears, or the URL matches. Returns as soon as the condition holds or fails after timeoutMs.",
    inputSchema: obj({
      tabId,
      text: { type: "string" },
      textGone: { type: "string" },
      selector: { type: "string" },
      urlIncludes: { type: "string" },
      timeoutMs: { type: "number", description: "Default 10000, max 60000." }
    }),
    timeoutMs: 7e4,
    annotations: { readOnlyHint: true }
  },
  {
    name: "handle_dialog",
    title: "Handle dialog",
    description: "Accept or dismiss a JavaScript alert/confirm/prompt/beforeunload dialog on a tab. Dialogs block the page until handled; tool results mention an open dialog.",
    inputSchema: obj({ accept: { type: "boolean" }, promptText: { type: "string" }, tabId }, ["accept"])
  },
  {
    name: "history_search",
    title: "Search browsing history",
    description: "Search this Chrome profile's browsing history. Works only when the user turned on history access in the extension popup.",
    inputSchema: obj({ query: { type: "string" }, maxResults: { type: "number" }, daysBack: { type: "number" } }, ["query"]),
    annotations: { readOnlyHint: true }
  }
];
var READ_ONLY = /* @__PURE__ */ new Set(["list_browsers", "tabs_context", "screenshot", "read_page", "find", "get_page_text", "read_console_messages", "read_network_requests", "wait_for", "history_search"]);
for (const t of TOOLS) {
  t.annotations = {
    title: t.title,
    readOnlyHint: READ_ONLY.has(t.name),
    destructiveHint: t.name === "tabs_close",
    idempotentHint: READ_ONLY.has(t.name),
    openWorldHint: !t.server
  };
}
var TOOL_BY_NAME = new Map(TOOLS.map((t) => [t.name, t]));

// ../protocol/src/mcp.ts
var SUPPORTED_PROTOCOL_VERSIONS = ["2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05"];
var LATEST_PROTOCOL_VERSION = SUPPORTED_PROTOCOL_VERSIONS[0];
var enc = new TextEncoder();

// ../protocol/src/wire.ts
var WS_SUBPROTOCOL = "agent-chrome-mcp.v1";
var WS_TOKEN_PREFIX = "acm-token.";

// ../protocol/src/agents.ts
var KNOWN = [
  [/claude/i, { key: "claude", name: "Claude Code" }],
  [/codex|openai/i, { key: "codex", name: "Codex" }],
  [/antigravity|\bagy\b|jetski/i, { key: "antigravity", name: "Antigravity" }],
  [/gemini/i, { key: "gemini", name: "Gemini" }],
  [/grok|xai/i, { key: "grok", name: "Grok" }],
  [/muse|meta/i, { key: "muse", name: "Muse" }],
  [/cursor/i, { key: "cursor", name: "Cursor" }],
  [/opencode/i, { key: "opencode", name: "opencode" }],
  [/windsurf|cascade|codeium/i, { key: "windsurf", name: "Windsurf" }],
  [/copilot|vscode|visual studio code/i, { key: "copilot", name: "Copilot" }],
  [/kiro/i, { key: "kiro", name: "Kiro" }],
  [/cline|roo/i, { key: "cline", name: "Cline" }],
  [/qwen/i, { key: "qwen", name: "Qwen Code" }]
];
function agentFor(client) {
  for (const [re, info] of KNOWN) if (re.test(client)) return info;
  const base = client.replace(/[-_ ]?(mcp)?[-_ ]?client$/i, "").replace(/[-_]+/g, " ").trim() || "Agent";
  return { key: "", name: base.replace(/\b\w/g, (c) => c.toUpperCase()) };
}

// src/background/settings.ts
var DEFAULTS = { askNewSites: false, allowedHosts: [], blockedHosts: [], showOverlay: true, showCursor: true };
async function getSettings() {
  const { settings } = await chrome.storage.local.get("settings");
  return { ...DEFAULTS, ...settings };
}
async function setSettings(patch) {
  const s = { ...await getSettings(), ...patch };
  await chrome.storage.local.set({ settings: s });
  return s;
}
async function getConnection() {
  const { connection } = await chrome.storage.local.get("connection");
  return connection ?? {};
}
async function setConnection(c) {
  await chrome.storage.local.set({ connection: c });
}
var hostOf = (url) => {
  try {
    const u = new URL(url ?? "");
    return u.protocol === "http:" || u.protocol === "https:" ? u.hostname : "";
  } catch {
    return "";
  }
};
var matches = (host, pattern) => host === pattern || host.endsWith(`.${pattern.replace(/^\*\./, "")}`);
var pendingPrompts = /* @__PURE__ */ new Map();
function resolvePrompt(id, v) {
  pendingPrompts.get(id)?.(v);
  pendingPrompts.delete(id);
}
var allowedOnce = /* @__PURE__ */ new Set();
async function gate(url, client) {
  const host = hostOf(url);
  if (!host) return;
  const s = await getSettings();
  if (s.blockedHosts.some((p) => matches(host, p))) throw new Error(`${host} is blocked in the Agent Chrome MCP extension settings.`);
  if (!s.askNewSites || s.allowedHosts.some((p) => matches(host, p)) || allowedOnce.has(host)) return;
  const id = crypto.randomUUID();
  const answer = await new Promise((resolve) => {
    pendingPrompts.set(id, resolve);
    chrome.windows.create({
      url: chrome.runtime.getURL(`prompt.html?id=${id}&host=${encodeURIComponent(host)}&client=${encodeURIComponent(client)}`),
      type: "popup",
      width: 420,
      height: 300,
      focused: true
    });
    setTimeout(() => {
      if (pendingPrompts.has(id)) resolvePrompt(id, "deny");
    }, 12e4);
  });
  if (answer === "deny") throw new Error(`The user declined access to ${host}.`);
  if (answer === "always") await setSettings({ allowedHosts: [...s.allowedHosts, host] });
  else allowedOnce.add(host);
}

// src/background/sessions.ts
var COLORS = ["blue", "cyan", "purple", "green", "orange", "pink", "yellow", "red"];
function prettyClient(client) {
  return agentFor(client).name;
}
var cache = null;
async function load() {
  if (!cache) {
    cache = (await chrome.storage.local.get("sessions")).sessions ?? {};
    await reconcile(cache);
  }
  return cache;
}
async function save() {
  if (cache) await chrome.storage.local.set({ sessions: cache });
}
async function reconcile(all) {
  for (const [id, s] of Object.entries(all)) {
    if (Date.now() - s.lastActive > 864e5) {
      delete all[id];
      continue;
    }
    if (s.groupId !== void 0 && !await groupAlive(s.groupId)) s.groupId = void 0;
    if (s.currentTabId !== void 0 && !await chrome.tabs.get(s.currentTabId).catch(() => null)) s.currentTabId = void 0;
  }
  await chrome.storage.local.set({ sessions: all });
}
chrome.tabGroups.onRemoved.addListener(async (group) => {
  const all = await load();
  let changed = false;
  for (const s of Object.values(all)) {
    if (s.groupId === group.id) {
      s.groupId = void 0;
      s.currentTabId = void 0;
      changed = true;
    }
  }
  if (changed) await save();
});
async function getSession(info) {
  const all = await load();
  let s = all[info.id];
  if (!s) {
    const pretty = prettyClient(info.client);
    const sameClient = Object.values(all).filter((x) => x.client === info.client).length;
    s = {
      id: info.id,
      client: info.client,
      agent: agentFor(info.client).key,
      title: sameClient ? `${pretty} ${sameClient + 1}` : pretty,
      color: COLORS[Object.keys(all).length % COLORS.length],
      lastActive: Date.now()
    };
    all[info.id] = s;
    const claimed = new Set(Object.values(all).map((x) => x.groupId).filter((g) => g !== void 0));
    const orphan = (await chrome.tabGroups.query({ title: s.title })).find((g) => !claimed.has(g.id));
    if (orphan) {
      s.groupId = orphan.id;
      s.windowId = orphan.windowId;
      s.currentTabId = (await chrome.tabs.query({ groupId: orphan.id }))[0]?.id;
    }
    for (const [k, v] of Object.entries(all)) if (Date.now() - v.lastActive > 864e5) delete all[k];
  }
  s.lastActive = Date.now();
  await save();
  return s;
}
async function updateSession(s) {
  const all = await load();
  all[s.id] = s;
  await save();
}
async function allSessions() {
  return Object.values(await load());
}
async function sessionsForTab(tabId2) {
  const tab = await chrome.tabs.get(tabId2).catch(() => null);
  return (await allSessions()).filter((s) => s.currentTabId === tabId2 || tab && s.groupId !== void 0 && tab.groupId === s.groupId);
}
async function groupAlive(groupId) {
  if (groupId === void 0 || groupId < 0) return false;
  return chrome.tabGroups.get(groupId).then(() => true, () => false);
}
async function targetWindow(s) {
  if (s.windowId !== void 0) {
    const w2 = await chrome.windows.get(s.windowId).catch(() => null);
    if (w2 && w2.type === "normal") return w2.id;
  }
  const w = await chrome.windows.getLastFocused({ windowTypes: ["normal"] }).catch(() => null);
  if (w?.id !== void 0 && w.type === "normal") return w.id;
  const all = await chrome.windows.getAll({ windowTypes: ["normal"] });
  if (all[0]?.id !== void 0) return all[0].id;
  const created = await chrome.windows.create({ focused: false, url: "about:blank" });
  return created.id;
}
async function ensureInGroup(s, tabId2) {
  const tab = await chrome.tabs.get(tabId2);
  if (await groupAlive(s.groupId)) {
    if (tab.groupId !== s.groupId) {
      const g = await chrome.tabGroups.get(s.groupId);
      if (g.windowId !== tab.windowId) await chrome.tabs.move(tabId2, { windowId: g.windowId, index: -1 });
      await chrome.tabs.group({ groupId: s.groupId, tabIds: [tabId2] });
    }
  } else {
    s.groupId = await chrome.tabs.group({ tabIds: [tabId2], createProperties: { windowId: tab.windowId } });
    await chrome.tabGroups.update(s.groupId, { title: s.title, color: s.color, collapsed: false });
  }
  s.windowId = tab.windowId;
  await updateSession(s);
  return s.groupId;
}
async function createTab(s, url = "about:blank", active = false) {
  let windowId = await targetWindow(s);
  if (await groupAlive(s.groupId)) windowId = (await chrome.tabGroups.get(s.groupId)).windowId;
  const tab = await chrome.tabs.create({ url, active, windowId });
  await ensureInGroup(s, tab.id);
  s.currentTabId = tab.id;
  await updateSession(s);
  return tab;
}
async function groupTabs(s) {
  if (!await groupAlive(s.groupId)) return [];
  return chrome.tabs.query({ groupId: s.groupId });
}
async function resolveTab(s, tabId2, createIfEmpty = true) {
  if (typeof tabId2 === "number") {
    await chrome.tabs.get(tabId2).catch(() => {
      throw new Error(`Tab ${tabId2} does not exist. Call tabs_context for valid tab IDs.`);
    });
    return tabId2;
  }
  if (s.currentTabId !== void 0) {
    const t = await chrome.tabs.get(s.currentTabId).catch(() => null);
    if (t) return t.id;
  }
  const inGroup = await groupTabs(s);
  if (inGroup[0]) {
    s.currentTabId = inGroup[0].id;
    await updateSession(s);
    return s.currentTabId;
  }
  if (!createIfEmpty) throw new Error("This session has no tabs yet. Call tabs_create or navigate first.");
  return (await createTab(s)).id;
}

// src/background/cdp.ts
var attached = /* @__PURE__ */ new Set();
var attaching = /* @__PURE__ */ new Map();
var tabs = /* @__PURE__ */ new Map();
var listeners = /* @__PURE__ */ new Set();
var MAX_ENTRIES = 1e3;
function state(tabId2) {
  let s = tabs.get(tabId2);
  if (!s) {
    s = { console: [], network: /* @__PURE__ */ new Map(), downloads: [], opened: [] };
    tabs.set(tabId2, s);
  }
  return s;
}
var fmtArg = (a) => {
  if (!a) return "";
  if (a.type === "string") return a.value;
  if ("value" in a) return JSON.stringify(a.value);
  if (a.unserializableValue) return a.unserializableValue;
  if (a.preview?.properties) {
    const props = a.preview.properties.map((p) => `${p.name}: ${p.value}`).join(", ");
    return a.subtype === "array" ? `[${props}]` : `{${props}}`;
  }
  return a.description ?? a.className ?? a.type;
};
chrome.debugger.onEvent.addListener((source, method, params) => {
  const tabId2 = source.tabId;
  if (tabId2 === void 0) return;
  const s = state(tabId2);
  switch (method) {
    case "Runtime.consoleAPICalled":
      s.console.push({
        level: params.type === "warning" ? "warn" : params.type,
        text: (params.args ?? []).map(fmtArg).join(" "),
        url: params.stackTrace?.callFrames?.[0]?.url,
        ts: Date.now()
      });
      break;
    case "Runtime.exceptionThrown": {
      const d = params.exceptionDetails;
      s.console.push({ level: "error", text: `Uncaught ${d.exception?.description ?? d.text}`, url: d.url, ts: Date.now() });
      break;
    }
    case "Log.entryAdded":
      s.console.push({ level: params.entry.level === "warning" ? "warn" : params.entry.level, text: params.entry.text, url: params.entry.url, ts: Date.now() });
      break;
    case "Page.frameNavigated":
      if (!params.frame.parentId) {
        s.mainFrameId = params.frame.id;
        s.crashed = false;
      }
      break;
    case "Page.fileChooserOpened":
      s.chooser = { backendNodeId: params.backendNodeId, mode: params.mode, ts: Date.now() };
      break;
    case "Page.windowOpen":
      s.opened.push({ url: params.url, ts: Date.now() });
      if (s.opened.length > 20) s.opened.shift();
      break;
    case "Page.downloadWillBegin":
      s.downloads.push({ name: params.suggestedFilename, ts: Date.now() });
      if (s.downloads.length > 20) s.downloads.shift();
      break;
    case "Inspector.targetCrashed":
      s.crashed = true;
      break;
    case "Network.requestWillBeSent":
      if (params.type === "Document" && (!s.mainFrameId || params.frameId === s.mainFrameId)) {
        s.doc = { url: params.request.url, ts: Date.now() };
      }
      s.network.set(params.requestId, {
        requestId: params.requestId,
        url: params.request.url,
        method: params.request.method,
        type: params.type,
        ts: Date.now()
      });
      break;
    case "Network.responseReceived": {
      const e = s.network.get(params.requestId);
      if (params.type === "Document" && s.doc && (!s.mainFrameId || params.frameId === s.mainFrameId)) s.doc.status = params.response.status;
      if (e) {
        e.status = params.response.status;
        e.mimeType = params.response.mimeType;
        e.type = params.type ?? e.type;
      }
      break;
    }
    case "Network.loadingFinished": {
      const e = s.network.get(params.requestId);
      if (e) e.durationMs = Date.now() - e.ts;
      break;
    }
    case "Network.loadingFailed": {
      const e = s.network.get(params.requestId);
      if (e) e.failed = params.errorText;
      if (params.type === "Document" && s.doc && e && e.url === s.doc.url && !params.canceled) s.doc.error = params.errorText;
      break;
    }
    case "Page.javascriptDialogOpening":
      s.dialog = { type: params.type, message: params.message, defaultPrompt: params.defaultPrompt };
      break;
    case "Page.javascriptDialogClosed":
      s.dialog = void 0;
      break;
  }
  if (s.console.length > MAX_ENTRIES) s.console.splice(0, s.console.length - MAX_ENTRIES);
  if (s.network.size > MAX_ENTRIES) {
    const first = s.network.keys().next().value;
    if (first) s.network.delete(first);
  }
  for (const l of listeners) l(tabId2, method, params);
});
chrome.debugger.onDetach.addListener((source, reason) => {
  if (source.tabId !== void 0) {
    attached.delete(source.tabId);
    if (reason === "canceled_by_user") {
      userDetached.add(source.tabId);
      for (const cb of cancelListeners) cb(source.tabId);
    }
  }
});
chrome.tabs.onRemoved.addListener((tabId2) => {
  attached.delete(tabId2);
  tabs.delete(tabId2);
});
var userDetached = /* @__PURE__ */ new Set();
var cancelListeners = /* @__PURE__ */ new Set();
function onUserCancel(cb) {
  cancelListeners.add(cb);
}
function onCdpEvent(l) {
  listeners.add(l);
  return () => listeners.delete(l);
}
async function attach(tabId2) {
  if (attached.has(tabId2)) return;
  const inflight2 = attaching.get(tabId2);
  if (inflight2) return inflight2;
  const p = (async () => {
    try {
      await chrome.debugger.attach({ tabId: tabId2 }, "1.3");
    } catch (e) {
      const msg = e.message ?? String(e);
      if (!/already attached/i.test(msg)) {
        throw new Error(`Cannot control this tab (${msg}). Chrome blocks extensions on chrome:// pages, the Chrome Web Store and other extensions.`);
      }
    }
    attached.add(tabId2);
    userDetached.delete(tabId2);
    await Promise.all([
      chrome.debugger.sendCommand({ tabId: tabId2 }, "Runtime.enable"),
      chrome.debugger.sendCommand({ tabId: tabId2 }, "Log.enable"),
      chrome.debugger.sendCommand({ tabId: tabId2 }, "Network.enable", { maxTotalBufferSize: 1e7 }),
      chrome.debugger.sendCommand({ tabId: tabId2 }, "Page.enable"),
      chrome.debugger.sendCommand({ tabId: tabId2 }, "Inspector.enable")
    ]).catch(() => {
    });
    const tree = await chrome.debugger.sendCommand({ tabId: tabId2 }, "Page.getFrameTree").catch(() => null);
    if (tree?.frameTree?.frame?.id) state(tabId2).mainFrameId = tree.frameTree.frame.id;
  })();
  attaching.set(tabId2, p);
  try {
    await p;
  } finally {
    attaching.delete(tabId2);
  }
}
async function send(tabId2, method, params) {
  await attach(tabId2);
  try {
    return await chrome.debugger.sendCommand({ tabId: tabId2 }, method, params);
  } catch (e) {
    const msg = e.message ?? String(e);
    if (/not attached|detached/i.test(msg)) {
      attached.delete(tabId2);
      await attach(tabId2);
      return await chrome.debugger.sendCommand({ tabId: tabId2 }, method, params);
    }
    throw new Error(`${method}: ${msg}`);
  }
}
var consoleOf = (tabId2) => state(tabId2).console;
var networkOf = (tabId2) => state(tabId2).network;
var dialogOf = (tabId2) => state(tabId2).dialog;
var clearDialog = (tabId2) => state(tabId2).dialog = void 0;
var chooserOf = (tabId2) => state(tabId2).chooser;
var clearChooser = (tabId2) => state(tabId2).chooser = void 0;
var docOf = (tabId2) => state(tabId2).doc;
var crashedOf = (tabId2) => Boolean(state(tabId2).crashed);
var downloadsOf = (tabId2) => state(tabId2).downloads;
var openedOf = (tabId2) => state(tabId2).opened;

// src/background/keys.ts
var defs = {};
var add = (names, d) => names.forEach((n) => defs[n.toLowerCase()] = d);
add(["enter", "return"], { key: "Enter", code: "Enter", keyCode: 13, text: "\r" });
add(["tab"], { key: "Tab", code: "Tab", keyCode: 9 });
add(["backspace"], { key: "Backspace", code: "Backspace", keyCode: 8 });
add(["delete", "del"], { key: "Delete", code: "Delete", keyCode: 46 });
add(["escape", "esc"], { key: "Escape", code: "Escape", keyCode: 27 });
add(["space", " "], { key: " ", code: "Space", keyCode: 32, text: " " });
add(["arrowup", "up"], { key: "ArrowUp", code: "ArrowUp", keyCode: 38 });
add(["arrowdown", "down"], { key: "ArrowDown", code: "ArrowDown", keyCode: 40 });
add(["arrowleft", "left"], { key: "ArrowLeft", code: "ArrowLeft", keyCode: 37 });
add(["arrowright", "right"], { key: "ArrowRight", code: "ArrowRight", keyCode: 39 });
add(["home"], { key: "Home", code: "Home", keyCode: 36 });
add(["end"], { key: "End", code: "End", keyCode: 35 });
add(["pageup"], { key: "PageUp", code: "PageUp", keyCode: 33 });
add(["pagedown"], { key: "PageDown", code: "PageDown", keyCode: 34 });
add(["insert"], { key: "Insert", code: "Insert", keyCode: 45 });
add(["shift"], { key: "Shift", code: "ShiftLeft", keyCode: 16, location: 1 });
add(["control", "ctrl"], { key: "Control", code: "ControlLeft", keyCode: 17, location: 1 });
add(["alt", "option"], { key: "Alt", code: "AltLeft", keyCode: 18, location: 1 });
add(["meta", "cmd", "command", "super", "win"], { key: "Meta", code: "MetaLeft", keyCode: 91, location: 1 });
for (let i = 1; i <= 12; i++) add([`f${i}`], { key: `F${i}`, code: `F${i}`, keyCode: 111 + i });
for (let c = 0; c < 26; c++) {
  const lower = String.fromCharCode(97 + c);
  add([lower], { key: lower, code: `Key${lower.toUpperCase()}`, keyCode: 65 + c, text: lower });
}
for (let d = 0; d <= 9; d++) add([String(d)], { key: String(d), code: `Digit${d}`, keyCode: 48 + d, text: String(d) });
var punct = [
  ["-", "Minus", 189],
  ["=", "Equal", 187],
  ["[", "BracketLeft", 219],
  ["]", "BracketRight", 221],
  ["\\", "Backslash", 220],
  [";", "Semicolon", 186],
  ["'", "Quote", 222],
  [",", "Comma", 188],
  [".", "Period", 190],
  ["/", "Slash", 191],
  ["`", "Backquote", 192]
];
for (const [k, code, kc] of punct) add([k], { key: k, code, keyCode: kc, text: k });
var MOD = { alt: 1, ctrl: 2, meta: 4, shift: 8 };
function modifierBits(mods) {
  let bits = 0;
  for (const m of mods.map((x) => x.toLowerCase())) {
    if (m === "alt" || m === "option") bits |= MOD.alt;
    else if (m === "ctrl" || m === "control") bits |= MOD.ctrl;
    else if (m === "cmd" || m === "meta" || m === "command" || m === "super" || m === "win") bits |= MOD.meta;
    else if (m === "shift") bits |= MOD.shift;
  }
  return bits;
}
var isModifier = (k) => ["shift", "ctrl", "control", "alt", "option", "cmd", "meta", "command", "super", "win"].includes(k.toLowerCase());
function parseCombo(combo) {
  const parts = combo === "+" ? ["+"] : combo.split("+").filter(Boolean);
  const keyName = parts.pop() ?? "";
  const modifiers = parts.filter(isModifier);
  let key = defs[keyName.toLowerCase()];
  if (!key) {
    if (keyName.length === 1) key = { key: keyName, code: "", keyCode: keyName.toUpperCase().charCodeAt(0), text: keyName };
    else throw new Error(`Unknown key "${keyName}"`);
  }
  if (keyName.length === 1 && keyName !== keyName.toLowerCase() && key.text) {
    key = { ...key, key: keyName, text: keyName };
    if (!modifiers.includes("shift")) modifiers.push("shift");
  }
  return { modifiers, key };
}
function editingCommands(mods, key) {
  const primary = mods & MOD.meta || mods & MOD.ctrl;
  if (!primary) return [];
  const k = key.toLowerCase();
  const shift = mods & MOD.shift;
  if (k === "a") return ["selectAll"];
  if (k === "c") return ["copy"];
  if (k === "x") return ["cut"];
  if (k === "v") return ["paste"];
  if (k === "z") return [shift ? "redo" : "undo"];
  if (k === "y") return ["redo"];
  return [];
}

// src/background/page.ts
async function content(tabId2, name, args = {}) {
  const call = () => chrome.scripting.executeScript({
    target: { tabId: tabId2 },
    func: async (n, a) => {
      const api = window.__acm;
      if (!api) return { missing: true };
      try {
        return { ok: true, value: await api.run(n, a) };
      } catch (e) {
        return { ok: false, error: String(e?.message ?? e) };
      }
    },
    args: [name, args]
  });
  let res;
  try {
    [res] = await call();
    if (res?.result?.missing) {
      await chrome.scripting.executeScript({ target: { tabId: tabId2 }, files: ["content.js"] });
      [res] = await call();
    }
  } catch (e) {
    throw new Error(`Cannot access this page (${e.message}).`);
  }
  const r = res?.result;
  if (!r) throw new Error("The page did not respond (it may be loading or blocked).");
  if (!r.ok) throw new Error(r.error);
  return r.value;
}
async function tryContent(tabId2, name, args = {}) {
  try {
    return await content(tabId2, name, args);
  } catch {
    return void 0;
  }
}
async function viewport(tabId2) {
  const r = await send(tabId2, "Runtime.evaluate", {
    expression: "({width: innerWidth, height: innerHeight, dpr: devicePixelRatio, scrollX, scrollY})",
    returnByValue: true
  });
  return r.result.value;
}
var shots = /* @__PURE__ */ new Map();
var images = /* @__PURE__ */ new Map();
var imageSeq = 0;
function targetScale(w, h) {
  return Math.min(1, 1568 / Math.max(w, h), Math.sqrt(115e4 / (w * h)));
}
function toCss(tabId2, x, y) {
  const s = shots.get(tabId2)?.scale ?? 1;
  return [x / s, y / s];
}
function toShot(tabId2, x, y) {
  const s = shots.get(tabId2)?.scale ?? 1;
  return [Math.round(x * s), Math.round(y * s)];
}
function b64ToBlob(b64, type) {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type });
}
async function blobToB64(blob) {
  const buf = new Uint8Array(await blob.arrayBuffer());
  let s = "";
  for (let i = 0; i < buf.length; i += 32768) s += String.fromCharCode(...buf.subarray(i, i + 32768));
  return btoa(s);
}
async function resize(b64, inType, width, height, outType, quality) {
  const bmp = await createImageBitmap(b64ToBlob(b64, inType));
  if (bmp.width === width && bmp.height === height && inType === outType) {
    bmp.close();
    return b64;
  }
  const canvas = new OffscreenCanvas(width, height);
  const ctx = canvas.getContext("2d");
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(bmp, 0, 0, width, height);
  bmp.close();
  return blobToB64(await canvas.convertToBlob({ type: outType, quality: quality / 100 }));
}
async function ensureRendered(tabId2) {
  const tab = await chrome.tabs.get(tabId2);
  if (!tab.active) {
    try {
      await send(tabId2, "Emulation.setFocusEmulationEnabled", { enabled: true });
    } catch {
    }
  }
  return tab;
}
async function captureRaw(tabId2, params) {
  const attempt = () => Promise.race([
    send(tabId2, "Page.captureScreenshot", params).then((r) => r.data),
    new Promise((r) => setTimeout(() => r(null), 4e3))
  ]);
  let data = await attempt();
  if (data === null) {
    await chrome.tabs.update(tabId2, { active: true });
    await new Promise((r) => setTimeout(r, 300));
    data = await attempt();
  }
  if (data === null) throw new Error("Screenshot timed out: the tab is not rendering. Make sure its window is not minimized.");
  return data;
}
async function screenshot(tabId2, opts = {}) {
  const format = opts.format ?? "jpeg";
  const quality = opts.quality ?? 80;
  const mimeType = format === "png" ? "image/png" : "image/jpeg";
  await ensureRendered(tabId2);
  const vp = await viewport(tabId2);
  if (opts.hideOverlay !== false) await tryContent(tabId2, "setOverlayVisible", { visible: false });
  let raw;
  let cssW = vp.width;
  let cssH = vp.height;
  try {
    if (opts.fullPage) {
      const m = await send(tabId2, "Page.getLayoutMetrics");
      const cs = m.cssContentSize ?? m.contentSize;
      cssW = Math.ceil(cs.width);
      cssH = Math.min(Math.ceil(cs.height), 16e3);
      raw = await captureRaw(tabId2, { format, quality, captureBeyondViewport: true, clip: { x: 0, y: 0, width: cssW, height: cssH, scale: 1 } });
    } else {
      raw = await captureRaw(tabId2, { format, quality });
    }
  } finally {
    if (opts.hideOverlay !== false) await tryContent(tabId2, "setOverlayVisible", { visible: true });
  }
  let scale = targetScale(cssW, cssH);
  if (opts.fullPage) scale = Math.min(1, 1280 / cssW);
  const width = Math.max(1, Math.round(cssW * scale));
  const height = Math.max(1, Math.round(cssH * scale));
  const base64 = await resize(raw, mimeType, width, height, mimeType, quality);
  if (!opts.fullPage) shots.set(tabId2, { scale, width, height });
  const imageId = `img_${++imageSeq}`;
  images.set(imageId, { base64, mimeType });
  if (images.size > 20) images.delete(images.keys().next().value);
  return { base64, mimeType, width, height, imageId, cssWidth: cssW, cssHeight: cssH };
}
async function zoom(tabId2, region) {
  const [x0, y0] = toCss(tabId2, region[0], region[1]);
  const [x1, y1] = toCss(tabId2, region[2], region[3]);
  const vp = await viewport(tabId2);
  await tryContent(tabId2, "setOverlayVisible", { visible: false });
  try {
    const raw = await captureRaw(tabId2, {
      format: "png",
      clip: { x: Math.min(x0, x1) + vp.scrollX, y: Math.min(y0, y1) + vp.scrollY, width: Math.abs(x1 - x0), height: Math.abs(y1 - y0), scale: 1 }
    });
    return raw;
  } finally {
    await tryContent(tabId2, "setOverlayVisible", { visible: true });
  }
}
async function mouseMove(tabId2, x, y, modifiers = 0) {
  await send(tabId2, "Input.dispatchMouseEvent", { type: "mouseMoved", x, y, modifiers });
}
async function click(tabId2, x, y, opts = {}) {
  const button = opts.button ?? "left";
  const count = opts.count ?? 1;
  const modifiers = opts.modifiers ?? 0;
  await send(tabId2, "Page.setInterceptFileChooserDialog", { enabled: true }).catch(() => {
  });
  try {
    await mouseMove(tabId2, x, y, modifiers);
    for (let i = 1; i <= count; i++) {
      await send(tabId2, "Input.dispatchMouseEvent", { type: "mousePressed", x, y, button, clickCount: i, modifiers, buttons: button === "left" ? 1 : button === "right" ? 2 : 4 });
      const opened = await untilDialog(tabId2, send(tabId2, "Input.dispatchMouseEvent", { type: "mouseReleased", x, y, button, clickCount: i, modifiers, buttons: 0 }));
      if (opened) return;
    }
    await new Promise((r) => setTimeout(r, 120));
  } finally {
    if (!dialogOf(tabId2)) await send(tabId2, "Page.setInterceptFileChooserDialog", { enabled: false }).catch(() => {
    });
  }
}
function untilDialog(tabId2, p) {
  return new Promise((resolve, reject) => {
    if (dialogOf(tabId2)) return resolve(true);
    const off = onCdpEvent((tid, method) => {
      if (tid === tabId2 && method === "Page.javascriptDialogOpening") {
        off();
        resolve(true);
      }
    });
    p.then(
      () => {
        off();
        resolve(false);
      },
      (e) => {
        off();
        reject(e);
      }
    );
  });
}
async function drag(tabId2, from, to, onStep) {
  let data = null;
  const off = onCdpEvent((tid, method, params) => {
    if (tid === tabId2 && method === "Input.dragIntercepted") data = params.data;
  });
  await send(tabId2, "Input.setInterceptDrags", { enabled: true }).catch(() => {
  });
  try {
    await mouseMove(tabId2, from[0], from[1]);
    await send(tabId2, "Input.dispatchMouseEvent", { type: "mousePressed", x: from[0], y: from[1], button: "left", clickCount: 1, buttons: 1 });
    const steps = 16;
    for (let i = 1; i <= steps; i++) {
      const x = from[0] + (to[0] - from[0]) * i / steps;
      const y = from[1] + (to[1] - from[1]) * i / steps;
      if (data) break;
      await send(tabId2, "Input.dispatchMouseEvent", { type: "mouseMoved", x, y, button: "left", buttons: 1 });
      onStep?.(x, y);
      await new Promise((r) => setTimeout(r, 18));
    }
    if (data) {
      for (const type of ["dragEnter", "dragOver"]) await send(tabId2, "Input.dispatchDragEvent", { type, x: to[0], y: to[1], data });
      await send(tabId2, "Input.dispatchDragEvent", { type: "drop", x: to[0], y: to[1], data });
      await send(tabId2, "Input.dispatchMouseEvent", { type: "mouseReleased", x: to[0], y: to[1], button: "left", clickCount: 1, buttons: 0 });
      return "html5";
    }
    await send(tabId2, "Input.dispatchMouseEvent", { type: "mouseReleased", x: to[0], y: to[1], button: "left", clickCount: 1, buttons: 0 });
    return "mouse";
  } finally {
    off();
    await send(tabId2, "Input.setInterceptDrags", { enabled: false }).catch(() => {
    });
  }
}
async function wheel(tabId2, x, y, dx, dy) {
  await send(tabId2, "Input.dispatchMouseEvent", { type: "mouseWheel", x, y, deltaX: dx, deltaY: dy });
}
async function pressCombo(tabId2, combo) {
  const { modifiers, key } = parseCombo(combo);
  const bits = modifierBits(modifiers);
  const order = ["ctrl", "alt", "shift", "cmd"];
  const held = order.filter((m) => m === "ctrl" ? bits & MOD.ctrl : m === "alt" ? bits & MOD.alt : m === "shift" ? bits & MOD.shift : bits & MOD.meta);
  let cur = 0;
  for (const m of held) {
    const d = parseCombo(m).key;
    cur |= modifierBits([m]);
    await send(tabId2, "Input.dispatchKeyEvent", { type: "rawKeyDown", key: d.key, code: d.code, windowsVirtualKeyCode: d.keyCode, modifiers: cur, location: d.location });
  }
  const printable = key.text && !(bits & (MOD.ctrl | MOD.meta | MOD.alt));
  const commands = editingCommands(bits, key.key);
  const down = send(tabId2, "Input.dispatchKeyEvent", {
    type: printable ? "keyDown" : "rawKeyDown",
    key: key.key,
    code: key.code,
    windowsVirtualKeyCode: key.keyCode,
    text: printable ? key.text : void 0,
    unmodifiedText: printable ? key.text : void 0,
    modifiers: bits,
    location: key.location,
    ...commands.length ? { commands } : {}
  });
  if (await untilDialog(tabId2, down)) return;
  await send(tabId2, "Input.dispatchKeyEvent", { type: "keyUp", key: key.key, code: key.code, windowsVirtualKeyCode: key.keyCode, modifiers: bits, location: key.location });
  for (const m of held.reverse()) {
    const d = parseCombo(m).key;
    cur &= ~modifierBits([m]);
    await send(tabId2, "Input.dispatchKeyEvent", { type: "keyUp", key: d.key, code: d.code, windowsVirtualKeyCode: d.keyCode, modifiers: cur, location: d.location });
  }
}
async function typeText(tabId2, text2) {
  const parts = text2.split(/(\n|\t)/);
  for (const p of parts) {
    if (p === "\n") await pressCombo(tabId2, "Enter");
    else if (p === "	") await pressCombo(tabId2, "Tab");
    else if (p) await send(tabId2, "Input.insertText", { text: p });
  }
}
function b64ToBytes(b64) {
  return b64ToBlob(b64, "application/octet-stream");
}
var SET_FILES_FN = `function (files) {
  const dt = new DataTransfer();
  for (const f of files) {
    const bin = atob(f.base64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    dt.items.add(new File([bytes], f.name, { type: f.mimeType || "application/octet-stream" }));
  }
  let el = this;
  if (!(el instanceof HTMLInputElement && el.type === "file")) {
    const inner = el.querySelector && el.querySelector('input[type="file"]');
    if (inner) el = inner;
  }
  if (el instanceof HTMLInputElement && el.type === "file") {
    if (!el.multiple && files.length > 1) throw new Error("This file input accepts one file; got " + files.length);
    el.files = dt.files;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return "input";
  }
  const r = el.getBoundingClientRect();
  for (const type of ["dragenter", "dragover", "drop"]) {
    el.dispatchEvent(new DragEvent(type, { bubbles: true, cancelable: true, dataTransfer: dt, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 }));
  }
  return "drop";
}`;
var DEEP_QUERY = (token) => `(() => {
  const sel = '[data-acm-up="${token}"]';
  const walk = (root) => {
    const hit = root.querySelector(sel);
    if (hit) return hit;
    for (const el of root.querySelectorAll("*")) if (el.shadowRoot) { const h = walk(el.shadowRoot); if (h) return h; }
    return null;
  };
  return walk(document);
})()`;
async function setFilesCdp(tabId2, target, files) {
  let objectId;
  if (target.backendNodeId !== void 0) {
    const r2 = await send(tabId2, "DOM.resolveNode", { backendNodeId: target.backendNodeId });
    objectId = r2.object?.objectId;
  } else if (target.token) {
    const r2 = await send(tabId2, "Runtime.evaluate", { expression: DEEP_QUERY(target.token), returnByValue: false });
    objectId = r2.result?.objectId;
  }
  if (!objectId) throw new Error("Could not find the file input in the page. Call read_page again.");
  if (files.paths?.length) {
    const info = await send(tabId2, "Runtime.callFunctionOn", {
      objectId,
      functionDeclaration: "function(){ const el = this instanceof HTMLInputElement ? this : this.querySelector && this.querySelector('input[type=file]'); return el && el.type === 'file' ? { multiple: el.multiple } : null; }",
      returnByValue: true
    });
    if (!info.result?.value) throw new Error("Local file paths can only go into an <input type=file>. Use files with base64 or url to drop onto other elements.");
    if (!info.result.value.multiple && files.paths.length > 1) throw new Error(`This file input accepts one file; got ${files.paths.length}`);
    await send(tabId2, "DOM.setFileInputFiles", { files: files.paths, objectId });
    return `Attached ${files.paths.length} local file(s)`;
  }
  const r = await send(tabId2, "Runtime.callFunctionOn", {
    objectId,
    functionDeclaration: SET_FILES_FN,
    arguments: [{ value: files.data ?? [] }],
    returnByValue: true,
    awaitPromise: true
  });
  if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description?.split("\n")[0] ?? r.exceptionDetails.text);
  const how = r.result?.value === "drop" ? "Dropped" : "Attached";
  return `${how} ${files.data?.length ?? 0} file(s)`;
}

// src/background/recording.ts
var recs = /* @__PURE__ */ new Map();
async function ensureOffscreen() {
  if (await chrome.offscreen.hasDocument()) return;
  await chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: [chrome.offscreen.Reason.BLOBS],
    justification: "Encode video and GIF recordings of tabs the agent controls."
  });
}
var toOffscreen = (msg) => chrome.runtime.sendMessage({ target: "offscreen", ...msg });
async function startRecording(tabId2, opts) {
  if (recs.has(tabId2)) throw new Error("This tab is already recording. Stop it first.");
  await ensureOffscreen();
  const recId = crypto.randomUUID();
  const fps = Math.max(1, Math.min(opts.kind === "gif" ? 10 : 30, opts.fps ?? (opts.kind === "gif" ? 5 : 15)));
  const started = await toOffscreen({ type: "rec:start", recId, kind: opts.kind, fps, format: opts.format });
  if (!started?.ok) throw new Error(started?.error ?? "Recorder failed to start");
  await chrome.tabs.update(tabId2, { active: true });
  const stopListen = onCdpEvent((tid, method, params) => {
    if (tid !== tabId2 || method !== "Page.screencastFrame") return;
    send(tabId2, "Page.screencastFrameAck", { sessionId: params.sessionId }).catch(() => {
    });
    toOffscreen({ type: "rec:frame", recId, data: params.data, metadata: params.metadata }).catch(() => {
    });
  });
  await send(tabId2, "Page.startScreencast", {
    format: "jpeg",
    quality: opts.kind === "gif" ? 60 : 75,
    maxWidth: opts.kind === "gif" ? 800 : 1600,
    maxHeight: opts.kind === "gif" ? 800 : 1600,
    everyNthFrame: 1
  });
  send(tabId2, "Runtime.evaluate", { expression: "document.body && (document.body.style.outline = document.body.style.outline)" }).catch(() => {
  });
  const rec = { recId, kind: opts.kind, since: Date.now(), showClicks: opts.showClicks === true, cursor: opts.cursor ?? "natural", stopListen };
  recs.set(tabId2, rec);
  chrome.action.setBadgeText({ tabId: tabId2, text: "REC" }).catch(() => {
  });
  chrome.action.setBadgeBackgroundColor({ tabId: tabId2, color: "#E5484D" }).catch(() => {
  });
  setTimeout(() => {
    if (recs.get(tabId2)?.recId === recId) stopRecording(tabId2, {}).catch(() => {
    });
  }, 10 * 6e4);
  return { mimeType: started.mimeType, fps };
}
function noteClick(tabId2, cssX, cssY) {
  const rec = recs.get(tabId2);
  if (rec?.showClicks) toOffscreen({ type: "rec:click", recId: rec.recId, x: cssX, y: cssY }).catch(() => {
  });
}
async function stopRecording(tabId2, opts) {
  const rec = recs.get(tabId2);
  if (!rec) throw new Error("This tab is not recording.");
  recs.delete(tabId2);
  chrome.action.setBadgeText({ tabId: tabId2, text: "" }).catch(() => {
  });
  rec.stopListen();
  await send(tabId2, "Page.stopScreencast").catch(() => {
  });
  const conn = await getConnection();
  const ext = rec.kind === "gif" ? "gif" : void 0;
  const res = await toOffscreen({
    type: "rec:stop",
    recId: rec.recId,
    server: conn.server,
    token: conn.deviceToken,
    filename: opts.filename,
    ext,
    inline: opts.inline
  });
  if (!res?.ok) throw new Error(res?.error ?? "Recorder failed");
  let downloadId;
  if (opts.download && res.objectUrl) {
    const name = (opts.filename || `agent-recording-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}`).replace(/\.(mp4|webm|gif)$/i, "");
    downloadId = await chrome.downloads.download({ url: res.objectUrl, filename: `${name}.${res.ext}`, saveAs: false }).catch(() => void 0);
  }
  return { ...res, downloadId };
}
function isRecording(tabId2) {
  return recs.has(tabId2);
}
function recordingSince(tabId2) {
  return recs.get(tabId2)?.since;
}
function presentationOf(tabId2) {
  const r = recs.get(tabId2);
  if (!r) return { clean: false, skin: "agent" };
  return { clean: r.cursor !== "agent", skin: r.cursor };
}

// src/background/tools.ts
var text = (t) => ({ type: "text", text: t });
var ok = (...blocks) => ({ content: blocks });
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
var lingerTimers = /* @__PURE__ */ new Map();
async function overlayWorking(tabId2, s) {
  if (!(await getSettings()).showOverlay) return;
  clearTimeout(lingerTimers.get(tabId2));
  const since = recordingSince(tabId2);
  await tryContent(tabId2, "overlay", {
    ...presentationOf(tabId2),
    state: s.paused ? "paused" : "working",
    label: s.paused ? `${s.title} is paused` : `${s.title} is working`,
    agent: s.agent,
    rec: since ? { since } : null
  });
}
async function overlayIdle(tabId2, s) {
  const since = recordingSince(tabId2);
  await tryContent(tabId2, "overlay", { ...presentationOf(tabId2), state: "idle", label: `${s.title} is working`, agent: s.agent, rec: since ? { since } : null, linger: 2500 });
}
async function moveCursor(tabId2, s, x, y, press = false, extra = {}) {
  const pres = presentationOf(tabId2);
  if (!pres.clean && !(await getSettings()).showCursor) return;
  await tryContent(tabId2, "cursorTo", { x, y, label: s.title, agent: s.agent, press, skin: pres.skin, ...extra });
}
var recentTabs = [];
var recentDownloads = [];
chrome.tabs.onCreated.addListener(async (tab) => {
  if (tab.id === void 0) return;
  recentTabs.push({ tabId: tab.id, opener: tab.openerTabId, ts: Date.now() });
  if (recentTabs.length > 50) recentTabs.shift();
  if (tab.openerTabId === void 0) return;
  for (const s of await allSessions()) {
    if (s.groupId === void 0) continue;
    const opener = await chrome.tabs.get(tab.openerTabId).catch(() => null);
    if (opener?.groupId === s.groupId) {
      await chrome.tabs.group({ groupId: s.groupId, tabIds: [tab.id] }).catch(() => {
      });
      break;
    }
  }
});
chrome.downloads?.onCreated.addListener((d) => {
  recentDownloads.push({ name: (d.filename || d.finalUrl || d.url).split(/[\\/]/).pop() || "file", url: d.finalUrl || d.url, ts: Date.now() });
  if (recentDownloads.length > 50) recentDownloads.shift();
});
async function sideEffects(tabId2, since) {
  for (let i = 0; i < 6; i++) {
    await sleep(120);
    if (recentTabs.some((x) => x.opener === tabId2 && x.ts >= since) || recentDownloads.some((x) => x.ts >= since)) break;
    if (openedOf(tabId2).some((x) => x.ts >= since) && recentTabs.some((x) => x.ts >= since)) break;
  }
  const notes = [];
  const openedUrls = openedOf(tabId2).filter((x) => x.ts >= since).map((x) => x.url);
  const session = (await allSessions()).find((s) => s.currentTabId === tabId2);
  for (const t of recentTabs.filter((x) => x.ts >= since && x.tabId !== tabId2)) {
    const info = await chrome.tabs.get(t.tabId).catch(() => null);
    if (!info) continue;
    const url = info.pendingUrl ?? info.url ?? "";
    if (t.opener !== tabId2 && !openedUrls.some((u) => u === url || url.startsWith(u))) continue;
    if (session?.groupId !== void 0 && info.groupId !== session.groupId) await chrome.tabs.group({ groupId: session.groupId, tabIds: [t.tabId] }).catch(() => {
    });
    notes.push(`It opened a new tab ${t.tabId} (${url || "loading"}) in your group. Use tabs_select to switch to it.`);
  }
  const names = /* @__PURE__ */ new Set([...recentDownloads.filter((x) => x.ts >= since).map((d) => d.name), ...downloadsOf(tabId2).filter((x) => x.ts >= since).map((d) => d.name)]);
  for (const n of names) notes.push(`A download started: ${n}.`);
  const ch = chooserOf(tabId2);
  if (ch && ch.ts >= since) notes.push(`The page tried to open a file picker (${ch.mode === "selectMultiple" ? "multiple files" : "one file"}). It was held back; call file_upload without ref to fill it.`);
  return notes.length ? `
${notes.join("\n")}` : "";
}
async function tabSummary(tabId2) {
  const t = await chrome.tabs.get(tabId2);
  return { tabId: t.id, title: t.title, url: t.url ?? t.pendingUrl, status: t.status };
}
async function waitForLoad(tabId2, timeoutMs = 3e4) {
  const deadline = Date.now() + timeoutMs;
  await sleep(150);
  while (Date.now() < deadline) {
    if (dialogOf(tabId2)) return true;
    const t = await chrome.tabs.get(tabId2);
    if (t.status === "complete") return true;
    await sleep(150);
  }
  return false;
}
var RESTRICTED = /^(chrome|chrome-extension|edge|about|devtools|view-source):|^https:\/\/(chromewebstore\.google\.com|chrome\.google\.com\/webstore)/i;
function pageNotes(tabId2, url = "") {
  const notes = [];
  const doc = docOf(tabId2);
  if (doc?.error) notes.push(`The page failed to load: ${doc.error}.`);
  else if (doc?.status && doc.status >= 400) notes.push(`The server answered HTTP ${doc.status}.`);
  if (RESTRICTED.test(url) && !/^about:blank/.test(url)) notes.push("Chrome does not let extensions read or click on this kind of page, so only navigation works here.");
  return notes.length ? `
${notes.join("\n")}` : "";
}
function normalizeUrl(u) {
  if (/^(https?|file|chrome|about|data|blob|chrome-extension):/i.test(u)) return u;
  if (/^localhost(:\d+)?(\/|$)|^127\.0\.0\.1|^\[::1\]/.test(u)) return `http://${u}`;
  return `https://${u}`;
}
async function pointFor(tabId2, a) {
  if (a.ref) {
    const r = await content(tabId2, "refRect", { ref: a.ref });
    return { x: r.cx, y: r.cy, label: `${a.ref} (${r.tag})` };
  }
  if (Array.isArray(a.coordinate) && a.coordinate.length === 2) {
    const [x, y] = toCss(tabId2, a.coordinate[0], a.coordinate[1]);
    return { x, y, label: `(${a.coordinate[0]}, ${a.coordinate[1]})` };
  }
  throw new Error("Give coordinate [x, y] or ref.");
}
async function describeAt(tabId2, x, y) {
  const el = await tryContent(tabId2, "elementAt", { x, y });
  return el ? ` on ${el.role !== "generic" ? el.role : el.tag}${el.name ? ` "${el.name}"` : ""}` : "";
}
function dialogNote(tabId2) {
  const d = dialogOf(tabId2);
  return d ? `
A ${d.type} dialog is open: ${JSON.stringify(d.message)}. Use handle_dialog to accept or dismiss it.` : "";
}
async function fileFrom(f) {
  if (f.base64) return { name: f.name, mimeType: f.mimeType, base64: f.base64 };
  if (f.imageId) {
    const img = images.get(f.imageId);
    if (!img) throw new Error(`Unknown imageId ${f.imageId}`);
    return { name: f.name, mimeType: img.mimeType, base64: img.base64 };
  }
  if (f.url) {
    const res = await fetch(f.url);
    if (!res.ok) throw new Error(`Fetching ${f.url} failed: HTTP ${res.status}`);
    const blob = await res.blob();
    return { name: f.name, mimeType: f.mimeType ?? blob.type, base64: await blobToB64(blob) };
  }
  throw new Error(`File ${f.name} needs base64, url or imageId`);
}
async function uploadArtifact(blob, name) {
  const c = await getConnection();
  if (!c.server || !c.deviceToken) throw new Error("Not paired");
  const res = await fetch(`${c.server}/api/artifacts?name=${encodeURIComponent(name)}`, {
    method: "POST",
    headers: { authorization: `Bearer ${c.deviceToken}`, "content-type": blob.type },
    body: blob
  });
  if (!res.ok) throw new Error(`Upload failed: HTTP ${res.status}`);
  return res.json();
}
var handlers = {
  async tabs_context(a, { session }) {
    if (a.all) {
      const tabs3 = await chrome.tabs.query({});
      const groups = await chrome.tabGroups.query({});
      const gname = new Map(groups.map((g) => [g.id, g.title]));
      return ok(
        text(
          JSON.stringify(
            tabs3.map((t) => ({ tabId: t.id, windowId: t.windowId, title: t.title, url: t.url, active: t.active, group: t.groupId >= 0 ? gname.get(t.groupId) ?? t.groupId : void 0, sessionTab: t.id === session.currentTabId })),
            null,
            1
          )
        )
      );
    }
    let tabs2 = await groupTabs(session);
    if (tabs2.length === 0 && a.createIfEmpty !== false) {
      await createTab(session);
      tabs2 = await groupTabs(session);
    }
    const group = session.groupId !== void 0 && tabs2.length ? await chrome.tabGroups.get(session.groupId).catch(() => null) : null;
    const conn = await getConnection();
    return ok(
      text(
        JSON.stringify(
          {
            browser: conn.name,
            group: group ? { groupId: group.id, title: group.title, color: group.color } : null,
            currentTabId: session.currentTabId,
            tabs: tabs2.map((t) => ({ tabId: t.id, title: t.title, url: t.url ?? t.pendingUrl, current: t.id === session.currentTabId }))
          },
          null,
          1
        )
      )
    );
  },
  async tabs_create(a, { session, info }) {
    const url = a.url ? normalizeUrl(String(a.url)) : "about:blank";
    if (a.url) await gate(url, session.title);
    const tab = await createTab(session, "about:blank", Boolean(a.active));
    if (a.url) {
      await attach(tab.id).catch(() => {
      });
      await chrome.tabs.update(tab.id, { url });
      await waitForLoad(tab.id);
    }
    return ok(text(JSON.stringify({ created: await tabSummary(tab.id), groupId: session.groupId }, null, 1)));
  },
  async tabs_close(a, { session }) {
    const tab = await chrome.tabs.get(a.tabId);
    if (!a.force && tab.groupId !== session.groupId) throw new Error("That tab is not in this session's group. Pass force=true to close it anyway.");
    await chrome.tabs.remove(a.tabId);
    if (session.currentTabId === a.tabId) session.currentTabId = void 0;
    await updateSession(session);
    return ok(text(`Closed tab ${a.tabId}`));
  },
  async tabs_select(a, { session }) {
    const tab = await chrome.tabs.get(a.tabId);
    if (a.adopt) await ensureInGroup(session, a.tabId);
    session.currentTabId = a.tabId;
    await updateSession(session);
    if (a.focus) {
      await chrome.tabs.update(a.tabId, { active: true });
      await chrome.windows.update(tab.windowId, { focused: true });
    }
    return ok(text(`Current tab is now ${a.tabId}: ${tab.title}`));
  },
  async tab_groups(a, { session }) {
    const action = a.action;
    if (action === "list") {
      const groups = await chrome.tabGroups.query({});
      const out = await Promise.all(
        groups.map(async (g) => ({
          groupId: g.id,
          title: g.title,
          color: g.color,
          collapsed: g.collapsed,
          windowId: g.windowId,
          session: g.id === session.groupId,
          tabs: (await chrome.tabs.query({ groupId: g.id })).map((t) => ({ tabId: t.id, title: t.title }))
        }))
      );
      return ok(text(JSON.stringify(out, null, 1)));
    }
    if (action === "update") {
      let gid = a.groupId ?? session.groupId;
      if (gid === void 0) {
        await resolveTab(session, void 0, true);
        const tabId2 = session.currentTabId;
        gid = await ensureInGroup(session, tabId2);
      }
      const patch = {};
      if (a.title !== void 0) patch.title = String(a.title);
      if (a.color) patch.color = a.color;
      if (a.collapsed !== void 0) patch.collapsed = Boolean(a.collapsed);
      const g = await chrome.tabGroups.update(gid, patch);
      if (g && gid === session.groupId) {
        if (a.title !== void 0) session.title = String(a.title);
        if (a.color) session.color = a.color;
        await updateSession(session);
      }
      return ok(text(`Group ${gid} is now "${g?.title}" (${g?.color})${g?.collapsed ? ", collapsed" : ""}`));
    }
    if (action === "create" || action === "move") {
      const tabIds = a.tabIds?.length ? a.tabIds : [await resolveTab(session, void 0, true)];
      const ids = tabIds;
      const groupId = await chrome.tabs.group(action === "move" && a.groupId !== void 0 ? { groupId: a.groupId, tabIds: ids } : { tabIds: ids });
      const patch = {};
      if (a.title !== void 0) patch.title = String(a.title);
      if (a.color) patch.color = a.color;
      if (Object.keys(patch).length) await chrome.tabGroups.update(groupId, patch);
      if (a.makeSessionGroup) {
        session.groupId = groupId;
        if (a.title) session.title = String(a.title);
        await updateSession(session);
      }
      return ok(text(`Tabs ${tabIds.join(", ")} are in group ${groupId}`));
    }
    if (action === "ungroup") {
      const tabIds = a.tabIds?.length ? a.tabIds : session.groupId !== void 0 ? (await groupTabs(session)).map((t) => t.id) : [];
      if (!tabIds.length) throw new Error("No tabs to ungroup");
      await chrome.tabs.ungroup(tabIds);
      return ok(text(`Ungrouped tabs ${tabIds.join(", ")}`));
    }
    throw new Error(`Unknown action ${action}`);
  },
  async navigate(a, { session }) {
    const tabId2 = await resolveTab(session, a.tabId);
    await ensureInGroupIfOwned(session, tabId2);
    const url = String(a.url);
    let navError = "";
    let leftUnsaved = false;
    const go = async (p) => {
      let res;
      const done = p.then((x) => res = x);
      if (await untilDialog(tabId2, done)) {
        const d = dialogOf(tabId2);
        if (d?.type === "beforeunload") {
          await send(tabId2, "Page.handleJavaScriptDialog", { accept: true });
          clearDialog(tabId2);
          leftUnsaved = true;
          await done.catch(() => {
          });
        }
      }
      return res;
    };
    const history = async (delta) => {
      const h = await send(tabId2, "Page.getNavigationHistory");
      const entry = h.entries[h.currentIndex + delta];
      if (!entry) throw new Error(delta < 0 ? "There is no previous page." : "There is no next page.");
      await go(send(tabId2, "Page.navigateToHistoryEntry", { entryId: entry.id }));
    };
    if (url === "back") await history(-1);
    else if (url === "forward") await history(1);
    else if (url === "reload") await go(send(tabId2, "Page.reload", { ignoreCache: false }));
    else {
      const target = normalizeUrl(url);
      if (/^file:/i.test(target) && !await chrome.extension.isAllowedFileSchemeAccess()) {
        throw new Error('Opening local files needs permission: in chrome://extensions open Agent Chrome MCP > Details and turn on "Allow access to file URLs".');
      }
      await gate(target, session.title);
      const current = (await chrome.tabs.get(tabId2)).url ?? "";
      if (RESTRICTED.test(target) || /^file:/i.test(target) || RESTRICTED.test(current) && !/^about:blank/.test(current)) await chrome.tabs.update(tabId2, { url: target });
      else {
        const nav = await go(send(tabId2, "Page.navigate", { url: target })) ?? {};
        if (nav.errorText && nav.errorText !== "net::ERR_ABORTED") navError = nav.errorText;
      }
    }
    const loaded = await waitForLoad(tabId2, Math.min(a.timeoutMs ?? 3e4, 55e3));
    await overlayWorking(tabId2, session);
    const t = await tabSummary(tabId2);
    return ok(text(`${loaded ? "Loaded" : "Still loading (timed out waiting)"}: ${t.title}
URL: ${t.url}
tabId: ${tabId2}${leftUnsaved ? "\nThe previous page warned about unsaved changes; the agent left it." : ""}${navError && !docOf(tabId2)?.error ? `
The page failed to load: ${navError}.` : ""}${pageNotes(tabId2, t.url)}${dialogNote(tabId2)}`));
  },
  async computer(a, { session }) {
    const tabId2 = await resolveTab(session, a.tabId);
    const tab = await chrome.tabs.get(tabId2);
    await gate(tab.url, session.title);
    const mods = a.modifiers ? modifierBits(String(a.modifiers).split("+")) : 0;
    switch (a.action) {
      case "screenshot": {
        const s = await screenshot(tabId2);
        return ok(
          { type: "image", data: s.base64, mimeType: s.mimeType },
          text(`Screenshot of tab ${tabId2} (${s.width}x${s.height}, imageId ${s.imageId}). Coordinates for clicks use this image's pixels.${dialogNote(tabId2)}`)
        );
      }
      case "zoom": {
        if (!Array.isArray(a.region) || a.region.length !== 4) throw new Error("zoom needs region [x0, y0, x1, y1]");
        const data = await zoom(tabId2, a.region);
        return ok({ type: "image", data, mimeType: "image/png" }, text(`Zoomed region ${JSON.stringify(a.region)} at full resolution.`));
      }
      case "left_click":
      case "right_click":
      case "middle_click":
      case "double_click":
      case "triple_click": {
        const p = await pointFor(tabId2, a);
        const what = await describeAt(tabId2, p.x, p.y);
        const button = a.action === "right_click" ? "right" : a.action === "middle_click" ? "middle" : "left";
        const count = a.action === "double_click" ? 2 : a.action === "triple_click" ? 3 : 1;
        await moveCursor(tabId2, session, p.x, p.y, true);
        tryContent(tabId2, "ripple", { x: p.x, y: p.y });
        noteClick(tabId2, p.x, p.y);
        const since = Date.now();
        await click(tabId2, p.x, p.y, { button, count, modifiers: mods });
        for (let i = 0; i < 4 && !dialogOf(tabId2); i++) await sleep(60);
        const effects = dialogOf(tabId2) ? "" : await sideEffects(tabId2, since);
        return ok(text(`${a.action.replace("_", " ")} at ${p.label}${what}${effects}${dialogNote(tabId2)}`));
      }
      case "hover":
      case "mouse_move": {
        const p = await pointFor(tabId2, a);
        await moveCursor(tabId2, session, p.x, p.y);
        await mouseMove(tabId2, p.x, p.y, mods);
        return ok(text(`Hovering at ${p.label}${await describeAt(tabId2, p.x, p.y)}`));
      }
      case "left_click_drag": {
        if (!a.start_coordinate && !a.start_ref) throw new Error("left_click_drag needs start_coordinate (or start_ref) and coordinate (or ref)");
        const start = a.start_ref ? await pointFor(tabId2, { ref: a.start_ref }) : null;
        const from = start ? [start.x, start.y] : toCss(tabId2, a.start_coordinate[0], a.start_coordinate[1]);
        const to = await pointFor(tabId2, a);
        await moveCursor(tabId2, session, from[0], from[1], true);
        noteClick(tabId2, from[0], from[1]);
        const dragging = moveCursor(tabId2, session, to.x, to.y, false, { grab: true, durationMs: 420 });
        const mode = await drag(tabId2, from, [to.x, to.y]);
        await dragging;
        await moveCursor(tabId2, session, to.x, to.y);
        return ok(text(`Dragged from ${start ? start.label : `(${a.start_coordinate})`} to ${to.label}${mode === "html5" ? " (native drag and drop)" : ""}${dialogNote(tabId2)}`));
      }
      case "type": {
        if (typeof a.text !== "string") throw new Error("type needs text");
        if (a.ref) {
          const p = await pointFor(tabId2, a);
          await moveCursor(tabId2, session, p.x, p.y, true);
          await click(tabId2, p.x, p.y);
        }
        await typeText(tabId2, a.text);
        return ok(text(`Typed ${a.text.length} characters`));
      }
      case "key": {
        if (!a.text) throw new Error("key needs text, e.g. 'Enter' or 'cmd+a'");
        const repeat = Math.min(Math.max(1, a.repeat ?? 1), 100);
        for (let i = 0; i < repeat; i++) for (const combo of String(a.text).split(/\s+/).filter(Boolean)) await pressCombo(tabId2, combo);
        return ok(text(`Pressed ${a.text}${repeat > 1 ? ` \xD7${repeat}` : ""}${dialogNote(tabId2)}`));
      }
      case "scroll": {
        const vp = await viewport(tabId2);
        const p = a.coordinate || a.ref ? await pointFor(tabId2, a) : { x: vp.width / 2, y: vp.height / 2, label: "center" };
        if (a.coordinate || a.ref) await moveCursor(tabId2, session, p.x, p.y);
        const amount = (a.scroll_amount ?? 3) * 100;
        const dir = a.scroll_direction ?? "down";
        const dx = dir === "left" ? -amount : dir === "right" ? amount : 0;
        const dy = dir === "up" ? -amount : dir === "down" ? amount : 0;
        await wheel(tabId2, p.x, p.y, dx, dy);
        await sleep(250);
        const after = await viewport(tabId2);
        return ok(text(`Scrolled ${dir} by ${amount}px at ${p.label}. Page scroll is now (${Math.round(after.scrollX)}, ${Math.round(after.scrollY)}).`));
      }
      case "scroll_to": {
        if (!a.ref) throw new Error("scroll_to needs ref");
        await content(tabId2, "refRect", { ref: a.ref });
        return ok(text(`Scrolled ${a.ref} into view`));
      }
      case "wait": {
        const secs = Math.min(Math.max(0, a.duration ?? 1), 30);
        await sleep(secs * 1e3);
        return ok(text(`Waited ${secs}s`));
      }
      default:
        throw new Error(`Unknown action ${a.action}`);
    }
  },
  async screenshot(a, { session }) {
    const tabId2 = await resolveTab(session, a.tabId);
    const s = await screenshot(tabId2, { format: a.format, fullPage: a.fullPage });
    const blocks = [{ type: "image", data: s.base64, mimeType: s.mimeType }];
    let note = `Screenshot of tab ${tabId2} (${s.width}x${s.height}${a.fullPage ? ", full page" : ""}, imageId ${s.imageId}).`;
    if (a.save) {
      const saved = await uploadArtifact(b64ToBytes(s.base64).slice(0, void 0, s.mimeType), `screenshot-${Date.now()}.${a.format === "png" ? "png" : "jpg"}`);
      note += ` Saved: ${saved.url}${saved.path ? `
File: ${saved.path}` : ""}`;
    }
    blocks.push(text(note));
    return ok(...blocks);
  },
  async read_page(a, { session }) {
    const tabId2 = await resolveTab(session, a.tabId);
    await gate((await chrome.tabs.get(tabId2)).url, session.title);
    const out = await content(tabId2, "readPage", a);
    return ok(text(out + dialogNote(tabId2)));
  },
  async find(a, { session }) {
    const tabId2 = await resolveTab(session, a.tabId);
    const found = await content(tabId2, "find", { query: a.query, limit: a.limit ?? 20 });
    if (!found.length) return ok(text(`Nothing matched "${a.query}". Try read_page with filter="interactive".`));
    const lines = found.map((f) => {
      const [x, y] = toShot(tabId2, f.rect.x + f.rect.width / 2, f.rect.y + f.rect.height / 2);
      return `- ${f.role} ${JSON.stringify(f.name)} [${f.ref}] at (${x}, ${y})`;
    });
    return ok(text(`Matches for "${a.query}":
${lines.join("\n")}`));
  },
  async form_input(a, { session }) {
    const tabId2 = await resolveTab(session, a.tabId);
    const box = await content(tabId2, "refRect", { ref: a.ref });
    await moveCursor(tabId2, session, box.cx, box.cy, true);
    const r = await content(tabId2, "formInput", { ref: a.ref, value: a.value });
    return ok(text(`${a.ref}: ${r}`));
  },
  async get_page_text(a, { session }) {
    const tabId2 = await resolveTab(session, a.tabId);
    await gate((await chrome.tabs.get(tabId2)).url, session.title);
    return ok(text(await content(tabId2, "pageText", { max_chars: a.max_chars })));
  },
  async javascript_tool(a, { session }) {
    const tabId2 = await resolveTab(session, a.tabId);
    await gate((await chrome.tabs.get(tabId2)).url, session.title);
    let r;
    const evaluating = send(tabId2, "Runtime.evaluate", {
      expression: String(a.text),
      replMode: true,
      awaitPromise: true,
      returnByValue: true,
      userGesture: true,
      timeout: 5e4
    }).then((x) => r = x);
    if (await untilDialog(tabId2, evaluating)) {
      return ok(text(`The script opened a dialog and is waiting for it.${dialogNote(tabId2)}`));
    }
    if (r.exceptionDetails) {
      const d = r.exceptionDetails;
      return { content: [text(`JavaScript error: ${d.exception?.description ?? d.text}`)], isError: true };
    }
    const v = r.result;
    let out;
    if (v.type === "undefined") out = "undefined";
    else if ("value" in v) out = typeof v.value === "string" ? v.value : JSON.stringify(v.value, null, 1);
    else out = v.description ?? v.unserializableValue ?? v.type;
    if (out && out.length > 5e4) out = `${out.slice(0, 5e4)}
\u2026 truncated`;
    return ok(text(out ?? "null"));
  },
  async read_console_messages(a, { session }) {
    const tabId2 = await resolveTab(session, a.tabId);
    await attach(tabId2);
    const all = consoleOf(tabId2);
    let list = all.slice();
    if (a.onlyErrors) list = list.filter((m) => m.level === "error");
    if (a.pattern) {
      const re = new RegExp(a.pattern, "i");
      list = list.filter((m) => re.test(m.text));
    }
    list = list.slice(-(a.limit ?? 100));
    if (a.clear) all.length = 0;
    if (!list.length) return ok(text("No console messages captured yet (capture starts when the agent first uses the tab)."));
    return ok(text(list.map((m) => `[${m.level}] ${m.text}${m.url ? `  (${m.url})` : ""}`).join("\n")));
  },
  async read_network_requests(a, { session }) {
    const tabId2 = await resolveTab(session, a.tabId);
    await attach(tabId2);
    const map = networkOf(tabId2);
    let list = [...map.values()];
    if (a.urlPattern) {
      let re = null;
      try {
        re = new RegExp(a.urlPattern, "i");
      } catch {
      }
      list = list.filter((r) => re ? re.test(r.url) : r.url.includes(a.urlPattern));
    }
    list = list.slice(-(a.limit ?? 100));
    const out = [];
    for (const r of list) {
      let line = `${r.method} ${r.status ?? (r.failed ? "FAILED" : "pending")} ${r.type ?? ""} ${r.url}${r.durationMs !== void 0 ? ` ${r.durationMs}ms` : ""}${r.failed ? ` (${r.failed})` : ""}`;
      if (a.includeBodies && (r.type === "XHR" || r.type === "Fetch") && r.status) {
        try {
          const b = await send(tabId2, "Network.getResponseBody", { requestId: r.requestId });
          const body = b.base64Encoded ? "[binary]" : String(b.body);
          line += `
    body: ${body.length > 1e4 ? `${body.slice(0, 1e4)}\u2026` : body}`;
        } catch {
        }
      }
      out.push(line);
    }
    if (a.clear) map.clear();
    return ok(text(out.length ? out.join("\n") : "No requests captured yet (capture starts when the agent first uses the tab)."));
  },
  async resize_window(a, { session }) {
    const tabId2 = await resolveTab(session, a.tabId);
    const tab = await chrome.tabs.get(tabId2);
    const w = await chrome.windows.update(tab.windowId, { state: "normal", width: Math.round(a.width), height: Math.round(a.height) });
    return ok(text(`Window ${w.id} resized to ${w.width}x${w.height}`));
  },
  async file_upload(a, { session }) {
    const tabId2 = await resolveTab(session, a.tabId);
    const paths = Array.isArray(a.paths) ? a.paths.map(String) : [];
    const data = await Promise.all((a.files ?? []).map(fileFrom));
    if (!paths.length && !data.length) throw new Error("Give files (base64, url or imageId) or paths (absolute paths on the browser's computer).");
    if (paths.length && data.length) throw new Error("Use either paths or files in one call, not both.");
    if (paths.some((p) => !/^(\/|[A-Za-z]:[\\/])/.test(p))) throw new Error("paths must be absolute file paths on the computer running Chrome.");
    let result;
    if (a.ref) {
      const box = await content(tabId2, "refRect", { ref: a.ref });
      await moveCursor(tabId2, session, box.cx, box.cy, true);
      const mark = await content(tabId2, "markUpload", { ref: a.ref });
      result = await setFilesCdp(tabId2, { token: mark.token }, { paths, data });
    } else {
      const ch = chooserOf(tabId2);
      if (!ch) throw new Error("No ref given and no file picker is waiting. Pass the ref of the file input (or its upload button) from read_page.");
      if (ch.mode !== "selectMultiple" && paths.length + data.length > 1) throw new Error("The waiting file picker accepts one file.");
      result = await setFilesCdp(tabId2, { backendNodeId: ch.backendNodeId }, { paths, data });
      clearChooser(tabId2);
    }
    const names = paths.length ? paths.map((p) => p.split(/[\\/]/).pop()) : data.map((f) => f.name);
    return ok(text(`${result}: ${names.join(", ")}`));
  },
  async upload_image(a, { session }) {
    const tabId2 = await resolveTab(session, a.tabId);
    const img = images.get(a.imageId);
    if (!img) throw new Error(`Unknown imageId ${a.imageId}. Take a screenshot first.`);
    const name = a.filename ?? (img.mimeType === "image/png" ? "image.png" : "image.jpg");
    const files = [{ name, mimeType: img.mimeType, base64: img.base64 }];
    if (a.ref) {
      const mark = await content(tabId2, "markUpload", { ref: a.ref });
      return ok(text(await setFilesCdp(tabId2, { token: mark.token }, { data: files })));
    }
    if (a.coordinate) {
      const [x, y] = toCss(tabId2, a.coordinate[0], a.coordinate[1]);
      return ok(text(await content(tabId2, "setFiles", { x, y, files })));
    }
    throw new Error("upload_image needs ref or coordinate");
  },
  async record(a, { session }) {
    const tabId2 = await resolveTab(session, a.tabId);
    if (a.action === "status") {
      const since = recordingSince(tabId2);
      return ok(text(since ? `Recording tab ${tabId2} for ${Math.round((Date.now() - since) / 1e3)}s` : `Tab ${tabId2} is not recording`));
    }
    if (a.action === "start") {
      const cursor = a.cursor === "agent" || a.cursor === "hidden" ? a.cursor : "natural";
      const r = await startRecording(tabId2, { kind: "video", fps: a.fps, format: a.format, showClicks: a.showClicks, cursor });
      await overlayWorking(tabId2, session);
      return ok(
        text(
          `Recording tab ${tabId2} (${r.mimeType}, ${r.fps} fps, ${cursor} cursor${cursor === "agent" ? "" : "; the border, status pill and name tag are hidden from the clip"}). Do the steps, then call record with action=stop.`
        )
      );
    }
    if (a.action === "stop") {
      const r = await stopRecording(tabId2, { filename: a.filename, download: a.download });
      await overlayIdle(tabId2, session);
      return ok(
        text(
          [
            `Recorded ${(r.durationMs / 1e3).toFixed(1)}s, ${r.frames} frames, ${(r.bytes / 1024 / 1024).toFixed(2)} MB (${r.mimeType}).`,
            r.url ? `URL: ${r.url}` : r.uploadError ? `Upload failed: ${r.uploadError}` : "",
            r.path ? `File: ${r.path}` : "",
            r.downloadId !== void 0 ? "Also saved to the browser's Downloads folder." : ""
          ].filter(Boolean).join("\n")
        )
      );
    }
    throw new Error(`Unknown action ${a.action}`);
  },
  async gif_creator(a, { session }) {
    const tabId2 = await resolveTab(session, a.tabId);
    if (a.action === "start_recording") {
      await startRecording(tabId2, { kind: "gif", showClicks: a.showClicks === true, cursor: a.cursor === "agent" || a.cursor === "hidden" ? a.cursor : "natural" });
      await overlayWorking(tabId2, session);
      return ok(text(`GIF recording started on tab ${tabId2}. Call gif_creator with action=stop_recording, then export.`));
    }
    if (a.action === "stop_recording" || a.action === "export") {
      if (!isRecording(tabId2)) {
        if (a.action === "export" && lastGif.has(tabId2)) {
          const g = lastGif.get(tabId2);
          return ok(...g);
        }
        throw new Error("No GIF recording on this tab");
      }
      const r = await stopRecording(tabId2, { filename: a.filename, download: a.download, inline: true });
      await overlayIdle(tabId2, session);
      const blocks = [];
      if (r.base64) blocks.push({ type: "image", data: r.base64, mimeType: "image/gif" });
      blocks.push(text(`GIF: ${r.frames} frames, ${(r.bytes / 1024).toFixed(0)} KB. ${r.path ?? r.url ?? r.uploadError ?? ""}`));
      lastGif.set(tabId2, blocks);
      return ok(...blocks);
    }
    if (a.action === "clear") {
      if (isRecording(tabId2)) await stopRecording(tabId2, {}).catch(() => {
      });
      lastGif.delete(tabId2);
      return ok(text("Cleared"));
    }
    throw new Error(`Unknown action ${a.action}`);
  },
  async wait_for(a, { session }) {
    const tabId2 = await resolveTab(session, a.tabId);
    const timeout = Math.min(a.timeoutMs ?? 1e4, 6e4);
    const deadline = Date.now() + timeout;
    if (a.urlIncludes) {
      while (Date.now() < deadline) {
        if ((await chrome.tabs.get(tabId2)).url?.includes(a.urlIncludes)) break;
        await sleep(200);
      }
      if (!(await chrome.tabs.get(tabId2)).url?.includes(a.urlIncludes)) return { content: [text(`Timed out: URL does not include ${a.urlIncludes}`)], isError: true };
    }
    if (a.text || a.textGone || a.selector) {
      let res;
      while (Date.now() < deadline) {
        try {
          res = await content(tabId2, "waitFor", { ...a, timeoutMs: Math.max(0, deadline - Date.now()) });
          if (res?.ok) break;
        } catch {
          await sleep(300);
        }
      }
      if (!res?.ok) return { content: [text(`Timed out after ${timeout}ms waiting for ${JSON.stringify({ text: a.text, textGone: a.textGone, selector: a.selector })}`)], isError: true };
    }
    return ok(text("Condition met"));
  },
  async handle_dialog(a, { session }) {
    const tabId2 = await resolveTab(session, a.tabId);
    const d = dialogOf(tabId2);
    if (!d) throw new Error("No dialog is open on this tab.");
    await send(tabId2, "Page.handleJavaScriptDialog", { accept: Boolean(a.accept), promptText: a.promptText });
    clearDialog(tabId2);
    return ok(text(`${a.accept ? "Accepted" : "Dismissed"} ${d ? `${d.type} "${d.message}"` : "the dialog"}`));
  },
  async history_search(a) {
    const granted = await chrome.permissions.contains({ permissions: ["history"] });
    if (!granted) throw new Error("History access is off. The user can turn it on in the Agent Chrome MCP extension popup.");
    const items = await chrome.history.search({
      text: String(a.query),
      maxResults: Math.min(a.maxResults ?? 25, 100),
      startTime: Date.now() - (a.daysBack ?? 30) * 864e5
    });
    return ok(text(JSON.stringify(items.map((i) => ({ title: i.title, url: i.url, lastVisit: i.lastVisitTime ? new Date(i.lastVisitTime).toISOString() : void 0, visits: i.visitCount })), null, 1)));
  }
};
var lastGif = /* @__PURE__ */ new Map();
async function ensureInGroupIfOwned(session, tabId2) {
  if (session.currentTabId === tabId2) {
    const t = await chrome.tabs.get(tabId2);
    if (session.groupId === void 0 || t.groupId !== session.groupId) {
      const inAnother = t.groupId >= 0 && t.groupId !== session.groupId;
      if (!inAnother) await ensureInGroup(session, tabId2);
    }
  }
}
var TAB_TOOLS = /* @__PURE__ */ new Set(["navigate", "computer", "screenshot", "read_page", "find", "form_input", "get_page_text", "javascript_tool", "file_upload", "upload_image", "wait_for", "record", "gif_creator"]);
async function runTool(name, args, info, signal) {
  const session = await getSession(info);
  if (session.paused) {
    const why = session.pausedReason === "debugger" ? `The user pressed Cancel on Chrome's "started debugging this browser" bar, which stops agent control.` : "The user pressed Stop in the browser, so this session is paused.";
    return {
      content: [text(`${why} Ask the user what to do; they can press Resume in the Agent Chrome popup.`)],
      isError: true
    };
  }
  const h = handlers[name];
  if (!h) return { content: [text(`Unknown tool ${name}`)], isError: true };
  let tabId2;
  if (TAB_TOOLS.has(name)) {
    try {
      tabId2 = await resolveTab(session, args.tabId);
      if (args.tabId === void 0) args.tabId = tabId2;
    } catch {
    }
    if (tabId2 !== void 0 && crashedOf(tabId2) && name !== "navigate") {
      return { content: [text(`Tab ${tabId2} crashed ("Aw, Snap!"). Call navigate with url "reload" to recover it.`)], isError: true };
    }
    if (tabId2 !== void 0 && dialogOf(tabId2)) {
      return { content: [text(`Tab ${tabId2} is blocked by a ${dialogOf(tabId2).type} dialog: ${JSON.stringify(dialogOf(tabId2).message)}. Call handle_dialog first.`)], isError: true };
    }
    if (tabId2 !== void 0) {
      await overlayWorking(tabId2, session).catch(() => {
      });
      await tryContent(tabId2, "passThrough", { on: true });
    }
  }
  try {
    const result = await Promise.race([
      h(args, { session, info, signal }),
      new Promise((_, rej) => signal.addEventListener("abort", () => rej(new Error("Cancelled")), { once: true }))
    ]);
    return result;
  } catch (e) {
    return { content: [text(`Error: ${e?.message ?? String(e)}`)], isError: true };
  } finally {
    if (tabId2 !== void 0) {
      tryContent(tabId2, "passThrough", { on: false }).catch(() => {
      });
      overlayIdle(tabId2, session).catch(() => {
      });
    }
  }
}
async function setSessionPaused(s, paused, reason) {
  s.paused = paused;
  s.pausedReason = paused ? reason : void 0;
  await updateSession(s);
  for (const t of await groupTabs(s)) {
    await tryContent(t.id, "overlay", paused ? { state: "paused", label: `${s.title} is paused` } : { state: "hidden" });
    if (paused) await tryContent(t.id, "cursorHide");
  }
}
async function setPaused(tabId2, paused, reason) {
  const list = tabId2 !== void 0 ? await sessionsForTab(tabId2) : await allSessions();
  for (const s of list) await setSessionPaused(s, paused, reason);
  return list.length;
}

// src/background/index.ts
var VERSION = chrome.runtime.getManifest().version;
var ws = null;
var status = "unpaired";
var lastError = "";
var backoff = 1e3;
var reconnectTimer;
var pingTimer;
var activeCalls = 0;
var inflight = /* @__PURE__ */ new Map();
var callSession = /* @__PURE__ */ new Map();
function setStatus(s, err = "") {
  status = s;
  lastError = err;
  const badge = {
    unpaired: ["!", "#F5A524"],
    connecting: ["\u2026", "#6366F1"],
    connected: ["", "#22C55E"],
    disconnected: ["off", "#71717A"],
    revoked: ["!", "#E5484D"]
  };
  const [text2, color] = badge[s];
  chrome.action.setBadgeText({ text: activeCalls > 0 && s === "connected" ? "\u25CF" : text2 }).catch(() => {
  });
  chrome.action.setBadgeBackgroundColor({ color: activeCalls > 0 ? "#8B5CF6" : color }).catch(() => {
  });
  chrome.runtime.sendMessage({ type: "acm:status-changed" }).catch(() => {
  });
}
async function profileName() {
  try {
    const info = await chrome.identity.getProfileUserInfo({ accountStatus: "ANY" });
    return info.email || void 0;
  } catch {
    return void 0;
  }
}
async function connect() {
  clearTimeout(reconnectTimer);
  const c = await getConnection();
  if (!c.server || !c.deviceToken) {
    setStatus("unpaired");
    return;
  }
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;
  setStatus("connecting");
  const url = `${c.server.replace(/^http/, "ws")}/ws`;
  let sock;
  try {
    sock = new WebSocket(url, [WS_SUBPROTOCOL, `${WS_TOKEN_PREFIX}${c.deviceToken}`]);
  } catch (e) {
    setStatus("disconnected", String(e));
    scheduleReconnect();
    return;
  }
  ws = sock;
  sock.onopen = async () => {
    backoff = 1e3;
    setStatus("connected");
    sock.send(JSON.stringify({ t: "hello", name: c.name ?? "Chrome", email: await profileName(), version: VERSION, userAgent: navigator.userAgent }));
    clearInterval(pingTimer);
    pingTimer = setInterval(() => sock.readyState === WebSocket.OPEN && sock.send('{"t":"ping"}'), 2e4);
  };
  sock.onmessage = (ev) => onMessage(sock, ev.data);
  sock.onclose = async (ev) => {
    if (ws === sock) ws = null;
    clearInterval(pingTimer);
    for (const ac of inflight.values()) ac.abort();
    if (ev.code === 4001) {
      setStatus("revoked", "This browser was removed from the account. Pair it again.");
      const cur = await getConnection();
      await setConnection({ server: cur.server, name: cur.name });
      return;
    }
    if (ev.code === 4e3) return;
    setStatus("disconnected", ev.reason || `Connection closed (${ev.code})`);
    scheduleReconnect();
  };
  sock.onerror = () => {
    lastError = "Cannot reach the server";
  };
}
function scheduleReconnect() {
  clearTimeout(reconnectTimer);
  reconnectTimer = setTimeout(connect, backoff);
  backoff = Math.min(backoff * 2, 3e4);
}
async function onMessage(sock, raw) {
  if (typeof raw !== "string") return;
  let msg;
  try {
    msg = JSON.parse(raw);
  } catch {
    return;
  }
  if (msg.t === "welcome") {
    const c = await getConnection();
    if (c.deviceId !== msg.deviceId) await setConnection({ ...c, deviceId: msg.deviceId });
    return;
  }
  if (msg.t === "cancel") {
    inflight.get(msg.id)?.abort();
    return;
  }
  if (msg.t !== "call") return;
  const ac = new AbortController();
  inflight.set(msg.id, ac);
  callSession.set(msg.id, msg.session?.id);
  activeCalls++;
  setStatus(status);
  try {
    const result = await runTool(msg.tool, msg.args ?? {}, msg.session, ac.signal);
    if (sock.readyState === WebSocket.OPEN) sock.send(JSON.stringify({ t: "result", id: msg.id, result }));
  } finally {
    inflight.delete(msg.id);
    callSession.delete(msg.id);
    activeCalls--;
    setStatus(status);
  }
}
async function pendingConnect() {
  const { pendingConnect: p } = await chrome.storage.session.get("pendingConnect");
  return p;
}
var polling = false;
async function pollConnect() {
  if (polling) return;
  polling = true;
  try {
    for (; ; ) {
      const p = await pendingConnect();
      if (!p) return;
      if (Date.now() > p.until) {
        await chrome.storage.session.remove("pendingConnect");
        return;
      }
      const res = await fetch(`${p.server}/api/connect/poll?cid=${encodeURIComponent(p.cid)}`, { cache: "no-store" }).catch(() => null);
      if (res?.status === 200) {
        const body = await res.json();
        await chrome.storage.session.remove("pendingConnect");
        const cur = await getConnection();
        ws?.close(1e3);
        ws = null;
        await setConnection({ server: p.server, deviceToken: body.deviceToken, deviceId: body.deviceId, accountId: body.accountId, name: cur.name });
        await connect();
        if (p.tabId !== void 0) setTimeout(() => chrome.tabs.remove(p.tabId).catch(() => {
        }), 1800);
        return;
      }
      await new Promise((r) => setTimeout(r, 1500));
    }
  } finally {
    polling = false;
  }
}
async function startConnect(server, name) {
  const base = server.replace(/\/+$/, "");
  const bytes = crypto.getRandomValues(new Uint8Array(24));
  const cid = btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  const cur = await getConnection();
  await setConnection({ ...cur, name });
  const tab = await chrome.tabs.create({ url: `${base}/connect?cid=${cid}&name=${encodeURIComponent(name)}`, active: true });
  await chrome.storage.session.set({ pendingConnect: { cid, server: base, tabId: tab.id, until: Date.now() + 15 * 6e4 } });
  pollConnect();
}
async function pair(server, code, name) {
  const base = server.replace(/\/+$/, "");
  const res = await fetch(`${base}/api/pair/redeem`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ code, name, email: await profileName(), version: VERSION })
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.error ?? `Pairing failed (HTTP ${res.status})`);
  ws?.close(1e3);
  ws = null;
  await setConnection({ server: base, deviceToken: body.deviceToken, deviceId: body.deviceId, accountId: body.accountId, name });
  await connect();
  return body.deviceId;
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.target === "offscreen") return false;
  (async () => {
    switch (msg?.type) {
      case "acm:status": {
        const c = await getConnection();
        const s = await getSettings();
        const sessions = await allSessions();
        const history = await chrome.permissions.contains({ permissions: ["history"] });
        return { status, lastError, server: c.server, name: c.name, deviceId: c.deviceId, settings: s, history, sessions, activeCalls, version: VERSION, connectPending: Boolean(await pendingConnect()) };
      }
      case "acm:connect-start":
        await startConnect(msg.server, msg.name || "Chrome");
        return { ok: true };
      case "acm:pair":
        return { deviceId: await pair(msg.server, msg.code, msg.name) };
      case "acm:unpair": {
        const c = await getConnection();
        ws?.close(1e3);
        ws = null;
        await setConnection({ server: c.server, name: c.name });
        setStatus("unpaired");
        return { ok: true };
      }
      case "acm:rename": {
        const c = await getConnection();
        await setConnection({ ...c, name: msg.name });
        if (c.server && c.deviceToken) {
          await fetch(`${c.server}/api/devices/rename`, {
            method: "POST",
            headers: { authorization: `Bearer ${c.deviceToken}`, "content-type": "application/json" },
            body: JSON.stringify({ name: msg.name })
          }).catch(() => {
          });
          ws?.send(JSON.stringify({ t: "hello", name: msg.name, email: await profileName(), version: VERSION }));
        }
        return { ok: true };
      }
      case "acm:reconnect":
        ws?.close(1e3);
        ws = null;
        backoff = 1e3;
        await connect();
        return { ok: true };
      case "acm:settings":
        return setSettings(msg.patch);
      case "acm:stop":
        return { paused: await setPaused(sender.tab?.id, true) };
      case "acm:resume":
        return { resumed: await setPaused(sender.tab?.id, false) };
      case "acm:resume-all":
        return { resumed: await setPaused(void 0, false) };
      case "acm:stop-all":
        for (const ac of inflight.values()) ac.abort();
        return { paused: await setPaused(void 0, true) };
      case "acm:session-pause": {
        const s = (await allSessions()).find((x) => x.id === msg.id);
        if (!s) return { ok: false };
        if (msg.paused) {
          for (const [id, ac] of inflight) if (callSession.get(id) === s.id) ac.abort();
        }
        await setSessionPaused(s, Boolean(msg.paused));
        return { ok: true };
      }
      case "acm:focus-session": {
        const s = (await allSessions()).find((x) => x.id === msg.id);
        const tabId2 = s?.currentTabId;
        const tab = tabId2 !== void 0 ? await chrome.tabs.get(tabId2).catch(() => null) : null;
        if (!tab) return { ok: false };
        await chrome.tabs.update(tab.id, { active: true });
        await chrome.windows.update(tab.windowId, { focused: true });
        if (s?.groupId !== void 0) await chrome.tabGroups.update(s.groupId, { collapsed: false }).catch(() => {
        });
        return { ok: true };
      }
      case "acm:forget-session": {
        const list = await allSessions();
        const s = list.find((x) => x.id === msg.id);
        if (s) {
          s.paused = false;
          s.groupId = void 0;
          s.currentTabId = void 0;
          await updateSession(s);
        }
        return { ok: true };
      }
      case "acm:prompt-answer":
        resolvePrompt(msg.id, msg.answer);
        return { ok: true };
    }
    return void 0;
  })().then(sendResponse, (e) => sendResponse({ error: String(e?.message ?? e) }));
  return true;
});
onUserCancel(() => {
  for (const ac of inflight.values()) ac.abort();
  setPaused(void 0, true, "debugger");
});
chrome.alarms.create("acm-keepalive", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "acm-keepalive" && (!ws || ws.readyState === WebSocket.CLOSED)) connect();
  if (a.name === "acm-keepalive") pollConnect();
});
chrome.runtime.onStartup.addListener(connect);
chrome.runtime.onInstalled.addListener(async (d) => {
  if (d.reason === "install") chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") });
  connect();
});
connect();
globalThis.__acmPair = pair;
globalThis.__acmStatus = () => ({ status, lastError });
