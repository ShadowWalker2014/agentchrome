// src/offscreen/gif.ts
var BAYER = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5].map((v) => v / 16 - 0.5);
function palette() {
  const p = new Uint8Array(256 * 3);
  let i = 0;
  for (let r = 0; r < 6; r++) for (let g = 0; g < 7; g++) for (let b = 0; b < 6; b++) {
    p[i++] = Math.round(r * 255 / 5);
    p[i++] = Math.round(g * 255 / 6);
    p[i++] = Math.round(b * 255 / 5);
  }
  return p;
}
function quantize(rgba, w, h) {
  const out = new Uint8Array(w * h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = y * w + x;
      const d = BAYER[(y & 3) * 4 + (x & 3)];
      const r = Math.min(5, Math.max(0, Math.round(rgba[i * 4] / 255 * 5 + d)));
      const g = Math.min(6, Math.max(0, Math.round(rgba[i * 4 + 1] / 255 * 6 + d)));
      const b = Math.min(5, Math.max(0, Math.round(rgba[i * 4 + 2] / 255 * 5 + d)));
      out[i] = r * 42 + g * 6 + b;
    }
  }
  return out;
}
var ByteWriter = class {
  chunks = [];
  buf = new Uint8Array(1 << 16);
  len = 0;
  byte(b) {
    if (this.len === this.buf.length) this.flush();
    this.buf[this.len++] = b;
  }
  bytes(a) {
    for (let i = 0; i < a.length; i++) this.byte(a[i]);
  }
  u16(v) {
    this.byte(v & 255);
    this.byte(v >> 8 & 255);
  }
  flush() {
    this.chunks.push(this.buf.slice(0, this.len));
    this.len = 0;
  }
  blob() {
    this.flush();
    return new Blob(this.chunks, { type: "image/gif" });
  }
};
function lzw(indices, out) {
  const minCode = 8;
  const clear = 1 << minCode;
  const eoi = clear + 1;
  let codeSize = minCode + 1;
  let next = eoi + 1;
  let dict = /* @__PURE__ */ new Map();
  const block = [];
  let cur = 0;
  let bits = 0;
  const emit = (code) => {
    cur |= code << bits;
    bits += codeSize;
    while (bits >= 8) {
      block.push(cur & 255);
      cur >>>= 8;
      bits -= 8;
      if (block.length === 255) {
        out.byte(255);
        out.bytes(block);
        block.length = 0;
      }
    }
  };
  out.byte(minCode);
  emit(clear);
  let prefix = indices[0];
  for (let i = 1; i < indices.length; i++) {
    const k = indices[i];
    const key = prefix << 8 | k;
    const hit = dict.get(key);
    if (hit !== void 0) {
      prefix = hit;
      continue;
    }
    emit(prefix);
    if (next < 4096) {
      dict.set(key, next++);
      if (next > 1 << codeSize && codeSize < 12) codeSize++;
    } else {
      emit(clear);
      dict = /* @__PURE__ */ new Map();
      codeSize = minCode + 1;
      next = eoi + 1;
    }
    prefix = k;
  }
  emit(prefix);
  emit(eoi);
  if (bits > 0) block.push(cur & 255);
  if (block.length) {
    out.byte(block.length);
    out.bytes(block);
  }
  out.byte(0);
}
function encodeGif(frames, w, h) {
  const out = new ByteWriter();
  out.bytes([71, 73, 70, 56, 57, 97]);
  out.u16(w);
  out.u16(h);
  out.byte(247);
  out.byte(0);
  out.byte(0);
  out.bytes(palette());
  out.bytes([33, 255, 11, ...Array.from("NETSCAPE2.0", (c) => c.charCodeAt(0)), 3, 1, 0, 0, 0]);
  for (const f of frames) {
    out.bytes([33, 249, 4, 0]);
    out.u16(Math.max(2, Math.round(f.delayMs / 10)));
    out.bytes([0, 0]);
    out.byte(44);
    out.u16(0);
    out.u16(0);
    out.u16(w);
    out.u16(h);
    out.byte(0);
    lzw(f.indices, out);
  }
  out.byte(59);
  return out.blob();
}

// src/offscreen/recorder.ts
var recs = /* @__PURE__ */ new Map();
var MAX_GIF_FRAMES = 400;
function pickMime(kind, format) {
  if (kind === "gif") return "image/gif";
  const mp4 = ["video/mp4;codecs=avc1.42E01E", "video/mp4;codecs=avc1", "video/mp4"];
  const webm = ["video/webm;codecs=vp9", "video/webm;codecs=vp8", "video/webm"];
  const order = format === "webm" ? [...webm, ...mp4] : [...mp4, ...webm];
  return order.find((m) => MediaRecorder.isTypeSupported(m)) ?? "video/webm";
}
function b64ToBlob(b64, type) {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type });
}
async function blobToB64(blob) {
  const buf = new Uint8Array(await blob.arrayBuffer());
  let s = "";
  for (let i = 0; i < buf.length; i += 32768) s += String.fromCharCode(...buf.subarray(i, i + 32768));
  return btoa(s);
}
function draw(r) {
  if (!r.last) return;
  const { ctx, canvas } = r;
  ctx.drawImage(r.last, 0, 0, canvas.width, canvas.height);
  const now = performance.now();
  r.clicks = r.clicks.filter((c) => now - c.t < 700);
  const scale = r.meta ? canvas.width / r.meta.deviceWidth : 1;
  for (const c of r.clicks) {
    const k = (now - c.t) / 700;
    const x = c.x * scale;
    const y = c.y * scale;
    ctx.beginPath();
    ctx.arc(x, y, (10 + 22 * k) * Math.max(1, scale), 0, Math.PI * 2);
    ctx.fillStyle = `rgba(47,107,255,${0.22 * (1 - k)})`;
    ctx.fill();
    ctx.lineWidth = 3 * Math.max(1, scale);
    ctx.strokeStyle = `rgba(47,107,255,${1 - k})`;
    ctx.stroke();
  }
}
function sampleGif(r) {
  if (!r.last || r.gif.length >= MAX_GIF_FRAMES) return;
  if (!r.gifCanvas) {
    const s = Math.min(1, 640 / r.canvas.width);
    r.gifW = Math.max(2, Math.round(r.canvas.width * s));
    r.gifH = Math.max(2, Math.round(r.canvas.height * s));
    r.gifCanvas = new OffscreenCanvas(r.gifW, r.gifH);
  }
  const g = r.gifCanvas.getContext("2d", { willReadFrequently: true });
  g.drawImage(r.canvas, 0, 0, r.gifW, r.gifH);
  const data = g.getImageData(0, 0, r.gifW, r.gifH).data;
  let sig = 0;
  for (let i = 0; i < data.length; i += 997) sig = sig * 31 + data[i] | 0;
  const delay = 1e3 / r.fps;
  const prev = r.gif[r.gif.length - 1];
  if (prev && sig === r.lastSig && r.clicks.length === 0) {
    prev.delayMs += delay;
    return;
  }
  r.lastSig = sig;
  r.gif.push({ indices: quantize(data, r.gifW, r.gifH), delayMs: delay });
}
function startEncoder(r) {
  if (r.kind === "video") {
    const stream = r.canvas.captureStream(r.fps);
    r.recorder = new MediaRecorder(stream, { mimeType: r.mimeType, videoBitsPerSecond: 5e6 });
    r.recorder.ondataavailable = (e) => e.data.size && r.chunks.push(e.data);
    r.recorder.start(1e3);
  }
  r.started = performance.now();
  r.timer = setInterval(() => {
    draw(r);
    if (r.kind === "gif") sampleGif(r);
  }, 1e3 / r.fps);
}
async function upload(blob, server, token, name) {
  const res = await fetch(`${server}/api/artifacts?name=${encodeURIComponent(name)}`, {
    method: "POST",
    headers: { authorization: `Bearer ${token}`, "content-type": blob.type },
    body: blob
  });
  if (!res.ok) throw new Error(`HTTP ${res.status} ${await res.text().catch(() => "")}`);
  return await res.json();
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.target !== "offscreen") return false;
  (async () => {
    if (msg.type === "rec:start") {
      const canvas = document.createElement("canvas");
      canvas.width = 1280;
      canvas.height = 800;
      document.body.appendChild(canvas);
      const mimeType = pickMime(msg.kind, msg.format);
      const r2 = {
        recId: msg.recId,
        kind: msg.kind,
        fps: msg.fps,
        format: msg.format,
        canvas,
        ctx: canvas.getContext("2d"),
        mimeType,
        chunks: [],
        started: 0,
        frames: 0,
        clicks: [],
        gif: [],
        gifW: 0,
        gifH: 0
      };
      recs.set(msg.recId, r2);
      return { ok: true, mimeType };
    }
    const r = recs.get(msg.recId);
    if (!r) return { ok: false, error: "No such recording" };
    if (msg.type === "rec:frame") {
      const bmp = await createImageBitmap(b64ToBlob(msg.data, "image/jpeg"));
      r.last?.close();
      r.last = bmp;
      r.meta = msg.metadata;
      r.frames++;
      if (!r.timer) {
        r.canvas.width = bmp.width - bmp.width % 2;
        r.canvas.height = bmp.height - bmp.height % 2;
        draw(r);
        startEncoder(r);
      }
      return { ok: true };
    }
    if (msg.type === "rec:click") {
      r.clicks.push({ x: msg.x, y: msg.y, t: performance.now() });
      return { ok: true };
    }
    if (msg.type === "rec:stop") {
      recs.delete(msg.recId);
      clearInterval(r.timer);
      if (!r.timer) return { ok: false, error: "No frames were captured. Recording needs the tab to be visible in a window that is not minimized." };
      const durationMs = performance.now() - r.started;
      let blob;
      if (r.kind === "video") {
        draw(r);
        await new Promise((res) => setTimeout(res, 150));
        const stopped = new Promise((res) => r.recorder.onstop = res);
        r.recorder.stop();
        await stopped;
        blob = new Blob(r.chunks, { type: r.mimeType.split(";")[0] });
      } else {
        sampleGif(r);
        blob = encodeGif(r.gif, r.gifW, r.gifH);
      }
      r.canvas.remove();
      r.last?.close();
      const ext = r.kind === "gif" ? "gif" : r.mimeType.includes("mp4") ? "mp4" : "webm";
      const base = (msg.filename || `agent-recording-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}`).replace(/\.(mp4|webm|gif)$/i, "");
      let url;
      let path;
      let uploadError;
      if (msg.server && msg.token) {
        try {
          const up = await upload(blob, msg.server, msg.token, `${base}.${ext}`);
          url = up.url;
          path = up.path;
        } catch (e) {
          uploadError = String(e.message ?? e);
        }
      }
      const base64 = msg.inline && blob.size < 3e6 ? await blobToB64(blob) : void 0;
      return {
        ok: true,
        url,
        path,
        uploadError,
        base64,
        bytes: blob.size,
        durationMs,
        mimeType: blob.type,
        ext,
        frames: r.kind === "gif" ? r.gif.length : r.frames,
        objectUrl: URL.createObjectURL(blob)
      };
    }
    return { ok: false, error: `Unknown message ${msg.type}` };
  })().then(sendResponse, (e) => sendResponse({ ok: false, error: String(e?.message ?? e) }));
  return true;
});
