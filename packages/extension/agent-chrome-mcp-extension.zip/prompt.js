// src/popup/prompt.ts
var q = new URLSearchParams(location.search);
var host = q.get("host") ?? "";
var client = q.get("client") ?? "An agent";
document.getElementById("who").textContent = `${client} wants to use`;
document.getElementById("title").textContent = host;
document.getElementById("fav").src = `https://www.google.com/s2/favicons?domain=${encodeURIComponent(host)}&sz=64`;
document.getElementById("desc").textContent = `It will be able to read and act on ${host} in this Chrome profile, where you may be signed in. Web pages can contain instructions meant to trick agents, so only allow sites you trust for this task.`;
var answer = async (a) => {
  await chrome.runtime.sendMessage({ type: "acm:prompt-answer", id: q.get("id"), answer: a });
  window.close();
};
for (const b of document.querySelectorAll("button[data-a]")) b.onclick = () => answer(b.dataset.a);
addEventListener("keydown", (e) => e.key === "Escape" && answer("deny"));
